"""
Telegram Bot Phase 2 Service for Honda HPPM Tender Lifecycle with Rich UI/UX
Features:
- Native Bot Menu Button & Persistent Keyboard Buttons (Bawah Layar)
- 📝 Buat / Edit Quotation
- 📋 Daftar RFQ Terbaru (dengan tombol klik langsung tanpa perlu ketik nomor RFQ)
- 📊 Cek Status Portal & Token
- 💡 Panduan Penggunaan
- Pengecekan otomatis Create vs Edit Quotation
- Ekstraksi PDF AI (Nemotron/Vision/Regex) & Teks interaktif
- Preview konfirmasi sebelum live submission
"""

import os
import re
import json
import time
import sqlite3
import logging
import threading
import requests
import io
from typing import Dict, Any, Optional

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger("telegram_phase2_bot")

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "9195418527:AAE86SeYoCnNHcCLD916RemhovjFMZGksYY")
HONDA_PORTAL_BASE = "https://gpsystem.id"
OPENROUTER_KEY = os.getenv("OPENROUTER_API_KEY", "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")
DB_PATH = os.path.join(os.path.dirname(__file__), "rfq_quotation_cache.db")

# In-memory user state
user_sessions: Dict[int, Dict[str, Any]] = {}

# Menu Keyboard Statis di Bawah Layar
MAIN_MENU_KEYBOARD = {
    "keyboard": [
        [{"text": "📝 Buat / Edit Quotation"}, {"text": "📋 Daftar RFQ Terbaru"}],
        [{"text": "📊 Cek Status Portal"}, {"text": "💡 Panduan Penggunaan"}]
    ],
    "resize_keyboard": True,
    "is_persistent": True
}

def get_db_connection():
    return sqlite3.connect(DB_PATH)

def get_honda_token() -> Optional[str]:
    try:
        conn = get_db_connection()
        c = conn.cursor()
        c.execute("SELECT token FROM auth_tokens WHERE portal_name = 'honda'")
        row = c.fetchone()
        conn.close()
        if row and row[0]:
            return row[0]
    except Exception as e:
        logger.warning(f"Failed to read token from SQLite: {e}")
    
    try:
        res = requests.get("http://127.0.0.1:8000/api/auth/token", timeout=5)
        if res.status_code == 200:
            return res.json().get("token")
    except Exception:
        pass
    return None

def telegram_request(method: str, data: Optional[Dict[str, Any]] = None, files: Optional[Dict[str, Any]] = None):
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/{method}"
    try:
        if files:
            res = requests.post(url, data=data, files=files, timeout=30)
        else:
            res = requests.post(url, json=data, timeout=30)
        return res.json()
    except Exception as e:
        logger.error(f"Telegram API request {method} error: {e}")
        return None

def send_message(chat_id: int, text: str, reply_markup: Optional[Dict[str, Any]] = None, parse_mode: str = "Markdown"):
    # Default pakai main keyboard jika tidak ditentukan
    markup = reply_markup if reply_markup is not None else MAIN_MENU_KEYBOARD
    payload = {
        "chat_id": chat_id,
        "text": text,
        "parse_mode": parse_mode,
        "reply_markup": markup
    }
    return telegram_request("sendMessage", payload)

def answer_callback(callback_query_id: str, text: Optional[str] = None):
    payload = {"callback_query_id": callback_query_id}
    if text:
        payload["text"] = text
    return telegram_request("answerCallbackQuery", payload)

def register_bot_commands():
    commands = {
        "commands": [
            {"command": "createqt", "description": "📝 Buat atau Edit Quotation RFQ"},
            {"command": "listrfq", "description": "📋 Lihat Daftar RFQ Terbaru Honda"},
            {"command": "status", "description": "📊 Cek Status Portal & Token"},
            {"command": "help", "description": "💡 Panduan Penggunaan"}
        ]
    }
    telegram_request("setMyCommands", commands)

def get_recent_rfqs(limit: int = 5) -> list:
    token = get_honda_token()
    if not token:
        return []
    headers = {
        "Authorization": f"Bearer {token}",
        "User-Agent": "Mozilla/5.0",
        "Referer": f"{HONDA_PORTAL_BASE}/"
    }
    try:
        # Urutkan berdasarkan tanggal RFQ terbaru (Rfq_Date descending)
        url = f"{HONDA_PORTAL_BASE}/api/v1/supplier/rfqs?rowsPerPage={limit}&page=1&sortBy[0]=Rfq_Date&sortDesc[0]=true"
        res = requests.get(url, headers=headers, timeout=10, verify=False)
        if res.status_code == 200:
            raw = res.json()
            return raw if isinstance(raw, list) else raw.get("data", [])
    except Exception as e:
        logger.error(f"Error fetching recent RFQs: {e}")
    return []

def search_rfq_on_honda(rfq_number: str) -> Optional[Dict[str, Any]]:
    token = get_honda_token()
    if not token:
        logger.error("No active Honda token available")
        return None
    
    headers = {
        "Authorization": f"Bearer {token}",
        "User-Agent": "Mozilla/5.0",
        "Referer": f"{HONDA_PORTAL_BASE}/"
    }
    url = f"{HONDA_PORTAL_BASE}/api/v1/supplier/rfqs?search={rfq_number.strip()}&rowsPerPage=1&page=1"
    try:
        res = requests.get(url, headers=headers, timeout=10, verify=False)
        if res.status_code == 200:
            data = res.json()
            rows = data if isinstance(data, list) else data.get("data", [])
            for r in rows:
                if r.get("rfqNumber", "").strip().upper() == rfq_number.strip().upper():
                    return r
            if rows:
                return rows[0]
    except Exception as e:
        logger.error(f"Error searching RFQ {rfq_number}: {e}")
    return None

def get_rfq_items_on_honda(rfq_id: int) -> list:
    token = get_honda_token()
    if not token:
        return []
    headers = {
        "Authorization": f"Bearer {token}",
        "User-Agent": "Mozilla/5.0",
        "Referer": f"{HONDA_PORTAL_BASE}/"
    }
    url = f"{HONDA_PORTAL_BASE}/api/v1/supplier/rfqs/{rfq_id}/items?rowsPerPage=50&page=1"
    try:
        res = requests.get(url, headers=headers, timeout=10, verify=False)
        if res.status_code == 200:
            raw = res.json()
            return raw if isinstance(raw, list) else raw.get("data", [])
    except Exception as e:
        logger.error(f"Error fetching items for RFQ {rfq_id}: {e}")
    return []

def extract_text_from_pdf(pdf_bytes: bytes) -> str:
    try:
        from pypdf import PdfReader
        reader = PdfReader(io.BytesIO(pdf_bytes))
        extracted = []
        for page in reader.pages:
            t = page.extract_text()
            if t:
                extracted.append(t)
        return "\n".join(extracted)
    except Exception as e:
        logger.error(f"pypdf extraction error: {e}")
        return ""

def parse_pdf_quotation_with_ai(pdf_text: str, rfq_number: str, rfq_items: list) -> Optional[Dict[str, Any]]:
    items_context = []
    for it in rfq_items:
        items_context.append({
            "rfqItemId": it.get("rfqItId"),
            "partCode": it.get("purItCode"),
            "partName": it.get("purItName"),
            "qty": it.get("rfqItQty", 1)
        })

    prompt = f"""Anda adalah asisten AI ekstraksi dokumen Quotation tender manufaktur Honda.
Teks berikut diekstrak dari file PDF Dokumen Penawaran Resmi:

--- AWAL TEKS PDF ---
{pdf_text[:4000]}
--- AKHIR TEKS PDF ---

Item yang dibutuhkan oleh RFQ ({rfq_number}):
{json.dumps(items_context, indent=2)}

Tugas Anda: Ekstrak data penawaran menjadi format JSON PERSIS seperti skema berikut:
{{
  "number": "Nomor quotation dari dokumen (cth: QT2026-G106)",
  "date": "YYYY-MM-DD",
  "validDate": "YYYY-MM-DD",
  "eta": "YYYY-MM-DD",
  "currencyCode": "IDR",
  "paymentTerms": "END_OF_NEXT_MONTH",
  "items": [
    {{
      "rfqItemId": {items_context[0]['rfqItemId'] if items_context else 0},
      "qty": {items_context[0]['qty'] if items_context else 1},
      "price": 0,
      "hsCode": "8504.40",
      "hsCodeDescription": "LAIN-LAIN",
      "netto": "2.0000",
      "nettoUnit": "KG"
    }}
  ]
}}

Keluarkan HANYA blok JSON valid tanpa teks markdown pengantar."""

    try:
        resp = requests.post(
            "https://openrouter.ai/api/v1/chat/completions",
            headers={"Authorization": f"Bearer {OPENROUTER_KEY}", "Content-Type": "application/json"},
            json={
                "model": "nvidia/nemotron-3-ultra-550b-a55b:free",
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0.1
            },
            timeout=15
        )
        if resp.status_code == 200:
            res_content = resp.json()["choices"][0]["message"]["content"]
            cleaned = re.sub(r'```(?:json)?', '', res_content).strip()
            match = re.search(r'(\{[\s\S]*\})', cleaned)
            if match:
                return json.loads(match.group(1))
    except Exception as e:
        logger.warning(f"AI extraction failed, fallback to heuristic: {e}")

    # Fallback Heuristik
    import datetime
    today = datetime.date.today()
    valid_until = today + datetime.timedelta(days=30)
    eta_default = today + datetime.timedelta(days=180)

    q_num_match = re.search(r'(?:QUOTATION\s+NO|NO\s*:\s*|QT[\w\-/]+)\s*[:.]?\s*([A-Za-z0-9\-/]+)', pdf_text, re.IGNORECASE)
    quot_num = q_num_match.group(1).strip() if q_num_match else f"QT{today.strftime('%Y')}-001"

    price_matches = re.findall(r'(?:Rp\.?|IDR)\s*([\d.,]+)', pdf_text, re.IGNORECASE)
    found_price = 0
    if price_matches:
        try:
            clean_p = price_matches[0].replace(".", "").replace(",", "")
            found_price = int(clean_p)
        except Exception:
            pass

    fallback_payload = {
        "number": quot_num,
        "date": today.strftime("%Y-%m-%d"),
        "validDate": valid_until.strftime("%Y-%m-%d"),
        "eta": eta_default.strftime("%Y-%m-%d"),
        "currencyCode": "IDR",
        "paymentTerms": "END_OF_NEXT_MONTH",
        "items": []
    }

    for it in rfq_items:
        fallback_payload["items"].append({
            "rfqItemId": it.get("rfqItId"),
            "qty": it.get("rfqItQty", 1),
            "price": found_price if found_price > 0 else it.get("quotItPrice", 8000000),
            "hsCode": it.get("quotItHsCode", "8504.40") or "8504.40",
            "hsCodeDescription": it.get("quotItHsCodeDescription", "LAIN-LAIN") or "LAIN-LAIN",
            "netto": it.get("quotItNetto", "2.0000") or "2.0000",
            "nettoUnit": it.get("quotItNettoUnit", "KG") or "KG"
        })

    return fallback_payload

def build_text_template(rfq_data: Dict[str, Any], rfq_items: list, is_edit: bool = False) -> str:
    import datetime
    today = datetime.date.today().strftime("%Y-%m-%d")
    valid = (datetime.date.today() + datetime.timedelta(days=30)).strftime("%Y-%m-%d")
    eta = (datetime.date.today() + datetime.timedelta(days=180)).strftime("%Y-%m-%d")

    num = rfq_data.get("quotNumber", f"QT{datetime.date.today().year}-001") if is_edit else f"QT{datetime.date.today().year}-001"
    num = (num or "").strip()
    
    tgl = rfq_data.get("quotDate", today) if is_edit else today
    val_tgl = rfq_data.get("quotValidDate", valid) if is_edit else valid
    eta_tgl = rfq_data.get("quotEta", eta) if is_edit else eta
    curr = rfq_data.get("quotCurrencyCode", "IDR") if is_edit else "IDR"
    pay = rfq_data.get("quotPaymentTerms", "END_OF_NEXT_MONTH") if is_edit else "END_OF_NEXT_MONTH"

    lines = [
        "/submitqt",
        f"RFQ: {rfq_data.get('rfqNumber')}",
        f"No Quotation: {num}",
        f"Tanggal: {tgl}",
        f"Valid Hingga: {val_tgl}",
        f"ETA Kirim: {eta_tgl}",
        f"Mata Uang: {curr}",
        f"Payment Terms: {pay}",
        ""
    ]

    for idx, it in enumerate(rfq_items, start=1):
        price = it.get("quotItPrice") if is_edit and it.get("quotItPrice") else 0
        hs = it.get("quotItHsCode") if is_edit and it.get("quotItHsCode") else "8504.40"
        hs_desc = it.get("quotItHsCodeDescription") if is_edit and it.get("quotItHsCodeDescription") else "LAIN-LAIN"
        netto = it.get("quotItNetto") if is_edit and it.get("quotItNetto") else "1.0000"
        unit = it.get("quotItNettoUnit") if is_edit and it.get("quotItNettoUnit") else "KG"

        lines.append(f"--- Item {idx} [ID: {it.get('rfqItId')}] ---")
        lines.append(f"Part Code: {it.get('purItCode')}")
        lines.append(f"Part Name: {it.get('purItName')}")
        lines.append(f"Qty: {it.get('rfqItQty')}")
        lines.append(f"Harga: {price}")
        lines.append(f"HS Code: {hs}")
        lines.append(f"Deskripsi HS: {hs_desc}")
        lines.append(f"Netto: {netto}")
        lines.append(f"Satuan Netto: {unit}")
        lines.append("")

    return "\n".join(lines).strip()

def parse_text_submission(text: str, rfq_items: list) -> Optional[Dict[str, Any]]:
    try:
        def get_val(pattern, default=""):
            m = re.search(pattern, text, re.IGNORECASE)
            return m.group(1).strip() if m else default

        payload = {
            "number": get_val(r"No Quotation\s*:\s*([^\n]+)", "QT-DEFAULT"),
            "date": get_val(r"Tanggal\s*:\s*([\d\-]+)", ""),
            "validDate": get_val(r"Valid Hingga\s*:\s*([\d\-]+)", ""),
            "eta": get_val(r"ETA Kirim\s*:\s*([\d\-]+)", ""),
            "currencyCode": get_val(r"Mata Uang\s*:\s*([A-Za-z]+)", "IDR"),
            "paymentTerms": get_val(r"Payment Terms\s*:\s*([^\n]+)", "END_OF_NEXT_MONTH"),
            "items": []
        }

        item_blocks = re.split(r'---\s*Item\s*\d+[^-\n]*---', text, flags=re.IGNORECASE)
        actual_blocks = [b for b in item_blocks[1:] if b.strip()]

        for idx, it in enumerate(rfq_items):
            block = actual_blocks[idx] if idx < len(actual_blocks) else ""
            p_match = re.search(r'Harga\s*:\s*([\d.,]+)', block, re.IGNORECASE)
            price = int(re.sub(r'[^\d]', '', p_match.group(1))) if p_match else 0

            hs_match = re.search(r'HS Code\s*:\s*([\d.]+)', block, re.IGNORECASE)
            hs = hs_match.group(1).strip() if hs_match else "8504.40"

            hsd_match = re.search(r'Deskripsi HS\s*:\s*([^\n]+)', block, re.IGNORECASE)
            hs_desc = hsd_match.group(1).strip() if hsd_match else "LAIN-LAIN"

            netto_match = re.search(r'Netto\s*:\s*([\d.]+)', block, re.IGNORECASE)
            netto = netto_match.group(1).strip() if netto_match else "1.0000"

            unit_match = re.search(r'Satuan Netto\s*:\s*([A-Za-z]+)', block, re.IGNORECASE)
            unit = unit_match.group(1).strip() if unit_match else "KG"

            payload["items"].append({
                "rfqItemId": it.get("rfqItId"),
                "qty": it.get("rfqItQty", 1),
                "price": price,
                "hsCode": hs,
                "hsCodeDescription": hs_desc,
                "netto": netto,
                "nettoUnit": unit
            })

        return payload
    except Exception as e:
        logger.error(f"Error parsing text submission: {e}")
        return None

def execute_honda_submission(rfq_id: int, quot_id: Optional[int], payload: Dict[str, Any], pdf_bytes: Optional[bytes] = None, pdf_name: Optional[str] = None):
    token = get_honda_token()
    if not token:
        return False, "Token Honda tidak ditemukan/tidak valid."

    headers = {
        "Authorization": f"Bearer {token}",
        "Referer": f"{HONDA_PORTAL_BASE}/",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    }

    form_data = {
        "_method": "post",
        "number": payload.get("number", ""),
        "date": payload.get("date", ""),
        "validDate": payload.get("validDate", ""),
        "eta": payload.get("eta", ""),
        "currencyCode": payload.get("currencyCode", "IDR"),
        "paymentTerms": payload.get("paymentTerms", "END_OF_NEXT_MONTH"),
        "hsCode": payload.get("items", [{}])[0].get("hsCode", "8504.40")
    }

    for idx, item in enumerate(payload.get("items", [])):
        form_data[f"items[{idx}][rfqItemId]"] = str(item.get("rfqItemId"))
        form_data[f"items[{idx}][qty]"] = str(item.get("qty", 1))
        form_data[f"items[{idx}][price]"] = str(item.get("price", 0))
        form_data[f"items[{idx}][hsCode]"] = str(item.get("hsCode", "8504.40"))
        form_data[f"items[{idx}][hsCodeDescription]"] = str(item.get("hsCodeDescription", "LAIN-LAIN"))
        form_data[f"items[{idx}][netto]"] = str(item.get("netto", "1.0000"))
        form_data[f"items[{idx}][nettoUnit]"] = str(item.get("nettoUnit", "KG"))

    assign_url = f"{HONDA_PORTAL_BASE}/api/v1/supplier/rfqs/{rfq_id}/assign-quotation"
    files = None
    if pdf_bytes:
        filename = pdf_name or "quotation.pdf"
        files = {"quotFile1": (filename, pdf_bytes, "application/pdf")}

    try:
        if files:
            res_assign = requests.post(assign_url, data=form_data, files=files, headers=headers, timeout=20, verify=False)
        else:
            res_assign = requests.post(assign_url, data=form_data, headers=headers, timeout=20, verify=False)
        
        if res_assign.status_code != 200:
            return False, f"Gagal saat /assign-quotation (HTTP {res_assign.status_code}): {res_assign.text[:200]}"
        
        target_quot_id = quot_id
        if not target_quot_id:
            updated_rfq = requests.get(f"{HONDA_PORTAL_BASE}/api/v1/supplier/rfqs/{rfq_id}/items", headers=headers, timeout=10, verify=False).json()
            rows = updated_rfq if isinstance(updated_rfq, list) else updated_rfq.get("data", [])
            if rows and rows[0].get("quotItQuotationId"):
                target_quot_id = rows[0].get("quotItQuotationId")
            else:
                rfq_check = requests.get(f"{HONDA_PORTAL_BASE}/api/v1/supplier/rfqs?rowsPerPage=10&page=1", headers=headers, timeout=10, verify=False).json()
                rfq_rows = rfq_check if isinstance(rfq_check, list) else rfq_check.get("data", [])
                for r in rfq_rows:
                    if r.get("rfqId") == rfq_id:
                        target_quot_id = r.get("quotId")
                        break

        if not target_quot_id:
            return True, "Data berhasil di-assign ke Honda, tetapi quotId tidak ditemukan untuk submit final."

        submit_url = f"{HONDA_PORTAL_BASE}/api/v1/supplier/rfqs/{target_quot_id}/submit-quotation"
        submit_data = {"_method": "put", "status_rfq": "QUOTATION"}
        res_submit = requests.post(submit_url, data=submit_data, headers=headers, timeout=20, verify=False)
        
        if res_submit.status_code == 200:
            return True, "Quotation berhasil di-assign dan di-submit ke status COMPLETE ✅"
        else:
            return False, f"Gagal saat /submit-quotation (HTTP {res_submit.status_code}): {res_submit.text[:200]}"

    except Exception as e:
        logger.error(f"Execution error on Honda API: {e}")
        return False, str(e)

def process_selected_rfq(chat_id: int, rfq_number: str):
    """Memproses RFQ yang dipilih user baik via input teks maupun tombol langsung."""
    user_sessions[chat_id] = {"state": "PROCESSING_RFQ"}
    send_message(chat_id, f"🔍 *Mengecek data RFQ `{rfq_number}` ke portal Honda...*")
    
    rfq_info = search_rfq_on_honda(rfq_number)
    if not rfq_info:
        send_message(chat_id, f"❌ RFQ dengan nomor `{rfq_number}` tidak ditemukan di portal Honda.\nPastikan nomor RFQ sudah sesuai.")
        return

    rfq_id = rfq_info.get("rfqId")
    items = get_rfq_items_on_honda(rfq_id)
    quot_id = rfq_info.get("quotId")
    is_edit = bool(quot_id)

    user_sessions[chat_id]["rfq_data"] = rfq_info
    user_sessions[chat_id]["rfq_items"] = items
    user_sessions[chat_id]["is_edit"] = is_edit
    user_sessions[chat_id]["state"] = "CHOOSING_METHOD"

    item_summary = []
    for idx, it in enumerate(items, start=1):
        item_summary.append(f"{idx}. *{it.get('purItName')}* (Qty: {it.get('rfqItQty')})")
    items_str = "\n".join(item_summary) if item_summary else "Tidak ada item rincian."

    if not is_edit:
        card = (
            f"🟢 *Status: Belum Ada Quotation (Baru)*\n\n"
            f"• *Nomor RFQ*  : `{rfq_info.get('rfqNumber')}`\n"
            f"• *Buyer*      : PT Honda Precision Parts Manufacturing\n"
            f"• *Batas Waktu*: `{rfq_info.get('rfqEstQuotationDate', '-')[:10]}`\n\n"
            f"*Daftar Barang:*\n{items_str}\n\n"
            f"Pilih metode untuk *Membuat Quotation Baru*:"
        )
        buttons = {
            "inline_keyboard": [
                [{"text": "📁 Upload File (PDF)", "callback_data": f"method_file_{rfq_id}"}],
                [{"text": "📝 Isi Format Teks", "callback_data": f"method_text_{rfq_id}"}],
                [{"text": "❌ Batalkan", "callback_data": "cancel_action"}]
            ]
        }
    else:
        total_current = rfq_info.get("quotAmount", 0)
        card = (
            f"🟡 *Status: Sudah Pernah Dibuat (Edit)*\n\n"
            f"• *Nomor RFQ*    : `{rfq_info.get('rfqNumber')}`\n"
            f"• *No Quotation* : `{rfq_info.get('quotNumber', '-')}`\n"
            f"• *Status Saat Ini*: `{rfq_info.get('quotStatus', '-')}`\n"
            f"• *Total Harga*  : `Rp {total_current:,.0f}`\n\n"
            f"*Daftar Barang:*\n{items_str}\n\n"
            f"Quotation untuk RFQ ini sudah ada. Pilih metode untuk *Mengedit / Merevisi*:"
        )
        buttons = {
            "inline_keyboard": [
                [{"text": "📁 Upload File Revisi (PDF)", "callback_data": f"method_file_{rfq_id}"}],
                [{"text": "📝 Edit via Teks", "callback_data": f"method_text_{rfq_id}"}],
                [{"text": "❌ Batalkan", "callback_data": "cancel_action"}]
            ]
        }

    send_message(chat_id, card, reply_markup=buttons)

def handle_telegram_updates():
    register_bot_commands()
    logger.info("Memulai Telegram Phase 2 Polling Listener dengan Rich UI/UX...")
    offset = 0

    while True:
        try:
            url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/getUpdates?offset={offset}&timeout=15"
            resp = requests.get(url, timeout=25).json()

            if not resp.get("ok"):
                time.sleep(3)
                continue

            for update in resp.get("result", []):
                offset = update["update_id"] + 1

                # 1. Handle Callback Query (Klik Tombol Inline)
                if "callback_query" in update:
                    cb = update["callback_query"]
                    cb_id = cb["id"]
                    data = cb["data"]
                    chat_id = cb["message"]["chat"]["id"]
                    session = user_sessions.get(chat_id, {})

                    if data == "cancel_action":
                        user_sessions.pop(chat_id, None)
                        answer_callback(cb_id, "Dibatalkan")
                        send_message(chat_id, "❌ Operasi pengisian Quotation telah dibatalkan.")
                        continue

                    elif data.startswith("select_rfq_"):
                        rfq_num = data.replace("select_rfq_", "")
                        answer_callback(cb_id, f"Memilih {rfq_num}...")
                        process_selected_rfq(chat_id, rfq_num)
                        continue

                    elif data.startswith("method_text_"):
                        answer_callback(cb_id, "Membuat template...")
                        rfq_data = session.get("rfq_data", {})
                        rfq_items = session.get("rfq_items", [])
                        is_edit = session.get("is_edit", False)

                        template_text = build_text_template(rfq_data, rfq_items, is_edit=is_edit)
                        session["state"] = "AWAITING_TEXT_INPUT"

                        instruction = (
                            "📝 *Salin teks berikut, sesuaikan harga & tanggalnya, lalu kirim kembali ke bot:*\n\n"
                            f"```text\n{template_text}\n```"
                        )
                        send_message(chat_id, instruction)
                        continue

                    elif data.startswith("method_file_"):
                        answer_callback(cb_id, "Menunggu file PDF...")
                        session["state"] = "AWAITING_FILE_INPUT"
                        send_message(
                            chat_id,
                            "📁 *Silakan upload file Dokumen Penawaran Resmi (PDF)* Anda untuk RFQ ini.\n\n"
                            "AI akan membaca isi dokumen secara otomatis dan mencocokkannya dengan kebutuhan tender."
                        )
                        continue

                    elif data == "confirm_submit":
                        answer_callback(cb_id, "Mengirim ke Honda...")
                        payload = session.get("pending_payload")
                        rfq_data = session.get("rfq_data", {})
                        rfq_id = rfq_data.get("rfqId")
                        quot_id = rfq_data.get("quotId")
                        pdf_bytes = session.get("pending_pdf_bytes")
                        pdf_name = session.get("pending_pdf_name")

                        if not payload or not rfq_id:
                            send_message(chat_id, "❌ Data sesi tidak ditemukan. Silakan ulangi dengan /createqt.")
                            continue

                        send_message(chat_id, "⏳ *Sedang memproses dan menembakkan data ke portal resmi Honda...*")
                        success, msg = execute_honda_submission(rfq_id, quot_id, payload, pdf_bytes, pdf_name)
                        
                        if success:
                            total_amount = sum(it.get("price", 0) * it.get("qty", 1) for it in payload.get("items", []))
                            success_card = (
                                f"🎉 *BERHASIL SUBMIT QUOTATION KE HONDA!*\n\n"
                                f"• *Nomor RFQ*     : `{rfq_data.get('rfqNumber')}`\n"
                                f"• *No Quotation*  : `{payload.get('number')}`\n"
                                f"• *Tanggal Kirim* : `{payload.get('eta')}`\n"
                                f"• *Total Nilai*   : `Rp {total_amount:,.0f}`\n"
                                f"• *Status Portal* : `COMPLETE ✅`\n"
                                f"• *File Fisik*    : `{'Terlampir di Honda ✅' if pdf_bytes else 'Tidak dilampirkan'}`\n\n"
                                f"Catatan: Data penawaran telah resmi diterima oleh sistem pengadaan Honda."
                            )
                            send_message(chat_id, success_card)
                            user_sessions.pop(chat_id, None)
                        else:
                            send_message(chat_id, f"❌ Terjadi kesalahan saat submit ke Honda:\n`{msg}`\n\nSilakan periksa kembali.")
                        continue

                # 2. Handle Pesan Teks
                if "message" in update:
                    msg = update["message"]
                    chat_id = msg["chat"]["id"]
                    text = msg.get("text", "").strip()

                    # Start / Menu Bantuan
                    if text in ["/start", "/help", "💡 Panduan Penggunaan"]:
                        welcome_card = (
                            "👋 *Selamat Datang di Honda Tender Assistant!*\n\n"
                            "Bot ini membantu Anda memproses tender pengadaan suku cadang PT Honda Precision Parts Manufacturing (HPPM):\n\n"
                            "📌 *Pilihan Menu Tersedia:*\n"
                            "• `📝 Buat / Edit Quotation` : Isi harga RFQ via Teks atau Upload PDF Resmi.\n"
                            "• `📋 Daftar RFQ Terbaru` : Lihat 5 tender terbaru dan klik langsung.\n"
                            "• `📊 Cek Status Portal` : Periksa koneksi akun PT APSINDO & token.\n\n"
                            "Gunakan tombol di keyboard bawah untuk navigasi cepat!"
                        )
                        send_message(chat_id, welcome_card)
                        continue

                    # Cek Status Portal
                    if text in ["/status", "📊 Cek Status Portal"]:
                        token = get_honda_token()
                        status_card = (
                            "📊 *STATUS KONEKSI SISTEM HONDA*\n\n"
                            f"• *Portal Target* : `https://gpsystem.id`\n"
                            f"• *Supplier*      : `PT APSINDO GANANCIA PERKASA`\n"
                            f"• *Supplier Code* : `5100025127`\n"
                            f"• *Token Auth*    : `{'AKTIF (365 Hari) ✅' if token else 'KEDALUWARSA ⚠️'}`\n"
                            f"• *Service Status*: `ONLINE & READY 🚀`\n\n"
                            "Semua request ke portal Honda menggunakan sesi token terenkripsi."
                        )
                        send_message(chat_id, status_card)
                        continue

                    # Daftar RFQ Terbaru
                    if text in ["/listrfq", "📋 Daftar RFQ Terbaru"]:
                        send_message(chat_id, "⏳ *Mengambil daftar RFQ terbaru dari portal Honda...*")
                        recent_rfqs = get_recent_rfqs(limit=5)
                        if not recent_rfqs:
                            send_message(chat_id, "⚠️ Tidak dapat memuat daftar RFQ atau daftar kosong.")
                            continue

                        inline_buttons = []
                        rfq_texts = []
                        for idx, r in enumerate(recent_rfqs, start=1):
                            rfq_num = r.get("rfqNumber")
                            rfq_date = r.get("rfqDate", "-")
                            quot_status = r.get("quotStatus")
                            status_badge = "✅ COMPLETE" if quot_status == "COMPLETE" else "⏳ BELUM ADA"
                            rfq_texts.append(f"{idx}. `{rfq_num}` ({rfq_date}) — *{status_badge}*")
                            inline_buttons.append([{"text": f"👉 Pilih {rfq_num} ({rfq_date})", "callback_data": f"select_rfq_{rfq_num}"}])

                        rfq_list_card = (
                            "📋 *5 TENDER RFQ TERBARU DI PORTAL HONDA:*\n\n"
                            + "\n".join(rfq_texts) +
                            "\n\n*Pilih salah satu nomor RFQ di bawah untuk mulai membuat/edit quotation:*"
                        )
                        send_message(chat_id, rfq_list_card, reply_markup={"inline_keyboard": inline_buttons})
                        continue

                    # Trigger Buat / Edit Quotation
                    if text in ["/createqt", "📝 Buat / Edit Quotation"]:
                        user_sessions[chat_id] = {"state": "AWAITING_RFQ_NUMBER"}
                        send_message(chat_id, "Masukan RFQ number nya (cth: 24A-0XX0XX)")
                        continue

                    session = user_sessions.get(chat_id)

                    # Jika sedang menunggu nomor RFQ
                    if session and session.get("state") == "AWAITING_RFQ_NUMBER":
                        rfq_number = text.strip().upper()
                        process_selected_rfq(chat_id, rfq_number)
                        continue

                    # Jika sedang menunggu teks pengisian /submitqt
                    if session and session.get("state") == "AWAITING_TEXT_INPUT":
                        if "/submitqt" in text or "No Quotation" in text:
                            parsed_payload = parse_text_submission(text, session.get("rfq_items", []))
                            if not parsed_payload:
                                send_message(chat_id, "❌ Format teks tidak dapat dibaca. Pastikan format sesuai template.")
                                continue

                            session["pending_payload"] = parsed_payload
                            session["state"] = "AWAITING_CONFIRMATION"

                            total_val = sum(it.get("price", 0) * it.get("qty", 1) for it in parsed_payload.get("items", []))
                            preview_items = []
                            for idx, it in enumerate(parsed_payload.get("items", []), start=1):
                                preview_items.append(
                                    f"{idx}. Qty: {it.get('qty')} x Rp {it.get('price', 0):,.0f} | HS: {it.get('hsCode')} ({it.get('hsCodeDescription')})"
                                )
                            
                            preview_card = (
                                f"🔍 *KONFIRMASI PENGAJUAN QUOTATION*\n\n"
                                f"• *Nomor RFQ*    : `{session['rfq_data'].get('rfqNumber')}`\n"
                                f"• *No Quotation* : `{parsed_payload.get('number')}`\n"
                                f"• *Tanggal*      : `{parsed_payload.get('date')}`\n"
                                f"• *Valid Hingga* : `{parsed_payload.get('validDate')}`\n"
                                f"• *Estimasi Kirim*: `{parsed_payload.get('eta')}`\n"
                                f"• *Payment Terms*: `{parsed_payload.get('paymentTerms')}`\n\n"
                                f"*Rincian Item:*\n" + "\n".join(preview_items) + f"\n\n"
                                f"💰 *Total Nilai Penawaran*: `Rp {total_val:,.0f}`\n\n"
                                f"Apakah Anda yakin ingin submit penawaran ini ke Honda?"
                            )
                            confirm_buttons = {
                                "inline_keyboard": [
                                    [{"text": "🚀 Ya, Kirim ke Honda", "callback_data": "confirm_submit"}],
                                    [{"text": "❌ Batalkan", "callback_data": "cancel_action"}]
                                ]
                            }
                            send_message(chat_id, preview_card, reply_markup=confirm_buttons)
                            continue

                    # Handle upload Document (PDF)
                    if "document" in msg and session and session.get("state") == "AWAITING_FILE_INPUT":
                        doc = msg["document"]
                        file_id = doc["file_id"]
                        file_name = doc.get("file_name", "quotation.pdf")

                        if not file_name.lower().endswith(".pdf"):
                            send_message(chat_id, "⚠️ Harap upload file berekstensi *.pdf* resmi penawaran Anda.")
                            continue

                        send_message(chat_id, f"📥 *Mengunduh file `{file_name}` dan membaca data via AI...*")

                        file_info = telegram_request("getFile", {"file_id": file_id})
                        if not file_info or not file_info.get("ok"):
                            send_message(chat_id, "❌ Gagal mengunduh file dari Telegram.")
                            continue

                        file_path = file_info["result"]["file_path"]
                        download_url = f"https://api.telegram.org/file/bot{TELEGRAM_BOT_TOKEN}/{file_path}"
                        pdf_bytes = requests.get(download_url, timeout=30).content

                        pdf_text = extract_text_from_pdf(pdf_bytes)
                        if not pdf_text:
                            send_message(chat_id, "⚠️ File PDF tidak memuat teks digital yang dapat dibaca.")
                        
                        parsed_payload = parse_pdf_quotation_with_ai(
                            pdf_text,
                            session["rfq_data"].get("rfqNumber"),
                            session.get("rfq_items", [])
                        )

                        if not parsed_payload:
                            send_message(chat_id, "❌ Gagal mengekstrak data dari dokumen PDF.")
                            continue

                        session["pending_payload"] = parsed_payload
                        session["pending_pdf_bytes"] = pdf_bytes
                        session["pending_pdf_name"] = file_name
                        session["state"] = "AWAITING_CONFIRMATION"

                        total_val = sum(it.get("price", 0) * it.get("qty", 1) for it in parsed_payload.get("items", []))
                        preview_items = []
                        for idx, it in enumerate(parsed_payload.get("items", []), start=1):
                            preview_items.append(
                                f"{idx}. Qty: {it.get('qty')} x Rp {it.get('price', 0):,.0f} | HS: {it.get('hsCode')} ({it.get('hsCodeDescription')})"
                            )

                        preview_card = (
                            f"🤖 *HASIL PEMBACAAN DOKUMEN OLEH AI*\n\n"
                            f"• *Nomor RFQ*    : `{session['rfq_data'].get('rfqNumber')}`\n"
                            f"• *No Quotation* : `{parsed_payload.get('number')}`\n"
                            f"• *Tanggal*      : `{parsed_payload.get('date')}`\n"
                            f"• *Valid Hingga* : `{parsed_payload.get('validDate')}`\n"
                            f"• *Estimasi Kirim*: `{parsed_payload.get('eta')}`\n"
                            f"• *Payment Terms*: `{parsed_payload.get('paymentTerms')}`\n\n"
                            f"*Rincian Item yang Diekstrak:*\n" + "\n".join(preview_items) + f"\n\n"
                            f"💰 *Total Nilai Penawaran*: `Rp {total_val:,.0f}`\n"
                            f"📎 *File Lampiran*: `{file_name}` (Siap diunggah ke Honda)\n\n"
                            f"Apakah data hasil ekstraksi di atas sudah sesuai?"
                        )
                        confirm_buttons = {
                            "inline_keyboard": [
                                [{"text": "🚀 Ya, Kirim ke Honda", "callback_data": "confirm_submit"}],
                                [{"text": "❌ Batalkan", "callback_data": "cancel_action"}]
                            ]
                        }
                        send_message(chat_id, preview_card, reply_markup=confirm_buttons)
                        continue

        except Exception as e:
            logger.error(f"Error in Telegram polling loop: {e}")
            time.sleep(3)

def start_telegram_bot_background():
    t = threading.Thread(target=handle_telegram_updates, daemon=True)
    t.start()
    logger.info("Background thread Telegram Bot Phase 2 dengan Rich UI/UX berhasil dijalankan.")

if __name__ == "__main__":
    handle_telegram_updates()
