document.addEventListener('DOMContentLoaded', () => {
  // --- State & Elements ---
  let currentLang = 'en';

  const langTrigger = document.getElementById('langTrigger');
  const langMenu = document.getElementById('langMenu');
  const familyTrigger = document.getElementById('familyTrigger');
  const familyMenu = document.getElementById('familyMenu');
  const hamburgerBtn = document.getElementById('hamburgerBtn');
  const sideDrawer = document.getElementById('sideDrawer');
  const drawerOverlay = document.getElementById('drawerOverlay');
  const closeDrawer = document.getElementById('closeDrawer');

  const heroPrevBtn = document.getElementById('heroPrevBtn');
  const heroNextBtn = document.getElementById('heroNextBtn');
  const heroImg = document.querySelector('.hero-img');

  const loginForm = document.getElementById('loginForm');
  const userIdInput = document.getElementById('userId');
  const userPwdInput = document.getElementById('userPwd');
  const userOtpInput = document.getElementById('userOtp');
  const generateOtpBtn = document.getElementById('generateOtpBtn');
  const applyAccountBtn = document.getElementById('applyAccountBtn');
  const findIdPwBtn = document.getElementById('findIdPwBtn');
  const unlockAccountBtn = document.getElementById('unlockAccountBtn');
  const userGuideLink = document.getElementById('userGuideLink');
  const contactUsLink = document.getElementById('contactUsLink');
  const moreNoticeBtn = document.getElementById('moreNoticeBtn');

  // Modal elements
  const appModal = document.getElementById('appModal');
  const modalTitle = document.getElementById('modalTitle');
  const modalBody = document.getElementById('modalBody');
  const modalCloseBtn = document.getElementById('modalCloseBtn');
  const modalConfirmBtn = document.getElementById('modalConfirmBtn');

  // --- Nilai Default Testing untuk Kemudahan Pengguna ---
  userIdInput.value = 'D004002';
  userPwdInput.value = 'hyundai123!';

  // --- Helper: Open & Close Modal ---
  function showModal(title, contentHtml) {
    modalTitle.textContent = title;
    modalBody.innerHTML = contentHtml;
    appModal.classList.add('show');
    appModal.setAttribute('aria-hidden', 'false');
  }

  function closeModal() {
    appModal.classList.remove('show');
    appModal.setAttribute('aria-hidden', 'true');
  }

  modalCloseBtn.addEventListener('click', closeModal);
  modalConfirmBtn.addEventListener('click', closeModal);
  appModal.addEventListener('click', (e) => {
    if (e.target === appModal) closeModal();
  });

  // --- Dropdown Toggles ---
  langTrigger.addEventListener('click', (e) => {
    e.stopPropagation();
    langMenu.classList.toggle('show');
    familyMenu.classList.remove('show');
  });

  familyTrigger.addEventListener('click', (e) => {
    e.stopPropagation();
    familyMenu.classList.toggle('show');
    langMenu.classList.remove('show');
  });

  document.addEventListener('click', () => {
    langMenu.classList.remove('show');
    familyMenu.classList.remove('show');
  });

  // --- Side Drawer ---
  function openDrawer() {
    sideDrawer.classList.add('open');
    drawerOverlay.classList.add('show');
  }

  function hideDrawer() {
    sideDrawer.classList.remove('open');
    drawerOverlay.classList.remove('show');
  }

  hamburgerBtn.addEventListener('click', openDrawer);
  closeDrawer.addEventListener('click', hideDrawer);
  drawerOverlay.addEventListener('click', hideDrawer);

  // --- Tombol "Generate OTP": Mengambil QR Code & OTP dari Backend ---
  generateOtpBtn.addEventListener('click', async () => {
    try {
      generateOtpBtn.textContent = '...';
      const res = await fetch('/api/otp/setup-qr');
      const data = await res.json();

      // Isi input OTP dengan kode real-time saat ini
      userOtpInput.value = data.currentRealTimeOtp;

      showModal('Google Authenticator Setup & OTP', `
        <div style="text-align: center;">
          <p style="margin-bottom: 8px;"><strong>Scan QR Code ini dengan Google Authenticator di HP Anda:</strong></p>
          <img src="${data.qrImageUrl}" alt="Google Authenticator QR Code" style="width: 180px; height: 180px; border: 1px solid #ccc; padding: 4px; border-radius: 4px;">
          <p style="font-size: 11px; color: #666; margin-top: 6px;">Atau masukkan Secret Key manual: <code style="background:#eee; padding:2px 5px; font-weight:bold;">${data.secretKey}</code></p>
          
          <div style="margin-top: 15px; background: #eef3fb; padding: 10px; border-radius: 4px; border: 1px solid #ccdcee;">
            <p style="font-size: 12px; color: #555;">Kode 6-Digit Saat Ini (Berubah tiap 30 detik):</p>
            <span style="font-size: 24px; font-weight: bold; letter-spacing: 4px; color: #4f81bd;">${data.currentRealTimeOtp}</span>
          </div>
          <p style="font-size: 11px; color: #28a745; margin-top: 8px;">[✓] Kode telah diisi otomatis ke kolom OTP untuk memudahkan pengujian.</p>
        </div>
      `);
    } catch (err) {
      showModal('Error Koneksi Backend', '<p style="color:#c00;">Pastikan server backend lokal (server.js) sudah dijalankan pada port 3000.</p>');
    } finally {
      generateOtpBtn.textContent = 'Generate';
    }
  });

  // --- Submit Login ke Backend Server Nyata ---
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const userId = userIdInput.value.trim();
    const password = userPwdInput.value.trim();
    const otp = userOtpInput.value.trim();

    if (!userId || !password) {
      showModal('Login Diperlukan', '<p style="color: #c00;">Harap masukkan User ID dan Password.</p>');
      return;
    }

    if (!otp) {
      showModal('OTP Diperlukan', '<p>Harap masukkan kode Google Authenticator 6-Digit atau klik tombol <strong>Generate</strong>.</p>');
      return;
    }

    const loginBtn = document.getElementById('loginBtn');
    loginBtn.textContent = 'Verifying...';
    loginBtn.disabled = true;

    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, password, otp })
      });

      const result = await res.json();

      if (res.ok && result.status === 'success') {
        showModal('Autentikasi 2FA Sukses', `
          <div style="text-align: center; padding: 10px;">
            <div style="font-size: 32px; color: #28a745; margin-bottom: 8px;">✓</div>
            <p style="font-weight: bold; font-size: 14px; color: #2c3e50;">Selamat Datang, ${result.user.userId}</p>
            <p style="font-size: 12px; color: #666; margin-top: 4px;">${result.user.company}</p>
            <p style="font-size: 11px; color: #888; margin-top: 10px;">Mengalihkan ke Supplier Workspace...</p>
          </div>
        `);
        setTimeout(() => {
          window.location.href = result.redirectUrl;
        }, 1500);
      } else {
        showModal('Verifikasi Gagal', `
          <p style="color: #c0392b; font-weight: bold;">${result.message}</p>
          ${result.hint ? `<p style="font-size: 12px; color: #555; margin-top: 8px;">${result.hint}</p>` : ''}
        `);
      }
    } catch (err) {
      showModal('Error Server', '<p style="color: #c00;">Gagal menghubungi server lokal (http://localhost:3000). Pastikan backend aktif.</p>');
    } finally {
      loginBtn.textContent = 'Login';
      loginBtn.disabled = false;
    }
  });

  // Notice Click Modal
  document.querySelectorAll('.notice-row').forEach(row => {
    row.addEventListener('click', (e) => {
      e.preventDefault();
      const id = row.getAttribute('data-id');
      if (id === '1') {
        showModal('(Important) Apply Google OTP to HMG Partner site', `
          <p><strong>Penerapan Wajib Multi-Factor Authentication (Google OTP)</strong></p>
          <hr style="margin: 10px 0; border: 0; border-top: 1px solid #eee;">
          <p>Mulai Mei 2024, seluruh akun pemasok Hyundai wajib mengaktifkan Google Authenticator 2FA.</p>
          <p style="margin-top: 8px;">Gunakan tombol <strong>Generate</strong> pada form login untuk mendapatkan QR Code pendaftaran akun.</p>
        `);
      } else {
        showModal('Customer Specific Requirements (CSR) Manual 5th Edition', `
          <p><strong>Rilis Dokumen Mutu Hyundai Edisi ke-5 (HB-PD-MA-001)</strong></p>
          <hr style="margin: 10px 0; border: 0; border-top: 1px solid #eee;">
          <p>Telah dirilis manual mutu CSR edisi 5 yang memuat aturan baru terkait After Sales 10 Tahun, pelaporan ESG ke SCMS/SCEMS, dan 26 aturan perubahan 4M.</p>
        `);
      }
    });
  });
});
