with open('server.js', 'r', encoding='utf-8') as f:
    content = f.read()

new_routes = """
// ==============================================================================
// GPSYSTEM.ID ALIAS ROUTES (Menyamakan persis dengan URL live portal asli)
// ==============================================================================
app.get('/supplier/rfqs', (req, res) => {
  res.redirect('/honda_dashboard.html#rfqs');
});

app.get('/supplier/rfqs/:id', (req, res) => {
  res.redirect(`/honda_dashboard.html#rfq-detail-${req.params.id}`);
});

app.get('/supplier/quotations', (req, res) => {
  res.redirect('/honda_dashboard.html#quotations');
});

app.get('/supplier/pos', (req, res) => {
  res.redirect('/honda_dashboard.html#pos');
});

app.get('/supplier/pos/:id', (req, res) => {
  res.redirect(`/honda_dashboard.html#pos-detail-${req.params.id}`);
});

app.get('/supplier/shipping-docs', (req, res) => {
  res.redirect('/honda_dashboard.html#shipping-docs');
});

app.get('/supplier/invoice-lists', (req, res) => {
  res.redirect('/honda_dashboard.html#invoice-lists');
});

// API aliases
app.get('/api/v1/supplier/rfqs', (req, res) => {
  res.json({ status: 'success', total: HONDA_RFQ_DATABASE.length, data: HONDA_RFQ_DATABASE });
});

app.get('/api/v1/supplier/rfqs/:id', (req, res) => {
  const item = HONDA_RFQ_DATABASE.find(r => r.number === req.params.id) || HONDA_RFQ_DATABASE[0];
  res.json({ status: 'success', data: item });
});

app.get('/api/v1/supplier/pos', (req, res) => {
  const pos = [
    {
      id: "4831",
      poNumber: "PO-26A-009780",
      rfqNumber: "26A-009780",
      date: "08/11/2026",
      deliveryDate: "25/11/2026",
      buyer: "Erpan Maulana",
      department: "DIE CASTING",
      currency: "IDR",
      totalAmount: "18.500.000",
      status: "CONFIRMED",
      items: [
        { code: "EQT-01965-R00", name: "FLASHBACK ARRESTOR OXYGEN", qty: 5, uom: "Pce", price: 3700000 },
        { code: "EQT-01966-R00", name: "FLASHBACK ARRESTOR ACETYLENE", qty: 5, uom: "Pce", price: 3700000 },
        { code: "EQT-01967-R00", name: "FLASHBACK ARRESTOR LPG", qty: 2, uom: "Pce", price: 3700000 },
        { code: "EQT-01968-R00", name: "FLASHBACK ARRESTOR INERT GAS", qty: 2, uom: "Pce", price: 3700000 }
      ]
    },
    {
      id: "4830",
      poNumber: "PO-26A-009588",
      rfqNumber: "26A-009588",
      date: "03/11/2026",
      deliveryDate: "20/12/2026",
      buyer: "Erpan Maulana",
      department: "ALUMINIUM MACHINING",
      currency: "IDR",
      totalAmount: "31.876.000",
      status: "IN_PRODUCTION",
      items: [
        { code: "MAC-02996-R00", name: "CHECK VALVE CN-T03-1-11 NACHI", qty: 1, uom: "Pce", price: 5876000 },
        { code: "MAC-10441-R00", name: "PISTON PUMP PVS-1B-16N1-12 NACHI", qty: 1, uom: "Pce", price: 12500000 },
        { code: "MAC-10444-R00", name: "PISTON PUMP PVS-2B-35N1-U-12 NACHI", qty: 1, uom: "Pce", price: 13500000 }
      ]
    }
  ];
  res.json({ status: 'success', total: pos.length, data: pos });
});

app.get('/api/v1/supplier/shipping-docs', (req, res) => {
  const docs = [
    {
      doNumber: "DO-2026-HPPM-0089",
      poNumber: "PO-26A-009588",
      shippingDate: "10/11/2026",
      carrier: "Armada Logistik Sendiri (Truk Box B-9821-K)",
      destination: "PT. HPPM Karawang Plant 1 (Dock 3)",
      status: "SHIPPED",
      itemsCount: 3
    }
  ];
  res.json({ status: 'success', total: docs.length, data: docs });
});

app.get('/api/v1/supplier/invoice-lists', (req, res) => {
  const invoices = [
    {
      invoiceNumber: "INV-2026-0045",
      fakturPajak: "010.000-26.00001892",
      poNumber: "PO-26A-009588",
      amount: "35.382.360",
      ppn: "3.506.360",
      dueDate: "31/12/2026",
      status: "VERIFIED_SAP",
      paymentTerms: "End Of Next Month"
    }
  ];
  res.json({ status: 'success', total: invoices.length, data: invoices });
});
"""

if "GPSYSTEM.ID ALIAS ROUTES" not in content:
    content = content.replace("app.listen(PORT,", new_routes + "\napp.listen(PORT,")
    with open('server.js', 'w', encoding='utf-8') as f:
        f.write(content)
    print("ROUTES UPDATED!")
else:
    print("ROUTES ALREADY EXIST!")

