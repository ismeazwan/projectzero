import os
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors

os.makedirs("assets/rfq_docs", exist_ok=True)

def create_hyundai_rfq():
    path = "assets/rfq_docs/Hyundai_RFQ_Creta_EV_2027.pdf"
    doc = SimpleDocTemplate(path, pagesize=A4, rightMargin=36, leftMargin=36, topMargin=36, bottomMargin=36)
    styles = getSampleStyleSheet()
    story = []

    title_style = ParagraphStyle('TitleStyle', parent=styles['Heading1'], fontSize=16, leading=20, textColor=colors.HexColor('#002c5f'), alignment=1)
    subtitle_style = ParagraphStyle('SubStyle', parent=styles['Normal'], fontSize=10, leading=14, textColor=colors.HexColor('#444444'), alignment=1)
    h2_style = ParagraphStyle('H2Style', parent=styles['Heading2'], fontSize=12, leading=16, textColor=colors.HexColor('#002c5f'), spaceBefore=10, spaceAfter=6)
    body_style = ParagraphStyle('BodyStyle', parent=styles['Normal'], fontSize=9, leading=13)

    story.append(Paragraph("<b>HYUNDAI MOTOR MANUFACTURING INDONESIA (HMMI)</b>", title_style))
    story.append(Paragraph("PROCUREMENT & SOURCING DIVISION • CIKARANG PLANT", subtitle_style))
    story.append(Spacer(1, 10))
    story.append(Paragraph("<b>OFFICIAL REQUEST FOR QUOTATION (RFQ)</b>", ParagraphStyle('RFQBolder', parent=title_style, fontSize=13, textColor=colors.HexColor('#d63939'))))
    story.append(Spacer(1, 12))

    # Meta Table
    meta_data = [
        [Paragraph("<b>RFQ Document No:</b>", body_style), Paragraph("HMMI-RFQ-2026-SU2id-041", body_style), Paragraph("<b>Date Issued:</b>", body_style), Paragraph("08 November 2026", body_style)],
        [Paragraph("<b>Target Program:</b>", body_style), Paragraph("All New Creta EV (SU2id EV)", body_style), Paragraph("<b>Target SOP Date:</b>", body_style), Paragraph("Q1 2027", body_style)],
        [Paragraph("<b>Part Name:</b>", body_style), Paragraph("Front Brake Caliper & Pad Assembly", body_style), Paragraph("<b>Part Number:</b>", body_style), Paragraph("58101-SU200", body_style)],
        [Paragraph("<b>Estimated Annual Usage:</b>", body_style), Paragraph("45,000 Sets / Year (5-Year Lifecycle)", body_style), Paragraph("<b>Submission Deadline:</b>", body_style), Paragraph("<b>15 Desember 2026 (17:00 WIB)</b>", body_style)],
    ]
    t = Table(meta_data, colWidths=[120, 150, 110, 140])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#f8f9fa')),
        ('BOX', (0,0), (-1,-1), 1, colors.HexColor('#cccccc')),
        ('INNERGRID', (0,0), (-1,-1), 0.5, colors.HexColor('#e0e0e0')),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('TOPPADDING', (0,0), (-1,-1), 5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
    ]))
    story.append(t)
    story.append(Spacer(1, 14))

    story.append(Paragraph("1. SCOPE OF SOURCING & TECHNICAL SPECIFICATIONS", h2_style))
    story.append(Paragraph("Supplier is invited to submit a competitive commercial and engineering quotation for the manufacturing and delivery of Front Brake Caliper & Pad Assembly for the localized Creta EV program. Sourcing is strictly open for Tier-1 suppliers certified with IATF 16949:2016.", body_style))
    story.append(Spacer(1, 6))
    story.append(Paragraph("• Material Standard: Hyundai Motor Engineering Standard MS 263-04 (High Heat Resistant Ductile Iron).<br/>"
                           "• Drawing Number: DWG-HMC-58101-REV-02 (Refer to attached 3D CAD step file in GSCM).<br/>"
                           "• Delivery Destination: HMMI Cikarang Plant (Line 2 Assembly - EV Section).<br/>"
                           "• Quality Gate: 0 PPM Defect Target during pre-production pilot builds (P1 & P2).", body_style))
    story.append(Spacer(1, 10))

    story.append(Paragraph("2. CUSTOMER SPECIFIC REQUIREMENTS (CSR 5TH EDITION)", h2_style))
    story.append(Paragraph("In accordance with HMB CSR Manual 5th Edition (HB-PD-MA-001):<br/>"
                           "<b>Clause 7.24 (After-Sales Supply Obligation):</b> Supplier must guarantee spare parts availability for 10 consecutive years after End of Production (EOP).<br/>"
                           "<b>Clause 9.1-9.4 (Sustainability & ESG):</b> Scope 1 & Scope 2 greenhouse gas emissions data must be reported to the SCEMS platform prior to final contract award.", body_style))
    story.append(Spacer(1, 10))

    story.append(Paragraph("3. QUOTATION SUBMISSION CHECKLIST", h2_style))
    story.append(Paragraph("Supplier must upload the following signed documents via Hyundai Partner Portal (partner.hyundai.com):<br/>"
                           "1. Standard Cost Breakdown (CBD) Sheet (Material, Machine Cycle, Labor, Tooling/Die, SG&A).<br/>"
                           "2. Tooling & Gauge Investment Proposal (Dies, Jigs, CMM fixture).<br/>"
                           "3. Quality Assurance Plan & Preliminary Control Plan.<br/>"
                           "4. Production Capacity Simulation based on peak 4,200 sets/month.", body_style))
    story.append(Spacer(1, 14))

    story.append(Paragraph("<i>Authorized by: HMMI Purchasing Committee • PT Hyundai Motor Manufacturing Indonesia</i>", ParagraphStyle('Footer', parent=styles['Italic'], fontSize=8, textColor=colors.HexColor('#666666'), alignment=1)))
    doc.build(story)
    print("Created:", path)

def create_honda_rfq():
    path = "assets/rfq_docs/Honda_RFQ_CRV_eHEV_2027.pdf"
    doc = SimpleDocTemplate(path, pagesize=A4, rightMargin=36, leftMargin=36, topMargin=36, bottomMargin=36)
    styles = getSampleStyleSheet()
    story = []

    title_style = ParagraphStyle('TitleStyle', parent=styles['Heading1'], fontSize=16, leading=20, textColor=colors.HexColor('#cc0000'), alignment=1)
    subtitle_style = ParagraphStyle('SubStyle', parent=styles['Normal'], fontSize=10, leading=14, textColor=colors.HexColor('#444444'), alignment=1)
    h2_style = ParagraphStyle('H2Style', parent=styles['Heading2'], fontSize=12, leading=16, textColor=colors.HexColor('#cc0000'), spaceBefore=10, spaceAfter=6)
    body_style = ParagraphStyle('BodyStyle', parent=styles['Normal'], fontSize=9, leading=13)

    story.append(Paragraph("<b>PT HONDA PROSPECT MOTOR (HPM)</b>", title_style))
    story.append(Paragraph("PURCHASING & STRATEGIC SOURCING DEPARTMENT • KARAWANG FACTORY", subtitle_style))
    story.append(Spacer(1, 10))
    story.append(Paragraph("<b>REQUEST FOR QUOTATION (RFQ) - NEW SOURCING PACKAGE</b>", ParagraphStyle('RFQBolder', parent=title_style, fontSize=13, textColor=colors.HexColor('#206bc4'))))
    story.append(Spacer(1, 12))

    meta_data = [
        [Paragraph("<b>RFQ Package ID:</b>", body_style), Paragraph("HPM-RFQ-2026-3A0-019", body_style), Paragraph("<b>Issued Date:</b>", body_style), Paragraph("08 November 2026", body_style)],
        [Paragraph("<b>Model Platform:</b>", body_style), Paragraph("All New CR-V e:HEV (RS Series)", body_style), Paragraph("<b>Mass Production SOP:</b>", body_style), Paragraph("November 2027", body_style)],
        [Paragraph("<b>Part Description:</b>", body_style), Paragraph("Rear Brake Disc & Caliper Carrier", body_style), Paragraph("<b>Part Number:</b>", body_style), Paragraph("42200-3A0-A01", body_style)],
        [Paragraph("<b>Target Volume (EAU):</b>", body_style), Paragraph("36,000 Sets / Year (Local Content >= 65%)", body_style), Paragraph("<b>Quotation Deadline:</b>", body_style), Paragraph("<b>20 Desember 2026 (15:00 WIB)</b>", body_style)],
    ]
    t = Table(meta_data, colWidths=[120, 150, 110, 140])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#f8f9fa')),
        ('BOX', (0,0), (-1,-1), 1, colors.HexColor('#cccccc')),
        ('INNERGRID', (0,0), (-1,-1), 0.5, colors.HexColor('#e0e0e0')),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('TOPPADDING', (0,0), (-1,-1), 5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
    ]))
    story.append(t)
    story.append(Spacer(1, 14))

    story.append(Paragraph("1. PROCUREMENT OBJECTIVE & DELIVERABLES", h2_style))
    story.append(Paragraph("PT Honda Prospect Motor invites qualified Tier-1 automotive suppliers to submit commercial and technical quotations for the Rear Brake Disc & Knuckle Carrier Sub-Assy for CR-V e:HEV hybrid platform assembled at Karawang Plant 2.", body_style))
    story.append(Spacer(1, 6))
    story.append(Paragraph("• Honda Engineering Standard: HES D 2005 / HES C 206 (Low Noise, High Thermal Stability).<br/>"
                           "• Surface Treatment: Geomet / Dacromet Anti-Corrosion (min 720 hours Salt Spray Test).<br/>"
                           "• Delivery Requirement: JIT (Just-In-Time) Kanban delivery to HPM Karawang Gate C.<br/>"
                           "• Target Piece Price: Max IDR 485,000 / Set (excluding tooling amortisation).", body_style))
    story.append(Spacer(1, 10))

    story.append(Paragraph("2. QUALITY & GREEN PURCHASING REQUIREMENTS (H-SQM 2026.4)", h2_style))
    story.append(Paragraph("Supplier must comply with Honda Supplier Quality Manual (H-SQM) Revision 2026.4:<br/>"
                           "• Mandatory CMM 3D coordinate inspection capability with automated SPC data logging.<br/>"
                           "• ESG Carbon Transparency: Submission of Product Carbon Footprint (PCF) declaration in kgCO2e/part.", body_style))
    story.append(Spacer(1, 10))

    story.append(Paragraph("3. SUBMISSION GUIDELINES VIA GPSYSTEM.ID", h2_style))
    story.append(Paragraph("Quotation submission must be completed through the Honda Global Partner System (https://gpsystem.id) prior to closing deadline. Late submissions will result in disqualification from the 2027 Model Year vendor panel.", body_style))
    story.append(Spacer(1, 14))

    story.append(Paragraph("<i>Issued by: Procurement Division • PT Honda Prospect Motor Karawang Factory</i>", ParagraphStyle('Footer', parent=styles['Italic'], fontSize=8, textColor=colors.HexColor('#666666'), alignment=1)))
    doc.build(story)
    print("Created:", path)

if __name__ == '__main__':
    create_hyundai_rfq()
    create_honda_rfq()

