import os
from reportlab.lib.pagesizes import A4, landscape
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors

os.makedirs("assets/rfq_docs", exist_ok=True)

def generate_exact_honda_rfq_pdf():
    pdf_path = "assets/rfq_docs/RFQ_26A-009588_PT_APSINDO_GANANCIA_PERKASA.pdf"
    
    # Use landscape A4 to match the screenshot aspect ratio
    doc = SimpleDocTemplate(
        pdf_path,
        pagesize=landscape(A4),
        leftMargin=24,
        rightMargin=24,
        topMargin=20,
        bottomMargin=20
    )
    
    styles = getSampleStyleSheet()
    
    honda_red = colors.HexColor('#cc0000')
    honda_blue = colors.HexColor('#003366')
    navy_header = colors.HexColor('#004080')
    light_border = colors.HexColor('#004080')
    
    title_honda = ParagraphStyle('HondaTitle', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=18, textColor=honda_red, leading=20)
    slogan_style = ParagraphStyle('HondaSlogan', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=10, textColor=colors.black, leading=12)
    slogan_sub = ParagraphStyle('HondaSub', parent=styles['Normal'], fontName='Helvetica', fontSize=7, textColor=colors.HexColor('#555555'), leading=9)
    company_style = ParagraphStyle('CompanyStyle', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=12, textColor=colors.black, leading=15)
    
    th_style = ParagraphStyle('THStyle', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=8, textColor=colors.white, alignment=1)
    td_style = ParagraphStyle('TDStyle', parent=styles['Normal'], fontName='Helvetica', fontSize=8, textColor=colors.black, leading=10)
    td_bold = ParagraphStyle('TDBold', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=8, textColor=colors.black, leading=10)
    td_center = ParagraphStyle('TDCenter', parent=styles['Normal'], fontName='Helvetica', fontSize=8, textColor=colors.black, alignment=1)
    
    story = []
    
    # 1. Header Row: Logo & Slogan (Left) + Request for Quotation Box (Right)
    left_header = [
        [Paragraph("<b>HONDA</b>", title_honda), Paragraph("<b>How we move you.</b><br/><font size='6' color='#666'>CREATE &gt; TRANSCEND, AUGMENT</font>", slogan_style)],
        [Paragraph("The Power of Dreams", ParagraphStyle('Pod', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=7, textColor=colors.black)), Paragraph("", slogan_style)],
        [Paragraph("<b>PT. Honda Precision Parts Manufacturing</b>", company_style), Paragraph("", slogan_style)]
    ]
    t_left = Table(left_header, colWidths=[110, 200])
    t_left.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('TOPPADDING', (0,0), (-1,-1), 1),
        ('BOTTOMPADDING', (0,0), (-1,-1), 1),
    ]))
    
    # Right Box: REQUEST FOR QUOTATION + Table
    rfq_title_p = Paragraph("<b>REQUEST FOR QUOTATION</b>", ParagraphStyle('RfqBig', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=16, textColor=navy_header, alignment=1))
    rfq_table_data = [
        [Paragraph("R.F.Q NUMBER", td_center), Paragraph("REV", td_center), Paragraph("DATE", td_center)],
        [Paragraph("<b>26A-009588</b>", td_center), Paragraph("0", td_center), Paragraph("29-10-2026", td_center)]
    ]
    t_rfq_box = Table(rfq_table_data, colWidths=[100, 40, 80])
    t_rfq_box.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), navy_header),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('INNERGRID', (0,0), (-1,-1), 0.5, navy_header),
        ('BOX', (0,0), (-1,-1), 1, navy_header),
        ('TOPPADDING', (0,0), (-1,-1), 2),
        ('BOTTOMPADDING', (0,0), (-1,-1), 2),
    ]))
    
    top_row = [
        [t_left, Paragraph("", styles['Normal']), t_rfq_box]
    ]
    t_top = Table(top_row, colWidths=[400, 170, 224])
    t_top.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('ALIGN', (2,0), (2,0), 'RIGHT'),
    ]))
    story.append(t_top)
    story.append(Spacer(1, 8))
    
    # 2. Section SUPPLIER (Left) vs CONDITION (Right)
    left_grid_data = [
        [Paragraph("<b>SUPPLIER</b>", th_style), Paragraph("", th_style)],
        [Paragraph("<b>5100025127 - PT APSINDO GANANCIA PERKASA</b><br/>JL.KELAPA GADING SELATAN BH.10/27 GADING SERPONG, TANGERANG, 99999, ID<br/>021-5470968", td_style), Paragraph("", td_style)],
        [Paragraph("BUYER", td_bold), Paragraph("Erpan Maulana", td_style)],
        [Paragraph("REQUESTER NAME", td_bold), Paragraph("LIA YULIANTI", td_style)],
        [Paragraph("USER NAME", td_bold), Paragraph("FAH RIANSYAH", td_style)],
        [Paragraph("DEPT REQUESTER", td_bold), Paragraph("ALUMINIUM MACHINING", td_style)],
    ]
    t_supplier = Table(left_grid_data, colWidths=[130, 260])
    t_supplier.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), navy_header),
        ('SPAN', (0,0), (1,0)),
        ('SPAN', (0,1), (1,1)),
        ('BACKGROUND', (0,2), (0,-1), colors.HexColor('#f0f4f8')),
        ('BOX', (0,0), (-1,-1), 1, light_border),
        ('INNERGRID', (0,0), (-1,-1), 0.5, light_border),
        ('TOPPADDING', (0,0), (-1,-1), 2.5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 2.5),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
    ]))
    
    right_grid_data = [
        [Paragraph("<b>CONDITION</b>", th_style), Paragraph("", th_style)],
        [Paragraph("P.R. NO.", td_bold), Paragraph("26-A2212600-10A-0985-01", td_style)],
        [Paragraph("PR CATEGORY", td_bold), Paragraph("NORMAL", td_style)],
        [Paragraph("ITEM TYPE", td_bold), Paragraph("GOODS", td_style)],
        [Paragraph("BONDED ZONE", td_bold), Paragraph("FACILITY", td_style)],
        [Paragraph("EXPECTED DELIVERY DATE", td_bold), Paragraph("<b>20-12-2026</b>", td_style)],
        [Paragraph("ESTIMATE DATE (QUOTATION)", td_bold), Paragraph("<b>29-11-2026</b>", td_style)],
    ]
    t_condition = Table(right_grid_data, colWidths=[150, 244])
    t_condition.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), navy_header),
        ('SPAN', (0,0), (1,0)),
        ('BACKGROUND', (0,1), (0,-1), colors.HexColor('#f0f4f8')),
        ('BOX', (0,0), (-1,-1), 1, light_border),
        ('INNERGRID', (0,0), (-1,-1), 0.5, light_border),
        ('TOPPADDING', (0,0), (-1,-1), 2.5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 2.5),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
    ]))
    
    two_col = [
        [t_supplier, t_condition]
    ]
    t_middle = Table(two_col, colWidths=[395, 399])
    t_middle.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('LEFTPADDING', (0,0), (-1,-1), 0),
        ('RIGHTPADDING', (0,0), (-1,-1), 0),
        ('TOPPADDING', (0,0), (-1,-1), 0),
        ('BOTTOMPADDING', (0,0), (-1,-1), 0),
    ]))
    story.append(t_middle)
    story.append(Spacer(1, 8))
    
    # 3. Items Table
    items_header = [
        Paragraph("Code", th_style),
        Paragraph("Product Description", th_style),
        Paragraph("Purchase Type", th_style),
        Paragraph("Additional Descriptions", th_style),
        Paragraph("Qty", th_style),
        Paragraph("UOM", th_style)
    ]
    
    items_rows = [
        items_header,
        [Paragraph("MAC-02996-R00", td_style), Paragraph("CHECK VALVE CN-T03-1-11 NACHI", td_style), Paragraph("PURCHASE", td_center), Paragraph("-", td_center), Paragraph("1", td_center), Paragraph("Pce", td_center)],
        [Paragraph("MAC-10441-R00", td_style), Paragraph("PISTON PUMP PVS-1B-16N1-12 NACHI", td_style), Paragraph("PURCHASE", td_center), Paragraph("-", td_center), Paragraph("1", td_center), Paragraph("Pce", td_center)],
        [Paragraph("MAC-10444-R00", td_style), Paragraph("PISTON PUMP PVS-2B-35N1-U-12 NACHI", td_style), Paragraph("PURCHASE", td_center), Paragraph("-", td_center), Paragraph("1", td_center), Paragraph("Pce", td_center)],
    ]
    
    t_items = Table(items_rows, colWidths=[100, 290, 110, 174, 60, 60])
    t_items.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), navy_header),
        ('BOX', (0,0), (-1,-1), 1, light_border),
        ('INNERGRID', (0,0), (-1,-1), 0.5, light_border),
        ('TOPPADDING', (0,0), (-1,-1), 4),
        ('BOTTOMPADDING', (0,0), (-1,-1), 4),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
    ]))
    story.append(t_items)
    
    doc.build(story)
    print("Exact PDF Generated at:", pdf_path)

if __name__ == '__main__':
    generate_exact_honda_rfq_pdf()

