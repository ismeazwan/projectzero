import http.server
import socketserver
import urllib.parse
import urllib.request
import json
import threading

PORT = 8085
CLIENT_ID = 'iamcli_3KeK8docLctYxdqmXkXUIBSFhMo'
REDIRECT_URI = f'http://localhost:{PORT}/oauth/callback'
RESOURCE = 'https://mcp.ngrok.com/mcp'

received_code = None
code_verifier = None

class OAuthCallbackHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        global received_code
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path == '/oauth/callback':
            query = urllib.parse.parse_qs(parsed.query)
            code = query.get('code', [None])[0]
            if code:
                received_code = code
                self.send_response(200)
                self.send_header('Content-Type', 'text/html; charset=utf-8')
                self.end_headers()
                self.wfile.write(b'<h2>[OK] Otorisasi ngrok Berhasil!</h2><p>Kode otorisasi berhasil diterima. Anda dapat menutup tab ini.</p>')
                print(f'\n[+] Kode Otorisasi Diterima: {code}')
            else:
                error = query.get('error', ['Unknown error'])[0]
                self.send_response(400)
                self.send_header('Content-Type', 'text/html; charset=utf-8')
                self.end_headers()
                self.wfile.write(f'<h2>Error: {error}</h2>'.encode('utf-8'))
        else:
            self.send_response(404)
            self.end_headers()

def run_callback_listener(verifier, timeout=120):
    global code_verifier, received_code
    code_verifier = verifier
    
    with socketserver.TCPServer(('127.0.0.1', PORT), OAuthCallbackHandler) as httpd:
        httpd.timeout = 1
        print(f'[*] Listener OAuth aktif di port {PORT}...')
        start_time = threading.Event()
        import time
        t_end = time.time() + timeout
        while time.time() < t_end and not received_code:
            httpd.handle_request()

    if received_code:
        print('[*] Menukar kode dengan Access Token dari ngrok...')
        token_url = 'https://login.ngrok.com/token'
        token_data = urllib.parse.urlencode({
            'grant_type': 'authorization_code',
            'client_id': CLIENT_ID,
            'code': received_code,
            'redirect_uri': REDIRECT_URI,
            'code_verifier': code_verifier,
            'resource': RESOURCE
        }).encode('utf-8')

        req = urllib.request.Request(token_url, data=token_data, headers={'Content-Type': 'application/x-www-form-urlencoded'})
        try:
            with urllib.request.urlopen(req) as resp:
                token_resp = json.loads(resp.read().decode('utf-8'))
                print('[✓] ACCESS TOKEN NGROK BERHASIL DIDAPATKAN!')
                with open('ngrok_token.json', 'w') as f:
                    json.dump(token_resp, f, indent=2)
                return token_resp
        except Exception as e:
            print('[-] Gagal menukar token:', e)
            if hasattr(e, 'read'):
                print(e.read().decode('utf-8', errors='ignore'))
    else:
        print('[-] Timeout menunggu otorisasi.')

if __name__ == '__main__':
    import sys
    verifier = sys.argv[1] if len(sys.argv) > 1 else 'TR7NbufTkS_ldd_qNAK1tD3Q65UQKrzgWYRTRTz9z3s'
    run_callback_listener(verifier)

