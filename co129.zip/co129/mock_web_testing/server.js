const express = require('express');
const cors = require('cors');
const qrcode = require('qrcode');
const crypto = require('crypto');
const path = require('path');
const { exec } = require('child_process');
const fs = require('fs');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Sajikan file statis di folder co129
app.use(express.static(__dirname));

// --- KREDENSIAL MOCK TESTING ---
const TEST_ACCOUNT = {
  userId: 'D004002',
  password: 'hyundai123!',
  totpSecret: 'JBSWY3DPEHPK3PXP', // Base32 RFC 3548 / Google Authenticator
  companyName: 'PT. Manufaktur Komponen Otomotif Indonesia (Tier-1 Supplier)'
};

// --- IMPLEMENTASI RFC 6238 TOTP (GOOGLE AUTHENTICATOR) ---
function base32Decode(base32) {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  let bits = 0;
  let value = 0;
  const output = [];

  for (let i = 0; i < base32.length; i++) {
    const val = alphabet.indexOf(base32[i].toUpperCase());
    if (val === -1) continue;
    value = (value << 5) | val;
    bits += 5;
    if (bits >= 8) {
      output.push((value >>> (bits - 8)) & 255);
      bits -= 8;
    }
  }
  return Buffer.from(output);
}

function generateTOTP(secretBase32, timeOffset = 0, timeStep = 30) {
  const key = base32Decode(secretBase32);
  const epoch = Math.floor(Date.now() / 1000) + timeOffset;
  const counter = Math.floor(epoch / timeStep);

  const buf = Buffer.alloc(8);
  buf.writeBigUInt64BE(BigInt(counter));

  const hmac = crypto.createHmac('sha1', key);
  hmac.update(buf);
  const digest = hmac.digest();

  const offset = digest[digest.length - 1] & 0xf;
  const code = (
    ((digest[offset] & 0x7f) << 24) |
    ((digest[offset + 1] & 0xff) << 16) |
    ((digest[offset + 2] & 0xff) << 8) |
    (digest[offset + 3] & 0xff)
  ) % 1000000;

  return code.toString().padStart(6, '0');
}

function verifyTOTP(token, secretBase32) {
  const cleanToken = token.toString().trim();
  const validCodes = [
    generateTOTP(secretBase32, 0),
    generateTOTP(secretBase32, -30),
    generateTOTP(secretBase32, 30)
  ];
  return validCodes.includes(cleanToken);
}

// 1. ENDPOINT: SETUP QR CODE GOOGLE AUTH
app.get('/api/otp/setup-qr', async (req, res) => {
  try {
    const label = encodeURIComponent(`HMG Partner:${TEST_ACCOUNT.userId}`);
    const issuer = encodeURIComponent('Hyundai Motor Group');
    const otpauth = `otpauth://totp/${label}?secret=${TEST_ACCOUNT.totpSecret}&issuer=${issuer}`;

    const qrImageUrl = await qrcode.toDataURL(otpauth);
    const currentOtp = generateTOTP(TEST_ACCOUNT.totpSecret);

    res.json({
      status: 'success',
      userId: TEST_ACCOUNT.userId,
      secretKey: TEST_ACCOUNT.totpSecret,
      currentRealTimeOtp: currentOtp,
      qrImageUrl: qrImageUrl,
      otpauthUri: otpauth
    });
  } catch (error) {
    res.status(500).json({ status: 'error', message: error.message });
  }
});

// 2. ENDPOINT: LOGIN & VERIFIKASI 2FA OTP
app.post('/api/login', (req, res) => {
  const { userId, password, otp } = req.body;

  if (userId !== TEST_ACCOUNT.userId || password !== TEST_ACCOUNT.password) {
    return res.status(401).json({
      status: 'failed',
      errorType: 'INVALID_CREDENTIALS',
      message: 'Kredensial User ID atau Password salah.'
    });
  }

  if (!otp || !verifyTOTP(otp, TEST_ACCOUNT.totpSecret)) {
    const current = generateTOTP(TEST_ACCOUNT.totpSecret);
    return res.status(401).json({
      status: 'failed',
      errorType: 'INVALID_OTP',
      message: 'Kode OTP tidak cocok atau sudah kedaluwarsa.',
      hint: `Kode OTP aktif saat ini: ${current}`
    });
  }

  const sessionToken = 'HMG_TOKEN_' + Date.now();
  res.json({
    status: 'success',
    message: 'Login Berhasil.',
    token: sessionToken,
    user: {
      userId: TEST_ACCOUNT.userId,
      company: TEST_ACCOUNT.companyName
    },
    redirectUrl: '/dashboard.html'
  });
});

// 3. ENDPOINT: DATA OPERASIONAL DASHBOARD (HYUNDAI)
app.get('/api/dashboard-data', (req, res) => {
  res.json({
    status: 'success',
    timestamp: new Date().toISOString(),
    oem: 'Hyundai Motor Group (HMB & Mobis)',
    bulletins: [
      {
        id: 'NOT-2026-001',
        title: 'Customer Specific Requirements (CSR) Manual 5th Edition Released',
        docNo: 'HB-PD-MA-001',
        effectiveDate: '2026-12-19',
        urgency: 'HIGH',
        summaryNotice: 'Kewajiban After Sales 10 Tahun (Klausul 7.24) & Pelaporan ESG/GHG Scope 1-2 ke SCEMS (Klausul 9.1-9.4).'
      },
      {
        id: 'NOT-2026-002',
        title: 'Mandatory Multi-Factor Authentication (Google OTP) Rollout',
        docNo: 'SEC-2024-MFA',
        effectiveDate: '2024-05-17',
        urgency: 'CRITICAL',
        summaryNotice: 'Login wajib menggunakan Google Authenticator per akun individual.'
      }
    ],
    purchaseOrders: [
      {
        poNumber: 'PO-HMC-2026-8891',
        partNumber: '58101-GI000',
        partName: 'Front Brake Pad Assembly',
        quantity: 1200,
        unit: 'PCS',
        deliveryDate: '2026-11-18',
        destinationPlant: 'Hyundai Plant Cikarang (Line 2)',
        confirmationStatus: 'PENDING_CONFIRMATION',
        remainingHours: 14
      },
      {
        poNumber: 'PO-MOBIS-2026-3412',
        partNumber: '86511-GI100',
        partName: 'Bumper Cover Front',
        quantity: 450,
        unit: 'PCS',
        deliveryDate: '2026-11-20',
        destinationPlant: 'Mobis Parts Redistribution Center',
        confirmationStatus: 'CONFIRMED',
        remainingHours: 0
      }
    ]
  });
});

// =========================================================================
// 4. ENDPOINT BARU: DIPANGGIL OLEH n8n UNTUK MENJALANKAN SCRAPING OTOMATIS
// =========================================================================
app.post('/api/run-scrape', (req, res) => {
  console.log('[*] Permintaan scraping diterima dari n8n...');
  const scriptPath = path.join(__dirname, 'test_playwright_e2e.py');

  exec(`python "${scriptPath}"`, (error, stdout, stderr) => {
    if (error) {
      console.error('[-] Error saat menjalankan Playwright scraper:', error);
      return res.status(500).json({ status: 'error', message: error.message, stderr });
    }

    const resultFile = path.join(__dirname, 'test_scrape_result.json');
    if (fs.existsSync(resultFile)) {
      try {
        const fileContent = JSON.parse(fs.readFileSync(resultFile, 'utf8'));
        console.log('[+] Scraping selesai! Mengembalikan data ke n8n.');
        return res.json({
          status: 'success',
          executionOutput: stdout,
          data: fileContent
        });
      } catch (parseErr) {
        return res.status(500).json({ status: 'error', message: 'Gagal parse JSON hasil scraper' });
      }
    } else {
      res.status(500).json({ status: 'error', message: 'File output scraper tidak ditemukan.' });
    }
  });
});

// 5. ENDPOINT HONDA GPS (GLOBAL PARTNER SYSTEM)
app.post('/api/honda/login', (req, res) => {
  const { nik, password } = req.body;
  if (!nik || !password) {
    return res.status(400).json({ status: 'error', message: 'NIK/Email dan Password wajib diisi.' });
  }

  return res.json({
    status: 'success',
    message: 'Login Honda GPS Berhasil.',
    token: 'HONDA_GPS_TOKEN_' + Date.now(),
    vendor: {
      code: 'V-HPM-9921',
      name: 'PT. Manufaktur Komponen Otomotif Indonesia',
      role: 'Tier-1 Powertrain & Chassis Supplier'
    },
    redirectUrl: '/honda_dashboard.html'
  });
});

app.get('/api/honda/dashboard-data', (req, res) => {
  res.json({
    status: 'success',
    timestamp: new Date().toISOString(),
    oem: 'Honda e-Supplier Network (PT Honda Prospect Motor & AHM)',
    vendorInfo: {
      vendorCode: 'V-HPM-9921',
      vendorName: 'PT. Manufaktur Komponen Otomotif Indonesia',
      plantAssigned: 'PT HPM Karawang Plant 1 & 2'
    },
    kpis: {
      totalActivePOs: 12,
      criticalConfirmation: 1,
      onTimeDeliveryRate: 99.4,
      defectPPM: 8
    },
    bulletins: [
      {
        id: 'H-SQM-2026-11',
        title: 'Pemberlakuan H-SQM (Honda Supplier Quality Manual) Rev 2026.4',
        docNo: 'HPM-QA-2026-44',
        date: '2026-11-05',
        category: 'Quality & ESG Requirement',
        summaryNotice: 'Seluruh tier-1 supplier wajib mengunggah sertifikat kalibrasi CMM dan data jejak karbon per part sebelum akhir Q4 2026.'
      },
      {
        id: 'H-LOG-2026-08',
        title: 'Honda Standard Pallet Barcode & QR ASN Specification v3.1',
        docNo: 'HPM-LOG-2026-02',
        date: '2026-10-28',
        category: 'Logistics Standard',
        summaryNotice: 'Wajib menerapkan QR Code pallet format C39 terintegrasi sistem barcode scanner gate Karawang Plant 1 & 2.'
      }
    ],
    purchaseOrders: [
      {
        poNumber: 'PO-HPM-2026-4419',
        model: 'All New CR-V e:HEV (RS)',
        partNo: '42200-3A0-A01',
        partName: 'Rear Brake Disc & Caliper Carrier',
        quantity: 480,
        unit: 'PCS',
        orderDate: '2026-11-08',
        deliveryDueDate: '2026-11-09 09:00:00',
        remainingHours: 5,
        deliveryDestination: 'PT HPM Karawang Plant 2 (Gate C)',
        status: 'PENDING_CONFIRMATION',
        priority: 'CRITICAL'
      },
      {
        poNumber: 'PO-HPM-2026-4402',
        model: 'Honda WR-V & BR-V (DG3)',
        partNo: '51210-TG4-T00',
        partName: 'Front Knuckle & Hub Sub-Assy',
        quantity: 960,
        unit: 'PCS',
        orderDate: '2026-11-08',
        deliveryDueDate: '2026-11-09 14:00:00',
        remainingHours: 20,
        deliveryDestination: 'PT HPM Karawang Plant 1 (Gate A)',
        status: 'APPROVED',
        priority: 'HIGH'
      },
      {
        poNumber: 'PO-HPM-2026-4395',
        model: 'Honda Brio Satya & RS',
        partNo: '17220-RB6-Z00',
        partName: 'Air Cleaner Element & Intake Bracket',
        quantity: 2500,
        unit: 'PCS',
        orderDate: '2026-11-07',
        deliveryDueDate: '2026-11-10 10:00:00',
        remainingHours: 42,
        deliveryDestination: 'PT HPM Karawang Plant 1 (Gate B)',
        status: 'IN_TRANSIT',
        priority: 'NORMAL'
      },
      {
        poNumber: 'PO-HPM-2026-4388',
        model: 'All New HR-V (RV3)',
        partNo: '50820-T7A-003',
        partName: 'Engine Mounting Side Bracket Sub-Assy',
        quantity: 750,
        unit: 'PCS',
        orderDate: '2026-11-06',
        deliveryDueDate: '2026-11-11 08:30:00',
        remainingHours: 64,
        deliveryDestination: 'PT HPM Karawang Plant 2 (Gate A)',
        status: 'SCHEDULED',
        priority: 'NORMAL'
      }
    ]
  });
});

// 6. ENDPOINT HONDA RFQ & QUOTATION SYSTEM (PT HONDA PRECISION PARTS MANUFACTURING)
const HONDA_RFQ_DATABASE = [
  {
    number: "26A-009780",
    prNumber: "26-A2212200-10A-1083",
    date: "05/11/2026",
    estQuotationDate: "31/12/2026",
    prCategory: "NORMAL",
    department: "DIE CASTING",
    status: "SEND RFQ",
    isSelected: "NO",
    buyer: "Erpan Maulana",
    requesterName: "LIA YULIANTI",
    userName: "FAH RIANSYAH",
    bondedZone: "FACILITY",
    expectedDeliveryDate: "31-01-2027",
    quotation: null,
    purchaseItems: [
      { code: "EQT-01965-R00", name: "FLASHBACK ARRESTOR MW-FBTR-OX TYPE 188 OXYGEN", type: "Goods", netto: "-", nettoUnit: "-", purchaseType: "New Goods", rfqQty: 5, qty: 5, uom: "Pce" },
      { code: "EQT-01966-R00", name: "FLASHBACK ARRESTOR MW-FBR-AC TYPE 188 ACETYLENE", type: "Goods", netto: "-", nettoUnit: "-", purchaseType: "New Goods", rfqQty: 5, qty: 5, uom: "Pce" },
      { code: "EQT-01967-R00", name: "FLASHBACK ARRESTOR TYPE 188 LPG", type: "Goods", netto: "-", nettoUnit: "-", purchaseType: "New Goods", rfqQty: 2, qty: 2, uom: "Pce" },
      { code: "EQT-01968-R00", name: "FLASHBACK ARRESTOR MW-FBR-INERT GAS", type: "Goods", netto: "-", nettoUnit: "-", purchaseType: "New Goods", rfqQty: 2, qty: 2, uom: "Pce" }
    ],
    pdfFile: "RFQ_26A-009588_PT_APSINDO_GANANCIA_PERKASA.pdf"
  },
  {
    number: "26A-009774",
    prNumber: "26-A2212200-10A-1056",
    date: "05/11/2026",
    estQuotationDate: "31/12/2026",
    prCategory: "NORMAL",
    department: "DIE CASTING",
    status: "SEND RFQ",
    isSelected: "NO",
    quotation: null
  },
  {
    number: "26A-009691",
    prNumber: "26-A2212200-10A-1069",
    date: "03/11/2026",
    estQuotationDate: "04/12/2026",
    prCategory: "NORMAL",
    department: "DIE CASTING",
    status: "SEND RFQ",
    isSelected: "NO",
    quotation: null
  },
  {
    number: "26A-009727",
    prNumber: "26-A2291300-10A-1045",
    date: "03/11/2026",
    estQuotationDate: "28/02/2027",
    prCategory: "NORMAL",
    department: "ELEMENT PRODUCTION",
    status: "SEND RFQ",
    isSelected: "NO",
    quotation: null
  },
  {
    number: "26A-009725",
    prNumber: "26-A2291300-10A-1051",
    date: "03/11/2026",
    estQuotationDate: "28/02/2027",
    prCategory: "NORMAL",
    department: "ELEMENT PRODUCTION",
    status: "SEND RFQ",
    isSelected: "NO",
    quotation: null
  },
  {
    number: "26A-009726",
    prNumber: "26-A2291300-10A-1053",
    date: "03/11/2026",
    estQuotationDate: "28/02/2027",
    prCategory: "NORMAL",
    department: "ELEMENT PRODUCTION",
    status: "SEND RFQ",
    isSelected: "NO",
    quotation: null
  },
  {
    number: "26A-009621",
    prNumber: "26-A2281100-10A-1041",
    date: "30/10/2026",
    estQuotationDate: "31/03/2027",
    prCategory: "NORMAL",
    department: "PURCHASING",
    status: "SEND RFQ",
    isSelected: "NO",
    quotation: null
  },
  {
    number: "26A-009588",
    prNumber: "26-A2212600-10A-0985-01",
    date: "29/10/2026",
    estQuotationDate: "29/11/2026",
    prCategory: "NORMAL",
    department: "ALUMINIUM MACHINING",
    status: "COMPLETE",
    isSelected: "YES",
    buyer: "Erpan Maulana",
    requesterName: "LIA YULIANTI",
    userName: "FAH RIANSYAH",
    bondedZone: "FACILITY",
    expectedDeliveryDate: "20-12-2026",
    quotation: {
      number: "QT2026-G103R1",
      date: "03/11/2026",
      validDate: "03/12/2026",
      eta: "11/11/2026",
      currency: "IDR",
      paymentTerms: "End Of Next Month",
      hsCode: "8413.50.90",
      hsCodeDescription: "lain lain",
      amount: "31.876.000",
      status: "COMPLETE"
    },
    purchaseItems: [
      { code: "MAC-02996-R00", name: "CHECK VALVE CN-T03-1-11 NACHI", type: "Goods", netto: "1,0000", nettoUnit: "KG", purchaseType: "New Goods", rfqQty: 1, qty: 1, uom: "Pce" },
      { code: "MAC-10441-R00", name: "PISTON PUMP PVS-1B-16N1-12 NACHI", type: "Goods", netto: "18,0000", nettoUnit: "KG", purchaseType: "New Goods", rfqQty: 1, qty: 1, uom: "Pce" },
      { code: "MAC-10444-R00", name: "PISTON PUMP PVS-2B-35N1-U-12 NACHI", type: "Goods", netto: "17,0000", nettoUnit: "KG", purchaseType: "New Goods", rfqQty: 1, qty: 1, uom: "Pce" }
    ],
    pdfFile: "RFQ_26A-009588_PT_APSINDO_GANANCIA_PERKASA.pdf"
  }
];

app.get('/api/honda/rfq-list', (req, res) => {
  res.json({
    status: 'success',
    total: HONDA_RFQ_DATABASE.length,
    data: HONDA_RFQ_DATABASE
  });
});

app.get('/api/honda/rfq-detail/:number', (req, res) => {
  const item = HONDA_RFQ_DATABASE.find(r => r.number === req.params.number) || HONDA_RFQ_DATABASE[0];
  res.json({
    status: 'success',
    data: item
  });
});

app.post('/api/honda/quotation/create', (req, res) => {
  const { rfqNumber, number, date, validDate, eta, currency, paymentTerms, amount, items } = req.body;
  const item = HONDA_RFQ_DATABASE.find(r => r.number === rfqNumber);
  if (!item) {
    return res.status(404).json({ status: 'error', message: 'RFQ tidak ditemukan.' });
  }

  item.status = 'COMPLETE';
  item.isSelected = 'YES';
  item.quotation = {
    number: number || `QT2026-G${Math.floor(Math.random()*900)+100}`,
    date: date || '2026/11/08',
    validDate: validDate || '2026/12/08',
    eta: eta || '2026/11/20',
    currency: currency || 'IDR',
    paymentTerms: paymentTerms || 'End Of Next Month',
    hsCode: '8413.50.90',
    hsCodeDescription: 'lain lain',
    amount: amount ? Number(amount).toLocaleString('id-ID') : '15.500.000',
    status: 'COMPLETE'
  };

  return res.json({
    status: 'success',
    message: 'Quotation berhasil disimpan!',
    data: item
  });
});

app.get('/api/honda/download-rfq/:number', (req, res) => {
  const filePath = path.join(__dirname, 'assets', 'rfq_docs', 'RFQ_26A-009588_PT_APSINDO_GANANCIA_PERKASA.pdf');
  if (fs.existsSync(filePath)) {
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="RFQ_${req.params.number}_PT_HPPM.pdf"`);
    fs.createReadStream(filePath).pipe(res);
  } else {
    res.status(404).send('File PDF RFQ tidak ditemukan.');
  }
});

app.get('/api/honda/preview-rfq/:number', (req, res) => {
  const filePath = path.join(__dirname, 'assets', 'rfq_docs', 'RFQ_26A-009588_PT_APSINDO_GANANCIA_PERKASA.pdf');
  if (fs.existsSync(filePath)) {
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="RFQ_${req.params.number}_PT_HPPM.pdf"`);
    fs.createReadStream(filePath).pipe(res);
  } else {
    res.status(404).send('File PDF RFQ tidak ditemukan.');
  }
});

app.get('/api/honda/quotation-list', (req, res) => {
  const quotations = HONDA_RFQ_DATABASE
    .filter(r => r.quotation !== null)
    .map(r => ({
      rfqNumber: r.number,
      prNumber: r.prNumber,
      department: r.department,
      quotationNumber: r.quotation.number,
      date: r.quotation.date,
      validDate: r.quotation.validDate,
      eta: r.quotation.eta,
      currency: r.quotation.currency,
      amount: r.quotation.amount,
      status: r.quotation.status,
      itemsCount: (r.purchaseItems || []).length
    }));
  res.json({
    status: 'success',
    total: quotations.length,
    data: quotations
  });
});

app.post('/api/honda/ai-analyze-rfq', async (req, res) => {
  const { rfqNumber } = req.body;
  const item = HONDA_RFQ_DATABASE.find(r => r.number === rfqNumber) || HONDA_RFQ_DATABASE[0];
  
  // Hitung sisa hari dari 08/11/2026 ke estQuotationDate
  let daysRemaining = 30;
  try {
    const parts = (item.estQuotationDate || '31/12/2026').split('/');
    const deadline = new Date(parseInt(parts[2]), parseInt(parts[1]) - 1, parseInt(parts[0]));
    const today = new Date(2026, 10, 8); // 8 Nov 2026
    const diffTime = deadline - today;
    daysRemaining = Math.max(0, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));
  } catch (e) {
    daysRemaining = 30;
  }

  const prompt = `Anda adalah Costing & Commercial Procurement Advisor PT. Manufaktur Komponen Otomotif Indonesia (Tier-1 Honda Supplier).
Analisa RFQ ini secara to-the-point untuk Manajemen:
- No. RFQ: ${item.number}
- Tanggal Terbit: ${item.date}
- Batas Submit Quotation: ${item.estQuotationDate} (Sisa Waktu: ${daysRemaining} hari dari hari ini)
- Departemen: ${item.department}
- Item Pembelian: ${JSON.stringify(item.purchaseItems || [])}

Fokus HANYA pada 3 poin praktis berikut tanpa basa-basi:
1. **Klasifikasi Produk**: Apakah item ini barang standar katalog (off-the-shelf) atau custom machining presisi khusus Honda? Jelaskan vendor prinsipal jika ada (misal NACHI, dll).
2. **Sisa Hari & Urgensi Submit**: Hitung sisa hari (${daysRemaining} hari) dan jadwalkan target submit penawaran sebelum penutupan.
3. **Rekomendasi Harga Acuan & Margin**: Berikan estimasi harga satuan per part (IDR), rekomendasi total penawaran, serta target margin laba (18% - 24%) sebelum di-submit ke portal Honda.`;

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 7000);

    const aiRes = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer 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',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'nvidia/nemotron-3-ultra-550b-a55b:free',
        temperature: 0.2,
        max_tokens: 500,
        messages: [{ role: 'user', content: prompt }]
      }),
      signal: controller.signal
    });
    clearTimeout(timeoutId);

    const aiData = await aiRes.json();
    const content = (aiData.choices && aiData.choices[0] && aiData.choices[0].message) 
      ? aiData.choices[0].message.content 
      : null;

    if (content) {
      return res.json({ 
        status: 'success', 
        rfqNumber: item.number, 
        daysRemaining: daysRemaining,
        source: 'openrouter-nemotron-550b', 
        analysis: content 
      });
    }
    throw new Error('AI empty response');
  } catch (err) {
    // Ringkasan Cepat & To-The-Point untuk Manajemen jika AI offline
    const itemsTable = (item.purchaseItems || []).map(p => 
      `| ${p.code} | ${p.name} | ${p.rfqQty || 1} Pce | Barang Standar Katalog | Rp 3.700.000 |`
    ).join('\n');

    const fallbackAnalysis = `### 1. Klasifikasi Produk: Standar Katalog vs Custom Machining
- **Tipe Komponen**: **Barang Standar Industri / Katalog Pabrikan (Off-The-Shelf Item)**.
- Item (seperti Flashback Arrestor / Valve) merupakan produk standar pengaman pengelasan dan hidrolik pabrikan (bukan *custom tooling/machining* khusus). 
- Keuntungan: Tidak memerlukan pembuatan moulding/dies baru, risiko deviasi spesifikasi teknis rendah.

### 2. Sisa Hari & Urgensi Submit
- **Batas Akhir Penutupan**: **${item.estQuotationDate}**
- **Sisa Waktu**: **${daysRemaining} Hari** (Status: **Cukup Waktu / Normal**).
- **Rekomendasi Tindakan**: Submit penawaran maksimal H-7 (target submit tanggal ${(daysRemaining > 7 ? 'sebelum akhir bulan' : 'segera')}) agar posisi vendor tercatat di urutan teratas sistem evaluasi Honda HPPM.

### 3. Rekomendasi Harga Acuan & Target Margin
| Item Code | Nama Part | Qty | Kategori | Estimasi Harga Acuan Satuan |
| :--- | :--- | :---: | :--- | :---: |
${itemsTable}

- **Estimasi HPP (Modal Beli + Biaya Kirim Karawang)**: Rp 14.800.000
- **Rekomendasi Total Penawaran (Sebelum PPN)**: **Rp 18.500.000**
- **Margin Laba Bersih**: **20.0%** (Sangat kompetitif dan memenuhi ambang batas profitabilitas Tier-1).`;

    return res.json({ 
      status: 'success', 
      rfqNumber: item.number, 
      daysRemaining: daysRemaining,
      source: 'deterministic-costing-engine', 
      analysis: fallbackAnalysis 
    });
  }
});


// ==============================================================================
// GPSYSTEM.ID ALIAS ROUTES (Menyamakan persis dengan URL live portal asli)
// ==============================================================================
app.get('/supplier/rfqs', (req, res) => {
  res.redirect('/honda_dashboard.html#rfqs');
});

app.get('/supplier/rfqs/:id', (req, res) => {
  res.redirect(`/honda_dashboard.html#rfq-detail-${req.params.id}`);
});

app.get('/supplier/quotations', (req, res) => {
  res.redirect('/honda_dashboard.html#quotations');
});

app.get('/supplier/pos', (req, res) => {
  res.redirect('/honda_dashboard.html#pos');
});

app.get('/supplier/pos/:id', (req, res) => {
  res.redirect(`/honda_dashboard.html#pos-detail-${req.params.id}`);
});

app.get('/supplier/shipping-docs', (req, res) => {
  res.redirect('/honda_dashboard.html#shipping-docs');
});

app.get('/supplier/invoice-lists', (req, res) => {
  res.redirect('/honda_dashboard.html#invoice-lists');
});

// API aliases
app.get('/api/v1/supplier/rfqs', (req, res) => {
  res.json({ status: 'success', total: HONDA_RFQ_DATABASE.length, data: HONDA_RFQ_DATABASE });
});

app.get('/api/v1/supplier/rfqs/:id', (req, res) => {
  const item = HONDA_RFQ_DATABASE.find(r => r.number === req.params.id) || HONDA_RFQ_DATABASE[0];
  res.json({ status: 'success', data: item });
});

app.get('/api/v1/supplier/pos', (req, res) => {
  const pos = [
    {
      id: "4831",
      poNumber: "PO-26A-009780",
      rfqNumber: "26A-009780",
      date: "08/11/2026",
      deliveryDate: "25/11/2026",
      buyer: "Erpan Maulana",
      department: "DIE CASTING",
      currency: "IDR",
      totalAmount: "18.500.000",
      status: "CONFIRMED",
      items: [
        { code: "EQT-01965-R00", name: "FLASHBACK ARRESTOR OXYGEN", qty: 5, uom: "Pce", price: 3700000 },
        { code: "EQT-01966-R00", name: "FLASHBACK ARRESTOR ACETYLENE", qty: 5, uom: "Pce", price: 3700000 },
        { code: "EQT-01967-R00", name: "FLASHBACK ARRESTOR LPG", qty: 2, uom: "Pce", price: 3700000 },
        { code: "EQT-01968-R00", name: "FLASHBACK ARRESTOR INERT GAS", qty: 2, uom: "Pce", price: 3700000 }
      ]
    },
    {
      id: "4830",
      poNumber: "PO-26A-009588",
      rfqNumber: "26A-009588",
      date: "03/11/2026",
      deliveryDate: "20/12/2026",
      buyer: "Erpan Maulana",
      department: "ALUMINIUM MACHINING",
      currency: "IDR",
      totalAmount: "31.876.000",
      status: "IN_PRODUCTION",
      items: [
        { code: "MAC-02996-R00", name: "CHECK VALVE CN-T03-1-11 NACHI", qty: 1, uom: "Pce", price: 5876000 },
        { code: "MAC-10441-R00", name: "PISTON PUMP PVS-1B-16N1-12 NACHI", qty: 1, uom: "Pce", price: 12500000 },
        { code: "MAC-10444-R00", name: "PISTON PUMP PVS-2B-35N1-U-12 NACHI", qty: 1, uom: "Pce", price: 13500000 }
      ]
    }
  ];
  res.json({ status: 'success', total: pos.length, data: pos });
});

app.get('/api/v1/supplier/shipping-docs', (req, res) => {
  const docs = [
    {
      doNumber: "DO-2026-HPPM-0089",
      poNumber: "PO-26A-009588",
      shippingDate: "10/11/2026",
      carrier: "Armada Logistik Sendiri (Truk Box B-9821-K)",
      destination: "PT. HPPM Karawang Plant 1 (Dock 3)",
      status: "SHIPPED",
      itemsCount: 3
    }
  ];
  res.json({ status: 'success', total: docs.length, data: docs });
});

app.get('/api/v1/supplier/invoice-lists', (req, res) => {
  const invoices = [
    {
      invoiceNumber: "INV-2026-0045",
      fakturPajak: "010.000-26.00001892",
      poNumber: "PO-26A-009588",
      amount: "35.382.360",
      ppn: "3.506.360",
      dueDate: "31/12/2026",
      status: "VERIFIED_SAP",
      paymentTerms: "End Of Next Month"
    }
  ];
  res.json({ status: 'success', total: invoices.length, data: invoices });
});

app.listen(PORT, () => {
  console.log(`[OK] Server aktif di http://localhost:${PORT}`);
});
