# Konfigurasi Auto-Select Certificate untuk Chromium / Chrome / Edge di HKCU
# Supaya Playwright / Browser otomatis memilih sertifikat portal-dc.maxplus.id tanpa pop-up dialog

$policies = @(
    "HKCU:\Software\Policies\Google\Chrome\AutoSelectCertificateForUrls",
    "HKCU:\Software\Policies\Chromium\AutoSelectCertificateForUrls",
    "HKCU:\Software\Policies\Microsoft\Edge\AutoSelectCertificateForUrls"
)

# Pattern JSON matching target SSO domain and client certificate CN
$jsonVal = '{"pattern":"https://*","filter":{"ISSUER":{"CN":"Sectigo RSA Domain Validation Secure Server CA"}}}'
$jsonVal2 = '{"pattern":"https://*","filter":{"SUBJECT":{"CN":"portal-dc.maxplus.id"}}}'

foreach ($p in $policies) {
    if (!(Test-Path $p)) {
        New-Item -Path $p -Force | Out-Null
    }
    Set-ItemProperty -Path $p -Name "1" -Value $jsonVal -Force
    Set-ItemProperty -Path $p -Name "2" -Value $jsonVal2 -Force
    Write-Host "Set policy on $p"
}

Write-Host "AutoSelectCertificate policy successfully installed!"

