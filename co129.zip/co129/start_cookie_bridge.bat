@echo off
title LG Singlex Cookie Bridge Listener
echo ====================================================
echo   LG SINGLEX COOKIE BRIDGE LISTENER FOR TELEGRAM
echo ====================================================
echo Running on http://127.0.0.1:5005
echo Biarkan jendela ini tetap berjalan di latar belakang.
echo.
python host_bridge_service.py
pause

