import os
import sys
import time
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import formatdate, make_msgid
import requests

# ==============================================================================
# KONFIGURASI TARGET TESTING
# ==============================================================================
TARGET_EMAIL = "jaganetworks25@gmail.com"
WEBHOOK_URL = os.getenv("HONDA_WEBHOOK_URL", "http://localhost:8001/webhook/honda-po")

# Konfigurasi SMTP (Opsional: Jika ingin mengirim email asli via Gmail SMTP)
# Untuk Gmail, gunakan 'App Password' 16 digit dari Google Account Security
SMTP_SERVER = os.getenv("SMTP_SERVER", "smtp.gmail.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", 587))
SMTP_SENDER_EMAIL = os.getenv("SMTP_SENDER_EMAIL", "no-reply.hppm.sourcing@gmail.com")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")  # Masukkan App Password Gmail Anda jika kirim riil

# ==============================================================================
# DAFTAR DATA RFQ / PO YANG READY UNTUK TESTING
# ==============================================================================
READY_RFQS = [
    {
        "po_number": "26A-009780",
        "buyer": "Erpan Maulana",
        "pr_category": "NORMAL",
        "pr_number": "26-A2212200-10A-1083",
        "department": "DIE CASTING",
        "deadline": "31/12/2026",
        "parts": [
            "FLASHBACK ARRESTOR MW-FBTR-OX TYPE 188 OXYGEN (5 Pce)",
            "FLASHBACK ARRESTOR MW-FBR-AC TYPE 188 ACETYLENE (5 Pce)",
            "FLASHBACK ARRESTOR TYPE 188 LPG (2 Pce)",
            "FLASHBACK ARRESTOR MW-FBR-INERT GAS (2 Pce)"
        ]
    },
    {
        "po_number": "26A-009588",
        "buyer": "Erpan Maulana",
        "pr_category": "NORMAL",
        "pr_number": "26-A2212600-10A-0985-01",
        "department": "ALUMINIUM MACHINING",
        "deadline": "29/11/2026",
        "parts": [
            "CHECK VALVE CN-T03-1-11 NACHI (1 Pce)",
            "PISTON PUMP PVS-1B-16N1-12 NACHI (1 Pce)",
            "PISTON PUMP PVS-2B-35N1-U-12 NACHI (1 Pce)"
        ]
    },
    {
        "po_number": "26A-009774",
        "buyer": "Erpan Maulana",
        "pr_category": "NORMAL",
        "pr_number": "26-A2212200-10A-1056",
        "department": "DIE CASTING",
        "deadline": "31/12/2026",
        "parts": [
            "Moulding Spareparts Core Pin Set (10 Pce)",
            "Die Casting Ejector Pin High Temp (20 Pce)"
        ]
    },
    {
        "po_number": "26A-009691",
        "buyer": "Erpan Maulana",
        "pr_category": "NORMAL",
        "pr_number": "26-A2212200-10A-1069",
        "department": "DIE CASTING",
        "deadline": "04/12/2026",
        "parts": [
            "Heating Element Furnace 3-Phase 380V (4 Pce)",
            "Thermocouple Type K High Accuracy (6 Pce)"
        ]
    },
    {
        "po_number": "26A-009727",
        "buyer": "Erpan Maulana",
        "pr_category": "NORMAL",
        "pr_number": "26-A2291300-10A-1045",
        "department": "ELEMENT PRODUCTION",
        "deadline": "28/02/2027",
        "parts": [
            "Photoelectric Sensor Line Autonics (8 Pce)",
            "Proximity Sensor Inductive M12 (12 Pce)"
        ]
    }
]

def generate_email_content(rfq):
    """Membuat template email persis sesuai format resmi yang diminta"""
    po_num = rfq['po_number']
    buyer = rfq.get('buyer', 'Erpan Maulana')
    pr_cat = rfq.get('pr_category', 'NORMAL')
    portal_link = os.getenv("HONDA_TARGET_URL", "https://possum-skyward-recess.ngrok-free.dev/honda_dashboard.html")

    subject = f"RECEIPT OF DOCUMENTS PO No {po_num}"
    
    plain_body = f"""Dear Mr/Mrs PT APSINDO GANANCIA PERKASA,

Thank you for your relentless cooperation. You have Doc of PO for No PO-{po_num}. Please check the Document.

Doc PO : PO-{po_num}
Buyer Name : {buyer}
PR Category : {pr_cat}

Click this link ➔ : {portal_link} for response or follow up the Documents.
"""

    html_body = f"""<!DOCTYPE html>
<html>
<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333333; margin: 0; padding: 20px;">
  <div style="max-width: 600px; margin: 0 auto; border: 1px solid #e1e4e8; border-radius: 8px; padding: 24px; background-color: #ffffff;">
    <p>Dear Mr/Mrs <strong>PT APSINDO GANANCIA PERKASA</strong>,</p>
    
    <p>Thank you for your relentless cooperation. You have Doc of PO for No <strong>PO-{po_num}</strong>. Please check the Document.</p>
    
    <table style="width: 100%; border-collapse: collapse; margin: 16px 0;">
      <tr style="background-color: #f8f9fa;">
        <td style="padding: 8px 12px; border: 1px solid #dee2e6; width: 35%;"><strong>Doc PO</strong></td>
        <td style="padding: 8px 12px; border: 1px solid #dee2e6; color: #0b57d0; font-weight: bold;">PO-{po_num}</td>
      </tr>
      <tr>
        <td style="padding: 8px 12px; border: 1px solid #dee2e6;"><strong>Buyer Name</strong></td>
        <td style="padding: 8px 12px; border: 1px solid #dee2e6;">{buyer}</td>
      </tr>
      <tr style="background-color: #f8f9fa;">
        <td style="padding: 8px 12px; border: 1px solid #dee2e6;"><strong>PR Category</strong></td>
        <td style="padding: 8px 12px; border: 1px solid #dee2e6;">{pr_cat}</td>
      </tr>
    </table>

    <p style="margin-top: 20px;">
      Click this link &#10148; : <a href="{portal_link}" style="color: #0b57d0; font-weight: bold; text-decoration: underline;" target="_blank">Click Here for response or follow up the Documents.</a>
    </p>

    <hr style="border: none; border-top: 1px solid #eeeeee; margin: 24px 0 16px 0;">
    <p style="font-size: 11px; color: #888888; margin-bottom: 0;">
      PT. Honda Precision Parts Manufacturing • Global Partner System
    </p>
  </div>
</body>
</html>
"""
    return subject, plain_body, html_body
    return subject, plain_body, html_body

def send_bulk_webhook(delay_seconds=3):
    """
    Mengirimkan batch email langsung ke FastAPI Webhook test.py 
    (http://localhost:8000/webhook/honda-po).
    Cocok untuk menguji otomatisasi Playwright test.py secara menyeluruh.
    """
    print(f"\n=======================================================")
    print(f"[*] MEMULAI BULK TRIGGER KE TEST.PY WEBHOOK")
    print(f"[*] Target Endpoint: {WEBHOOK_URL}")
    print(f"[*] Jumlah RFQ: {len(READY_RFQS)} item")
    print(f"=======================================================")
    
    for idx, rfq in enumerate(READY_RFQS, 1):
        subject, plain_body, html_body = generate_email_content(rfq)
        
        payload = {
            "po_number": rfq["po_number"],
            "email_body": plain_body
        }
        
        print(f"\n[{idx}/{len(READY_RFQS)}] Mengirim data RFQ {rfq['po_number']}...")
        try:
            res = requests.post(WEBHOOK_URL, json=payload, timeout=5)
            if res.status_code == 200:
                print(f"  [SUCCESS] Diterima oleh test.py: {res.json().get('message')}")
            else:
                print(f"  [FAILED] HTTP {res.status_code}: {res.text}")
        except Exception as e:
            print(f"  [ERROR] Gagal konek ke test.py: {e}")
            print(f"  --> Pastikan 'python test.py' sudah aktif berjalan di terminal lain!")
            break
            
        if idx < len(READY_RFQS):
            print(f"  --> Menunggu jeda {delay_seconds} detik sebelum RFQ berikutnya...")
            time.sleep(delay_seconds)
            
    print(f"\n[DONE] Selesai mengirim seluruh batch ke test.py.\n")

def send_bulk_real_email(delay_seconds=2):
    """
    Mengirimkan email fisik sungguhan ke jaganetworks25@gmail.com via SMTP
    """
    print(f"\n=======================================================")
    print(f"[*] MEMULAI PENGIRIMAN EMAIL MASSAL KE: {TARGET_EMAIL}")
    print(f"[*] SMTP Server: {SMTP_SERVER}:{SMTP_PORT}")
    print(f"=======================================================")
    
    if not SMTP_PASSWORD:
        print("\n[PERINGATAN] Variabel lingkungan SMTP_PASSWORD belum diisi.")
        print("Jika ingin mengirim email asli via Gmail, Anda memerlukan App Password 16-digit.")
        print("Contoh cara menjalankan dengan kredensial:")
        print('  $env:SMTP_SENDER_EMAIL="email_anda@gmail.com"')
        print('  $env:SMTP_PASSWORD="xxxx xxxx xxxx xxxx"')
        print("  python bulk_sender.py --smtp\n")
        return

    try:
        print("[*] Menghubungkan ke server SMTP...")
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(SMTP_SENDER_EMAIL, SMTP_PASSWORD)
        print("[*] Autentikasi SMTP Berhasil!\n")
        
        for idx, rfq in enumerate(READY_RFQS, 1):
            subject, plain_body, html_body = generate_email_content(rfq)
            
            # Gunakan format MIMEMultipart('alternative') sesuai standar RFC 2046
            msg = MIMEMultipart("alternative")
            msg["From"] = f"HPPM Procurement <{SMTP_SENDER_EMAIL}>"
            msg["To"] = TARGET_EMAIL
            msg["Subject"] = subject
            msg["Date"] = formatdate(localtime=True)
            msg["Message-ID"] = make_msgid(domain=SMTP_SENDER_EMAIL.split("@")[-1])
            msg["Reply-To"] = SMTP_SENDER_EMAIL
            
            # Lampirkan versi plain text dan html (mengurangi skor spamfilter Google)
            part1 = MIMEText(plain_body, "plain", "utf-8")
            part2 = MIMEText(html_body, "html", "utf-8")
            msg.attach(part1)
            msg.attach(part2)
            
            print(f"[{idx}/{len(READY_RFQS)}] Mengirim email RFQ {rfq['po_number']} ke {TARGET_EMAIL}...")
            server.send_message(msg)
            print(f"  [SUCCESS] Email terkirim!")
            
            if idx < len(READY_RFQS):
                time.sleep(delay_seconds)
                
        server.quit()
        print(f"\n[DONE] Seluruh {len(READY_RFQS)} email berhasil dikirim ke {TARGET_EMAIL}!\n")
        
    except Exception as e:
        print(f"[ERROR] Gagal mengirim email SMTP: {e}")

if __name__ == "__main__":
    # Pilihan mode:
    # 1. python bulk_sender.py        -> Trigger massal ke Webhook test.py (Fast & Automated)
    # 2. python bulk_sender.py --smtp -> Kirim email asli ke jaganetworks25@gmail.com
    if "--smtp" in sys.argv:
        send_bulk_real_email()
    else:
        print("=" * 65)
        print("TOOLS PENGUJIAN MASSAL (BULK) EMAIL TENDER HONDA HPPM")
        print(f"Penerima Sasaran: {TARGET_EMAIL}")
        print("=" * 65)
        print("Opsi Pengujian:")
        print("1. Kirim Batch ke test.py Webhook (Jalankan 'python bulk_sender.py')")
        print("2. Kirim Email Asli via SMTP Gmail (Jalankan 'python bulk_sender.py --smtp')")
        print("=" * 65)
        send_bulk_webhook()
