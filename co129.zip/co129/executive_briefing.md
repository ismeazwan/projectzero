
📢 [HMG PARTNER - EXECUTIVE OPERATIONAL BRIEFING]
Waktu Ekstraksi: 2026-11-08 13:31:39 | Akun: D004002

🚨 1. STATUS PESANAN & LOGISTIK (PPIC & Delivery)
• PO-HMC-2026-8891 (Front Brake Pad Assembly - 58101-GI000):
  - Jumlah: 1.200 PCS | Tujuan: Hyundai Plant Cikarang (Line 2)
  - ⚠️ PERHATIAN TINGGI: Status "PENDING CONFIRMATION" dengan sisa waktu 14 Jam!
  - Berdasarkan aturan Hyundai CSR Klausul 7.24.1, pemasok wajib konfirmasi terima/tolak &le; 24 jam via portal.
• PO-MOBIS-2026-3412 (Bumper Cover Front - 86511-GI100):
  - Jumlah: 450 PCS | Status: CONFIRMED (Aman untuk jadwal kirim 20 Nov 2026).

📋 2. KEPATUHAN & REGULASI MUTU (QA, Engineering & EHS)
• Rilis CSR Manual 5th Edition (Doc No: HB-PD-MA-001):
  - Klausul 7.24 (After Sales): Kewajiban ketersediaan suku cadang servis minimal 10 tahun pasca-discontinue model.
  - Klausul 9.1 - 9.4 (Sustainability & ESG): Pemasok wajib mengunggah laporan inventarisasi emisi Gas Rumah Kaca (Scope 1 & 2 GHG) ke platform SCEMS.
  - Sanksi: Kegagalan pelaporan dapat menyebabkan penangguhan bisnis (business suspension).

✅ 3. ACTION PLAN & PIC HARI INI
1. [PPIC / Sales Admin]: Buka portal SRS/GSCM sekarang & klik 'Confirm' untuk PO-HMC-2026-8891 sebelum batas 14 jam habis.
2. [Quality Assurance]: Pelajari checklist revisi CSR 5th Edition & siapkan data kapabilitas proses (CPK &ge; 1.67).
3. [EHS / GA]: Koordinasikan pengumpulan data konsumsi listrik & bahan bakar pabrik untuk pelaporan Scope 1-2 GHG ke portal SCEMS.
