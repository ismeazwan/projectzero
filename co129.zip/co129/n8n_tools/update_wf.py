import json

file_path = r'c:\Users\muham\Documents\co129\n8n_workflow_honda_rfq_lifecycle.json'
with open(file_path, 'r', encoding='utf-8') as f:
    wf = json.load(f)

for node in wf['nodes']:
    if node['id'] == 'node-7-telegram-send-msg':
        node['parameters']['jsonBody'] = "={{ JSON.stringify({\n  chat_id: '1859219519',\n  text: $json.aiSummary + '\\n\\n💾 Status Cache: ' + ($json.cached ? 'Menggunakan Cache SQLite' : 'Analisis AI Baru Tersimpan') + '\\n👉 Silakan cari supplier rekanan dan unggah file penawaran/quotation balasan ke sini.'\n}) }}"
    elif node['id'] == 'node-12-telegram-confirm':
        node['parameters']['jsonBody'] = "={{ JSON.stringify({\n  chat_id: '1859219519',\n  text: '🎉 [QUOTATION BERHASIL DISUBMIT KE HONDA]\\n========================================\\n- No. RFQ: ' + $('9. AI Validasi: Cek Kesesuaian RFQ vs Penawaran').first().json.rfqId + '\\n- No. Quotation: ' + $('9. AI Validasi: Cek Kesesuaian RFQ vs Penawaran').first().json.quotationNumber + '\\n- Supplier Terpilih: ' + $('9. AI Validasi: Cek Kesesuaian RFQ vs Penawaran').first().json.supplierName + '\\n- Nilai Penawaran: ' + $('9. AI Validasi: Cek Kesesuaian RFQ vs Penawaran').first().json.currency + ' ' + $('9. AI Validasi: Cek Kesesuaian RFQ vs Penawaran').first().json.totalAmount + '\\n- Status di Portal: COMPLETE ✅\\n\\nDokumen penawaran harga telah sah tercatat di sistem PT Honda Precision Parts Manufacturing.'\n}) }}"
    elif node['id'] == 'node-13-mismatch-reject':
        node['parameters']['jsonBody'] = "={{ JSON.stringify({\n  chat_id: '1859219519',\n  text: '⚠️ [PENGAJUAN QUOTATION DITOLAK]\\nQuotation ' + $json.quotationNumber + ' tidak cocok dengan spesifikasi tender RFQ ' + $json.rfqId + '. Mohon hubungi supplier untuk revisi penawaran.'\n}) }}"

with open(file_path, 'w', encoding='utf-8') as f:
    json.dump(wf, f, indent=2, ensure_ascii=False)

print('SUCCESSFULLY_UPDATED_WORKFLOW')

