import json

file_path = "n8n_workflow_honda_rfq_lifecycle.json"
with open(file_path, "r", encoding="utf-8") as f:
    wf = json.load(f)

print("Current node count:", len(wf["nodes"]))
for n in wf["nodes"]:
    print("-", n.get("id"), ":", n.get("name"))

