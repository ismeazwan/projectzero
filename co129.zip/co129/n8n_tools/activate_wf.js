const sqlite3 = require('/usr/local/lib/node_modules/n8n/node_modules/sqlite3');
const db = new sqlite3.Database('/home/node/.n8n/database.sqlite');
db.run("UPDATE workflow_entity SET active = 1 WHERE id = 'w0vLgy43JWzWqtuw'", [], function(err) {
  if (err) {
    console.error(err);
    process.exit(1);
  } else {
    console.log('SUCCESS: Workflow activated! Rows:', this.changes);
    db.close();
  }
});

