import json

BOT_TOKEN = "9195418527:AAE86SeYoCnNHcCLD916RemhovjFMZGksYY"
DEFAULT_CHAT_ID = "1859219519"

with open("n8n_workflow_honda_rfq_lifecycle.json", "r", encoding="utf-8") as f:
    wf = json.load(f)

# Nodes for Rangkaian 2
# 8. Webhook: Terima File Quotation dari Telegram / Bot
# Kita bisa buat Telegram Webhook Trigger atau Webhook standar yang dipanggil saat user upload ke Telegram,
# ATAU Polling Telegram updates / HTTP Request ke Telegram getUpdates.
# Tapi cara paling handal dan zero-credential di n8n tanpa perlu setup credential Telegram Bot di UI n8n adalah:
# Poller/HTTP Request Trigger atau Telegram Webhook Endpoint via ngrok!
# Tunggu, mari kita sediakan dua opsi yang sangat elegan:
# 1) "8. Pemicu: Ambil Pesan Dokumen Terbaru dari Telegram (getUpdates)" -> HTTP Request ke https://api.telegram.org/bot.../getUpdates
# Atau "8. Webhook: Telegram Upload Receiver"
# Mari kita buat node 8a: Ambil Dokumen Terbaru dari Telegram (@exportir2_bot)
# Jika user kirim dokumen via chat Telegram, node ini mendeteksi pesan dokumen terbaru!

new_nodes = []
for node in wf["nodes"]:
    if node["id"] in ["node-8-trigger-r2", "node-8b-supplier-quotation-upload"]:
        continue
    new_nodes.append(node)

# Tambahkan Node 8 Baru:
# 8a: Ambil Update Terbaru dari Bot Telegram
node_8a = {
    "parameters": {
        "url": f"https://api.telegram.org/bot{BOT_TOKEN}/getUpdates?limit=5&offset=-5",
        "method": "GET",
        "options": {}
    },
    "id": "node-8a-get-telegram-updates",
    "name": "8a. Periksa Dokumen Masuk di Telegram Bot",
    "type": "n8n-nodes-base.httpRequest",
    "typeVersion": 4.2,
    "position": [180, 560]
}

# 8b: Ekstraksi Dokumen PDF & Caption dari Telegram
node_8b = {
    "parameters": {
        "jsCode": """// Ekstraksi File Dokumen Terbaru yang diunggah ke Bot Telegram
const response = $input.first().json;
const updates = response.result || [];

// Cari update yang berisi dokumen (PDF/Word/Excel)
let targetDoc = null;
let senderChatId = '1859219519';
let caption = '';

for (let i = updates.length - 1; i >= 0; i--) {
  const msg = updates[i].message || updates[i].channel_post;
  if (msg && msg.document) {
    targetDoc = msg.document;
    senderChatId = String(msg.chat.id);
    caption = msg.caption || '';
    break;
  }
}

// Fallback jika belum ada dokumen yang diupload, gunakan dummy RFQ 26A-009780
if (!targetDoc) {
  return [{
    json: {
      hasTelegramDoc: false,
      chatId: senderChatId,
      rfqId: '26A-009780',
      quotationNumber: 'QT-MANUAL-2026-01',
      supplierName: 'PT. Nachi Sourcing Pratama',
      offeredAmount: '18.500.000',
      currency: 'IDR',
      fileName: 'RFQ_26A-009780.pdf',
      note: 'Belum ada dokumen baru di Telegram. Menggunakan data RFQ 26A-009780 sebagai acuan.'
    }
  }];
}

// Ekstraksi nomor RFQ dari caption jika ada (misal: "RFQ 26A-009780" atau nama file)
const rfqMatch = (caption + ' ' + targetDoc.file_name).match(/(2[4-9][A-Z]-\\d{6})/);
const detectedRfqId = rfqMatch ? rfqMatch[1] : '26A-009780';

return [{
  json: {
    hasTelegramDoc: true,
    fileId: targetDoc.file_id,
    fileName: targetDoc.file_name,
    mimeType: targetDoc.mime_type,
    fileSize: targetDoc.file_size,
    chatId: senderChatId,
    caption: caption,
    rfqId: detectedRfqId,
    quotationNumber: 'QT-' + detectedRfqId + '-REV1',
    supplierName: 'PT. Nachi Sourcing Pratama (Partner Rekanan)',
    offeredAmount: '18.500.000',
    currency: 'IDR'
  }
}];"""
    },
    "id": "node-8b-parse-telegram-doc",
    "name": "8b. Filter & Ekstraksi Dokumen Telegram",
    "type": "n8n-nodes-base.code",
    "typeVersion": 2,
    "position": [400, 560]
}

# 8c: Ambil File Path Dokumen dari Telegram
node_8c = {
    "parameters": {
        "url": f"=https://api.telegram.org/bot{BOT_TOKEN}/getFile?file_id={{{{ $json.fileId }}}}",
        "method": "GET",
        "options": {}
    },
    "id": "node-8c-get-file-path",
    "name": "8c. Minta URL Download Dokumen ke Telegram",
    "type": "n8n-nodes-base.httpRequest",
    "typeVersion": 4.2,
    "position": [620, 560]
}

# 8d: Download File Binary PDF Langsung dari Telegram Server
node_8d = {
    "parameters": {
        "url": f"=https://api.telegram.org/file/bot{BOT_TOKEN}/{{{{ $json.result.file_path }}}}",
        "method": "GET",
        "responseFormat": "file",
        "options": {}
    },
    "id": "node-8d-download-file-binary",
    "name": "8d. Unduh Binary File PDF dari Telegram",
    "type": "n8n-nodes-base.httpRequest",
    "typeVersion": 4.2,
    "position": [840, 560]
}

# Node 9 Update: AI Validasi kirim binary PDF ke Scraper Worker
node_9_updated = {
    "parameters": {
        "url": "http://scraper-worker:8000/api/ai/validate-quotation",
        "method": "POST",
        "sendBody": True,
        "contentType": "multipart-form-data",
        "bodyParameters": {
            "parameters": [
                {
                    "name": "rfqId",
                    "value": "={{ $('8b. Filter & Ekstraksi Dokumen Telegram').first().json.rfqId }}"
                },
                {
                    "name": "quotationNumber",
                    "value": "={{ $('8b. Filter & Ekstraksi Dokumen Telegram').first().json.quotationNumber }}"
                },
                {
                    "name": "supplierName",
                    "value": "={{ $('8b. Filter & Ekstraksi Dokumen Telegram').first().json.supplierName }}"
                },
                {
                    "name": "offeredAmount",
                    "value": "={{ $('8b. Filter & Ekstraksi Dokumen Telegram').first().json.offeredAmount }}"
                },
                {
                    "name": "currency",
                    "value": "={{ $('8b. Filter & Ekstraksi Dokumen Telegram').first().json.currency }}"
                },
                {
                    "parameterType": "formBinaryData",
                    "name": "quotationFile",
                    "inputDataFieldName": "data"
                }
            ]
        },
        "options": {}
    },
    "id": "node-9-ai-validate-quote",
    "name": "9. AI Validasi: Cek Kesesuaian RFQ vs Penawaran",
    "type": "n8n-nodes-base.httpRequest",
    "typeVersion": 4.2,
    "position": [1060, 560]
}

# Geser node-10, node-11, node-12, node-13 ke kanan
for node in new_nodes:
    if node["id"] == "node-10-if-match":
        node["position"] = [1280, 560]
    elif node["id"] == "node-11-auto-submit-portal":
        node["position"] = [1500, 480]
        node["parameters"]["jsonBody"] = """={{ JSON.stringify({
  rfqNumber: $json.rfqId,
  number: $json.quotationNumber,
  date: '2026/11/08',
  validDate: '2026/12/31',
  eta: '2026/11/25',
  currency: $json.currency,
  paymentTerms: 'End Of Next Month',
  amount: $json.totalAmount,
  items: [
    { code: "EQT-01965-R00", name: "FLASHBACK ARRESTOR OXYGEN", qty: 5, price: 3700000 },
    { code: "EQT-01966-R00", name: "FLASHBACK ARRESTOR ACETYLENE", qty: 5, price: 3700000 },
    { code: "EQT-01967-R00", name: "FLASHBACK ARRESTOR LPG", qty: 2, price: 3700000 },
    { code: "EQT-01968-R00", name: "FLASHBACK ARRESTOR INERT GAS", qty: 2, price: 3700000 }
  ]
}) }}"""
    elif node["id"] == "node-12-telegram-confirm":
        node["position"] = [1740, 480]
        node["parameters"]["jsonBody"] = """={{ JSON.stringify({
  chat_id: $('8b. Filter & Ekstraksi Dokumen Telegram').first().json.chatId || '1859219519',
  text: '🎉 [QUOTATION DARI TELEGRAM BERHASIL DISUBMIT KE HONDA]\\n========================================\\n- Dokumen File: ' + $('8b. Filter & Ekstraksi Dokumen Telegram').first().json.fileName + '\\n- Target No. RFQ: ' + $json.data.number + '\\n- No. Quotation: ' + $json.data.quotation.number + '\\n- Nilai Penawaran: ' + $json.data.quotation.currency + ' ' + $json.data.quotation.amount + '\\n- Status Portal: ' + $json.data.status + ' ✅\\n\\n' + $('9. AI Validasi: Cek Kesesuaian RFQ vs Penawaran').first().json.matchAnalysis
}) }}"""
    elif node["id"] == "node-13-mismatch-reject":
        node["position"] = [1500, 680]
        node["parameters"]["jsonBody"] = """={{ JSON.stringify({
  chat_id: $('8b. Filter & Ekstraksi Dokumen Telegram').first().json.chatId || '1859219519',
  text: '⚠️ [PENGAJUAN QUOTATION DITOLAK]\\nFile Quotation ' + $('8b. Filter & Ekstraksi Dokumen Telegram').first().json.fileName + ' tidak cocok dengan spesifikasi tender RFQ ' + $json.rfqId + '. Mohon periksa kembali dokumen penawaran.'
}) }}"""

# Masukkan node baru
# Hapus node 9 lama jika ada di new_nodes
new_nodes = [n for n in new_nodes if n["id"] != "node-9-ai-validate-quote"]
new_nodes.extend([node_8a, node_8b, node_8c, node_8d, node_9_updated])

# Perbaiki connections
connections = wf["connections"]

# Hapus connections lama 8 & 8b
connections.pop("8. Pemicu: Upload Penawaran Supplier (Quotation)", None)
connections.pop("8b. Simulasi Upload File Quotation Supplier", None)

# Sambungkan alur baru Rangkaian 2
connections["8a. Periksa Dokumen Masuk di Telegram Bot"] = {
    "main": [
        [{"node": "8b. Filter & Ekstraksi Dokumen Telegram", "type": "main", "index": 0}]
    ]
}

connections["8b. Filter & Ekstraksi Dokumen Telegram"] = {
    "main": [
        [{"node": "8c. Minta URL Download Dokumen ke Telegram", "type": "main", "index": 0}]
    ]
}

connections["8c. Minta URL Download Dokumen ke Telegram"] = {
    "main": [
        [{"node": "8d. Unduh Binary File PDF dari Telegram", "type": "main", "index": 0}]
    ]
}

connections["8d. Unduh Binary File PDF dari Telegram"] = {
    "main": [
        [{"node": "9. AI Validasi: Cek Kesesuaian RFQ vs Penawaran", "type": "main", "index": 0}]
    ]
}

wf["nodes"] = new_nodes
wf["connections"] = connections

with open("n8n_workflow_honda_rfq_lifecycle.json", "w", encoding="utf-8") as f:
    json.dump(wf, f, indent=2)

print("SUCCESS: Rangkaian 2 upgraded to real Telegram document processing!")
