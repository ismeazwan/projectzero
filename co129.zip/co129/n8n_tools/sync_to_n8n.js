const fs = require('fs');
const sqlite3 = require('/usr/local/lib/node_modules/n8n/node_modules/sqlite3');
const db = new sqlite3.Database('/home/node/.n8n/database.sqlite');

const wf = JSON.parse(fs.readFileSync('/tmp/workflow.json', 'utf8'));
const nodesStr = JSON.stringify(wf.nodes);
const connectionsStr = JSON.stringify(wf.connections);

db.run(
  "UPDATE workflow_entity SET nodes = ?, connections = ?, updatedAt = datetime('now') WHERE id = ?",
  [nodesStr, connectionsStr, 'w0vLgy43JWzWqtuw'],
  function(err) {
    if (err) {
      console.error('ERROR:', err);
      process.exit(1);
    } else {
      console.log('SUCCESS: Updated rows =', this.changes);
      db.close();
    }
  }
);

