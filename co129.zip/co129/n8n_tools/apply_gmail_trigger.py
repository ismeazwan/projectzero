import json

with open("n8n_workflow_honda_rfq_lifecycle.json", "r", encoding="utf-8") as f:
    wf = json.load(f)

# Update Node 1 & 2
for node in wf["nodes"]:
    if node["id"] == "node-1-trigger":
        # Ubah Node 1 jadi Schedule Trigger (Polling setiap 1 menit)
        node["name"] = "1. Jadwal: Pantau Inbox Gmail Setiap 1 Menit"
        node["type"] = "n8n-nodes-base.scheduleTrigger"
        node["typeVersion"] = 1.2
        node["parameters"] = {
            "rule": {
                "interval": [
                    {
                        "field": "minutes",
                        "minutesInterval": 1
                    }
                ]
            }
        }
    elif node["id"] == "node-2-mock-email":
        # Ubah Node 2 jadi Real HTTP Request ke Scraper Worker yang membaca IMAP Gmail
        node["name"] = "2. Baca Email Asli dari jaganetworks25@gmail.com"
        node["type"] = "n8n-nodes-base.httpRequest"
        node["typeVersion"] = 4.2
        node["parameters"] = {
            "url": "http://scraper-worker:8000/api/email/fetch-latest-rfq",
            "method": "GET",
            "options": {}
        }
    elif node["id"] == "node-3-parse-id":
        node["name"] = "3. Ekstraksi ID RFQ dari Email Asli"
        node["parameters"]["jsCode"] = """// Ekstraksi ID / Nomor RFQ dari Hasil Pembacaan Email Asli
const email = $input.first().json;
const fullText = (email.subject || '') + ' ' + (email.body || '');
const rfqMatch = fullText.match(/(2[4-9][A-Z]-\\d{6})/);
const extractedRfqId = rfqMatch ? rfqMatch[1] : (email.rfqId || '26A-009727');

return [
  {
    json: {
      rfqId: extractedRfqId,
      emailSender: email.from,
      emailSubject: email.subject,
      detectedAt: new Date().toISOString()
    }
  }
];"""

# Perbarui nama koneksi jika ada perubahan nama node
connections = {}
for src_node, targets in wf["connections"].items():
    new_src = src_node
    if src_node == "1. Pemicu: Email Masuk (No-Reply RfQ)":
        new_src = "1. Jadwal: Pantau Inbox Gmail Setiap 1 Menit"
    elif src_node == "2. Simulasi Email No-Reply Honda":
        new_src = "2. Baca Email Asli dari jaganetworks25@gmail.com"
    elif src_node == "3. Ekstraksi ID RFQ dari Email":
        new_src = "3. Ekstraksi ID RFQ dari Email Asli"

    new_targets = {"main": []}
    for branch in targets.get("main", []):
        new_branch = []
        for item in branch:
            target_name = item["node"]
            if target_name == "2. Simulasi Email No-Reply Honda":
                target_name = "2. Baca Email Asli dari jaganetworks25@gmail.com"
            elif target_name == "3. Ekstraksi ID RFQ dari Email":
                target_name = "3. Ekstraksi ID RFQ dari Email Asli"
            new_branch.append({
                "node": target_name,
                "type": item["type"],
                "index": item["index"]
            })
        new_targets["main"].append(new_branch)
    connections[new_src] = new_targets

wf["connections"] = connections

with open("n8n_workflow_honda_rfq_lifecycle.json", "w", encoding="utf-8") as f:
    json.dump(wf, f, indent=2)

print("SUCCESS: Workflow updated with Schedule Trigger & Real Gmail IMAP reader!")

