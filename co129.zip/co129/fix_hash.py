import json

file_path = "n8n_workflow_honda_rfq_lifecycle.json"
with open(file_path, "r", encoding="utf-8") as f:
    wf = json.load(f)

# Hash SHA-256 yang benar untuk "nuclearportalhppm":
# 8ed59a6f1ffdd7a2f60921d3f203d3c41c18b6307c1e26a183d4f6bebbc3ccd6
correct_hash = "8ed59a6f1ffdd7a2f60921d3f203d3c41c18b6307c1e26a183d4f6bebbc3ccd6"

for node in wf["nodes"]:
    if node["id"] == "node-4-auto-login-honda":
        node["parameters"]["jsonBody"] = '={{ JSON.stringify({\n  username: "apsindo@cbn.net.id",\n  password: "' + correct_hash + '",\n  rememberMe: true\n}) }}'
        print("Updated node 4 with correct SHA-256 hash!")

with open(file_path, "w", encoding="utf-8") as f:
    json.dump(wf, f, indent=2)

print("SUCCESS: JSON updated.")

