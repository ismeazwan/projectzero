"""
Telegram Bot Phase 2 Service for Honda HPPM Tender Lifecycle with Rich UI/UX
Features:
- Native Bot Menu Button & Persistent Keyboard Buttons (Bawah Layar)
- 📝 Create / Edit Quotation (Mandiri & Turunan)
- 🔍 Cari RFQ Berdasarkan Nomor
- 🔎 Cari Quotation Berdasarkan Nomor
- 📋 Daftar RFQ Terbaru (dengan tombol klik langsung tanpa perlu ketik nomor RFQ)
- 📊 Cek Status Portal & Token
- 💡 Panduan Penggunaan
- Pembuatan Dokumen Word (.docx) & Konversi Native PDF via Windows Host Bridge
- Preview interaktif sebelum live submission ke gpsystem.id
"""

import os
import re
import json
import time
import sqlite3
import logging
import threading
import requests
import io
import base64
import datetime
from typing import Dict, Any, Optional, List

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger("telegram_honda_bot")

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "9195418527:AAE86SeYoCnNHcCLD916RemhovjFMZGksYY")
HONDA_PORTAL_BASE = "https://gpsystem.id"
OPENROUTER_KEY = os.getenv("OPENROUTER_API_KEY", "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")
DB_PATH = os.path.join(os.path.dirname(__file__), "rfq_quotation_cache.db")
HOST_BRIDGE_URL = os.getenv("HOST_BRIDGE_URL", "http://host.docker.internal:5005")

# In-memory user state
user_sessions: Dict[int, Dict[str, Any]] = {}

# Menu Keyboard Statis di Bawah Layar (Khusus Honda HPPM)
MAIN_MENU_KEYBOARD = {
    "keyboard": [
        [{"text": "📋 Daftar RFQ Terbaru"}, {"text": "📝 Create Quotation"}],
        [{"text": "🔍 Cari RFQ"}, {"text": "🔎 Cari Quotation"}],
        [{"text": "📊 Cek Status Portal"}, {"text": "💡 Panduan Penggunaan"}]
    ],
    "resize_keyboard": True,
    "is_persistent": True
}

def get_db_connection():
    return sqlite3.connect(DB_PATH)

def get_honda_token(force_refresh: bool = False) -> Optional[str]:
    try:
        from main import get_honda_auth_token
        token = get_honda_auth_token(force_refresh=force_refresh)
        if token:
            return token
    except Exception as e:
        logger.warning(f"Gagal memanggil get_honda_auth_token dari main: {e}")

    if not force_refresh:
        try:
            conn = get_db_connection()
            c = conn.cursor()
            c.execute("SELECT token FROM auth_tokens WHERE portal_name = 'honda'")
            row = c.fetchone()
            conn.close()
            if row and row[0]:
                return row[0]
        except Exception as e:
            logger.warning(f"Gagal membaca token dari SQLite: {e}")
    
    return None

def honda_api_get(endpoint: str, params: Optional[Dict[str, Any]] = None) -> Optional[requests.Response]:
    url = f"{HONDA_PORTAL_BASE}{endpoint}" if endpoint.startswith("/") else endpoint
    token = get_honda_token(force_refresh=False)
    if not token:
        token = get_honda_token(force_refresh=True)
    if not token:
        return None
    
    headers = {
        "Authorization": f"Bearer {token}",
        "User-Agent": "Mozilla/5.0",
        "Referer": f"{HONDA_PORTAL_BASE}/"
    }
    try:
        res = requests.get(url, params=params, headers=headers, timeout=15, verify=False)
        if res.status_code == 401:
            logger.warning(f"Honda API merespons 401 Unauthorized pada {endpoint}. Melakukan auto-refresh token...")
            new_token = get_honda_token(force_refresh=True)
            if new_token:
                headers["Authorization"] = f"Bearer {new_token}"
                res = requests.get(url, params=params, headers=headers, timeout=15, verify=False)
        return res
    except Exception as e:
        logger.error(f"Error GET ke Honda API ({endpoint}): {e}")
        return None

def honda_api_post(endpoint: str, data: Optional[Dict[str, Any]] = None, files: Optional[Dict[str, Any]] = None) -> Optional[requests.Response]:
    url = f"{HONDA_PORTAL_BASE}{endpoint}" if endpoint.startswith("/") else endpoint
    token = get_honda_token(force_refresh=False)
    if not token:
        token = get_honda_token(force_refresh=True)
    if not token:
        return None
    
    headers = {
        "Authorization": f"Bearer {token}",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Referer": f"{HONDA_PORTAL_BASE}/"
    }
    try:
        res = requests.post(url, data=data, files=files, headers=headers, timeout=25, verify=False)
        if res.status_code == 401:
            logger.warning(f"Honda API merespons 401 Unauthorized pada POST {endpoint}. Melakukan auto-refresh token...")
            new_token = get_honda_token(force_refresh=True)
            if new_token:
                headers["Authorization"] = f"Bearer {new_token}"
                res = requests.post(url, data=data, files=files, headers=headers, timeout=25, verify=False)
        return res
    except Exception as e:
        logger.error(f"Error POST ke Honda API ({endpoint}): {e}")
        return None

def telegram_request(method: str, data: Optional[Dict[str, Any]] = None, files: Optional[Dict[str, Any]] = None):
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/{method}"
    try:
        if files:
            res = requests.post(url, data=data, files=files, timeout=35)
        else:
            res = requests.post(url, json=data, timeout=35)
        return res.json()
    except Exception as e:
        logger.error(f"Telegram API request {method} error: {e}")
        return None

def send_message(chat_id: int, text: str, reply_markup: Optional[Dict[str, Any]] = None, parse_mode: Optional[str] = "Markdown"):
    markup = reply_markup if reply_markup is not None else MAIN_MENU_KEYBOARD
    payload = {
        "chat_id": chat_id,
        "text": text,
        "reply_markup": markup
    }
    if parse_mode:
        payload["parse_mode"] = parse_mode
    res = telegram_request("sendMessage", payload)
    # Jika gagal karena entity markdown parsing error, fallback kirim sebagai plain-text tanpa parse_mode
    if res and not res.get("ok") and "parse entities" in res.get("description", "").lower():
        logger.warning(f"Markdown parsing failed on sendMessage: {res.get('description')}. Falling back to plain text.")
        payload.pop("parse_mode", None)
        res = telegram_request("sendMessage", payload)
    return res

def edit_message_text(chat_id: int, message_id: int, text: str, reply_markup: Optional[Dict[str, Any]] = None, parse_mode: Optional[str] = "Markdown"):
    payload = {
        "chat_id": chat_id,
        "message_id": message_id,
        "text": text,
        "reply_markup": reply_markup
    }
    if parse_mode:
        payload["parse_mode"] = parse_mode
    res = telegram_request("editMessageText", payload)
    if res and not res.get("ok") and "parse entities" in res.get("description", "").lower():
        logger.warning(f"Markdown parsing failed on editMessageText: {res.get('description')}. Falling back to plain text.")
        payload.pop("parse_mode", None)
        res = telegram_request("editMessageText", payload)
    if not res or not res.get("ok"):
        return send_message(chat_id, text, reply_markup=reply_markup, parse_mode=parse_mode)
    return res

def send_document(chat_id: int, file_bytes: bytes, filename: str, caption: str = "", mime_type: str = "application/pdf"):
    files = {
        "document": (filename, file_bytes, mime_type)
    }
    data = {
        "chat_id": chat_id,
        "caption": caption,
        "parse_mode": "Markdown"
    }
    res = telegram_request("sendDocument", data=data, files=files)
    if res and not res.get("ok") and "parse entities" in res.get("description", "").lower():
        logger.warning(f"Markdown parsing failed on sendDocument: {res.get('description')}. Falling back to plain text caption.")
        data.pop("parse_mode", None)
        res = telegram_request("sendDocument", data=data, files=files)
    return res

def send_chat_action(chat_id: int, action: str = "typing"):
    """Mengirim status aktivitas bot ke Telegram (typing, upload_document, dll)."""
    return telegram_request("sendChatAction", {"chat_id": chat_id, "action": action})

def answer_callback(callback_query_id: str, text: Optional[str] = None):
    payload = {"callback_query_id": callback_query_id}
    if text:
        payload["text"] = text
    return telegram_request("answerCallbackQuery", payload)

def register_bot_commands():
    commands = {
        "commands": [
            {"command": "createqt", "description": "📝 Buat Quotation Honda Baru"},
            {"command": "carirfq", "description": "🔍 Cari RFQ Berdasarkan Nomor"},
            {"command": "cariqt", "description": "🔎 Cari Quotation Berdasarkan Nomor"},
            {"command": "listrfq", "description": "📋 Lihat Daftar RFQ Terbaru Honda"},
            {"command": "status", "description": "📊 Cek Status Portal & Token"},
            {"command": "help", "description": "💡 Panduan Penggunaan"}
        ]
    }
    telegram_request("setMyCommands", commands)

def get_recent_rfqs(limit: int = 5) -> list:
    try:
        endpoint = f"/api/v1/supplier/rfqs?rowsPerPage={limit}&page=1&sortBy[0]=Rfq_Date&sortDesc[0]=true"
        res = honda_api_get(endpoint)
        if res and res.status_code == 200:
            raw = res.json()
            return raw if isinstance(raw, list) else raw.get("data", [])
    except Exception as e:
        logger.error(f"Error fetching recent RFQs: {e}")
    return []

def search_rfq_on_honda(rfq_number: str) -> Optional[Dict[str, Any]]:
    clean_num = rfq_number.strip().upper().replace("RFQ", "").strip()
    try:
        endpoint = f"/api/v1/supplier/rfqs?search={clean_num}&rowsPerPage=10&page=1"
        res = honda_api_get(endpoint)
        if res and res.status_code == 200:
            data = res.json()
            rows = data if isinstance(data, list) else data.get("data", [])
            for r in rows:
                if r.get("rfqNumber", "").strip().upper() == clean_num:
                    return r
            for r in rows:
                if clean_num in r.get("rfqNumber", "").strip().upper():
                    return r
            if rows:
                return rows[0]
    except Exception as e:
        logger.error(f"Error searching RFQ {clean_num}: {e}")
    return None

def search_quotation_on_honda(quot_or_rfq_num: str) -> Optional[Dict[str, Any]]:
    query = quot_or_rfq_num.strip().upper().replace("RFQ", "").replace("QT", "").strip()
    try:
        endpoint = f"/api/v1/supplier/quotations?rowsPerPage=100&page=1"
        res = honda_api_get(endpoint)
        if res and res.status_code == 200:
            data = res.json()
            rows = data if isinstance(data, list) else data.get("data", [])
            for q in rows:
                q_num = (q.get("quotNumber") or "").strip().upper()
                r_num = (q.get("rfqNumber") or "").strip().upper()
                if query in q_num or query in r_num:
                    return q
    except Exception as e:
        logger.error(f"Error searching quotation {query}: {e}")
    return None

def get_rfq_items_on_honda(rfq_id: int) -> list:
    try:
        endpoint = f"/api/v1/supplier/rfqs/{rfq_id}/items?rowsPerPage=50&page=1"
        res = honda_api_get(endpoint)
        if res and res.status_code == 200:
            raw = res.json()
            return raw if isinstance(raw, list) else raw.get("data", [])
    except Exception as e:
        logger.error(f"Error fetching items for RFQ {rfq_id}: {e}")
    return []

# ==============================================================================
# GENERATOR DOKUMEN WORD (.DOCX) & CONVERTER KE PDF
# ==============================================================================
# ==============================================================================
# GENERATOR DOKUMEN WORD (.DOCX) REPLIKA 100% PERSIS CONTOH USER
# ==============================================================================
def set_cell_border(cell, **kwargs):
    """Mengatur border spesifik pada cell tabel Word (OxmlElement)."""
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    tcPr = cell._tc.get_or_add_tcPr()
    tcBorders = OxmlElement('w:tcBorders')
    for edge in ('top', 'left', 'bottom', 'right'):
        edge_data = kwargs.get(edge)
        if edge_data:
            tag = 'w:' + edge
            element = OxmlElement(tag)
            element.set(qn('w:val'), edge_data.get('val', 'single'))
            element.set(qn('w:sz'), str(edge_data.get('sz', 4)))
            element.set(qn('w:space'), '0')
            element.set(qn('w:color'), edge_data.get('color', '000000'))
            tcBorders.append(element)
        else:
            tag = 'w:' + edge
            element = OxmlElement(tag)
            element.set(qn('w:val'), 'none')
            tcBorders.append(element)
    tcPr.append(tcBorders)

def format_date_str(d_str: str) -> str:
    """Konversi tanggal YYYY-MM-DD ke format '14 Oct 2026'."""
    try:
        dt = datetime.datetime.strptime(d_str[:10], "%Y-%m-%d")
        return dt.strftime("%d %b %Y")
    except Exception:
        return d_str

def calculate_lead_time_days(date_str: str, eta_str: str) -> int:
    """Hitung selisih hari lead time antara tanggal penawaran dan ETA."""
    try:
        d1 = datetime.datetime.strptime(date_str[:10], "%Y-%m-%d")
        d2 = datetime.datetime.strptime(eta_str[:10], "%Y-%m-%d")
        days = (d2 - d1).days
        return max(days, 14)
    except Exception:
        return 30

def generate_quotation_docx(payload: Dict[str, Any], rfq_data: Dict[str, Any], rfq_items: list) -> bytes:
    import docx
    from docx.shared import Inches, Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.table import WD_TABLE_ALIGNMENT

    doc = docx.Document()
    
    # Atur Ukuran Kertas & Margin Persis Asli (Letter / A4 Standard)
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11.0)
    section.top_margin = Inches(0.4)
    section.bottom_margin = Inches(0.4)
    section.left_margin = Inches(0.65)
    section.right_margin = Inches(0.65)

    base_dir = os.path.dirname(__file__)
    logo_path = os.path.join(base_dir, "assets", "apsindo_logo.png")
    stamp_path = os.path.join(base_dir, "assets", "signature_stamp.png")
    wa_icon_path = os.path.join(base_dir, "assets", "whatsapp_icon.png")

    def add_run(p, text, bold=False, size=8.5, underline=False, italic=False, font_name='Arial'):
        r = p.add_run(text)
        r.bold = bold
        r.underline = underline
        r.italic = italic
        r.font.size = Pt(size)
        r.font.name = font_name
        return r

    # --- 1. HEADER (QUOTATION di kiri, Logo & Alamat di kanan) ---
    t_top = doc.add_table(rows=1, cols=2)
    t_top.alignment = WD_TABLE_ALIGNMENT.CENTER
    t_top.autofit = False
    t_top.columns[0].width = Inches(4.2)
    t_top.columns[1].width = Inches(3.0)

    c0 = t_top.rows[0].cells[0]
    p0 = c0.paragraphs[0]
    p0.paragraph_format.space_before = Pt(12)
    r_q = p0.add_run("QUOTATION")
    r_q.bold = True
    r_q.font.size = Pt(26)
    r_q.font.name = "Arial"

    c1 = t_top.rows[0].cells[1]
    p1 = c1.paragraphs[0]
    p1.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    if os.path.exists(logo_path):
        p1.add_run().add_picture(logo_path, width=Inches(1.5))
    else:
        r_l = p1.add_run("APSINDO\n")
        r_l.bold = True
        r_l.font.size = Pt(14)

    p1_txt = c1.add_paragraph()
    p1_txt.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    p1_txt.paragraph_format.line_spacing = 1.05
    p1_txt.paragraph_format.space_before = Pt(1)

    add_run(p1_txt, "P.T. APSINDO GANANCIA PERKASA\n", bold=True, size=8.5)
    add_run(p1_txt, "Jl. Kelapa Gading Selatan BH10 no. 27\nGading Serpong - Tangerang 15810\nTel.: +62-21-547-0968\napsindo@cbn.net.id   www.apsindo-ganancia.com", size=7.5)

    # --- 2. CUSTOMER & REFERENCE META TABLE ---
    buyer_name = rfq_data.get("prByrName") or "Agus Kurniawan"
    buyer_title = f"Mr. {buyer_name.title()}" if not buyer_name.lower().startswith("mr") else buyer_name.title()

    quot_date_str = format_date_str(payload.get("date", time.strftime("%Y-%m-%d")))
    valid_date_str = format_date_str(payload.get("validDate", ""))
    lead_time_days = calculate_lead_time_days(payload.get("date", ""), payload.get("eta", ""))

    t_meta = doc.add_table(rows=1, cols=2)
    t_meta.alignment = WD_TABLE_ALIGNMENT.CENTER
    t_meta.autofit = False
    t_meta.columns[0].width = Inches(4.2)
    t_meta.columns[1].width = Inches(3.0)

    cm_left = t_meta.rows[0].cells[0]
    pm_l = cm_left.paragraphs[0]
    pm_l.paragraph_format.line_spacing = 1.15
    pm_l.paragraph_format.space_before = Pt(8)

    add_run(pm_l, "Customer detail:\n")
    add_run(pm_l, f"{buyer_title}\n", bold=True, underline=True)
    add_run(pm_l, "Purchasing Department\n")
    add_run(pm_l, "P.T. Honda Precision Parts Manufacturing\n")
    add_run(pm_l, "Kawasan Industri Indotaisei Sektor 1A Blok S\n")
    add_run(pm_l, "Kalihurip, Cikampek 41373, Karawang\n")
    add_run(pm_l, "Tel.: +62-264-350-517\n")
    add_run(pm_l, "Fax: +62-264-350-467\n")

    cm_right = t_meta.rows[0].cells[1]
    pm_r = cm_right.paragraphs[0]
    pm_r.paragraph_format.line_spacing = 1.15
    pm_r.paragraph_format.space_before = Pt(8)

    add_run(pm_r, f"Date                         : {quot_date_str}\n")
    add_run(pm_r, f"Quotation valid till  : {valid_date_str}\n\n")
    add_run(pm_r, f"Our reference          : {payload.get('number', '-')}\n")
    add_run(pm_r, "Total page(s)           : 01(one)\n\n")
    add_run(pm_r, f"Your reference        : {rfq_data.get('rfqNumber', '-')}\n")

    p_salut = doc.add_paragraph()
    p_salut.paragraph_format.space_before = Pt(8)
    p_salut.paragraph_format.space_after = Pt(4)
    add_run(p_salut, f"Dear {buyer_title};\nAs requested, here is our current pricing for the items listed.")

    # --- 3. ITEMS TABLE (5 Kolom: No, Description, Qty, Unit price Rp, Amount Rp) ---
    items = payload.get("items", [])
    num_rows = 1 + len(items) + 3 # 1 Header + Items + Subtotal + Discount + After Discount
    t_items = doc.add_table(rows=num_rows, cols=5)
    t_items.alignment = WD_TABLE_ALIGNMENT.CENTER
    t_items.autofit = False

    col_w = [Inches(0.4), Inches(3.4), Inches(0.6), Inches(1.4), Inches(1.4)]
    for r in t_items.rows:
        for idx, w in enumerate(col_w):
            r.cells[idx].width = w

    # Header Row
    r0 = t_items.rows[0].cells
    r0_texts = ["No", "D  e  s  c  r  i  p  t  i  o  n", "Qty", "Unit price Rp", "Amount Rp"]
    r0_align = [WD_ALIGN_PARAGRAPH.CENTER, WD_ALIGN_PARAGRAPH.CENTER, WD_ALIGN_PARAGRAPH.CENTER, WD_ALIGN_PARAGRAPH.RIGHT, WD_ALIGN_PARAGRAPH.RIGHT]
    for i in range(5):
        p = r0[i].paragraphs[0]
        p.alignment = r0_align[i]
        add_run(p, r0_texts[i], size=8.5)
        set_cell_border(r0[i], top={'sz': 12, 'color': '000000'}, bottom={'sz': 12, 'color': '000000'},
                               left={'sz': 12, 'color': '000000'} if i == 0 else {'sz': 8, 'color': '000000'},
                               right={'sz': 12, 'color': '000000'} if i == 4 else None)

    subtotal = 0
    item_meta_map = {it.get("rfqItId"): it for it in rfq_items}

    # Item Rows
    for idx, item in enumerate(items, start=1):
        row_cells = t_items.rows[idx].cells
        rfq_it_id = item.get("rfqItemId")
        rfq_info = item_meta_map.get(rfq_it_id, {})
        part_name = rfq_info.get("purItName") or item.get("partName") or f"Item {idx}"

        qty = item.get("qty", 1)
        price = item.get("price", 0)
        line_total = qty * price
        subtotal += line_total

        r_texts = [str(idx), part_name, str(qty), f"{price:,.0f}", f"{line_total:,.0f}"]
        r_align = [WD_ALIGN_PARAGRAPH.CENTER, WD_ALIGN_PARAGRAPH.LEFT, WD_ALIGN_PARAGRAPH.CENTER, WD_ALIGN_PARAGRAPH.RIGHT, WD_ALIGN_PARAGRAPH.RIGHT]

        for i in range(5):
            p = row_cells[i].paragraphs[0]
            p.alignment = r_align[i]
            p.paragraph_format.space_before = Pt(4)
            # Berikan ruang tinggi seperti di PDF contoh
            p.paragraph_format.space_after = Pt(25 if len(items) <= 2 else 6)
            add_run(p, r_texts[i], size=8.5)
            # Garis bawah tabel barang tebal setelah item terakhir
            is_last_item = (idx == len(items))
            set_cell_border(row_cells[i], bottom={'sz': 12, 'color': '000000'} if is_last_item else None,
                                   left={'sz': 12, 'color': '000000'} if i == 0 else {'sz': 8, 'color': '000000'},
                                   right={'sz': 12, 'color': '000000'} if i == 4 else None)

    # Subtotal Row
    row_sub = t_items.rows[1 + len(items)].cells
    p_note = row_sub[1].paragraphs[0]
    add_run(p_note, "The above rates are subject to the specified quantity requirements.", italic=True, size=8.0)
    add_run(row_sub[3].paragraphs[0], "Subtotal", size=8.5)
    row_sub[3].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT
    add_run(row_sub[4].paragraphs[0], f"{subtotal:,.0f}", size=8.5)
    row_sub[4].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT
    set_cell_border(row_sub[0], left={'sz': 12, 'color': '000000'})
    set_cell_border(row_sub[4], right={'sz': 12, 'color': '000000'})

    # Discount Row
    row_disc = t_items.rows[1 + len(items) + 1].cells
    add_run(row_disc[3].paragraphs[0], "Discount", size=8.5)
    row_disc[3].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT
    add_run(row_disc[4].paragraphs[0], "-", size=8.5)
    row_disc[4].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT
    set_cell_border(row_disc[0], left={'sz': 12, 'color': '000000'})
    set_cell_border(row_disc[4], right={'sz': 12, 'color': '000000'})

    # After Discount Row
    row_after = t_items.rows[1 + len(items) + 2].cells
    add_run(row_after[3].paragraphs[0], "After discount", size=8.5)
    row_after[3].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT
    add_run(row_after[4].paragraphs[0], f"{subtotal:,.0f}", size=8.5)
    row_after[4].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT

    for i in range(5):
        set_cell_border(row_after[i], top={'sz': 8, 'color': '000000'} if i >= 3 else None,
                               bottom={'sz': 12, 'color': '000000'},
                               left={'sz': 12, 'color': '000000'} if i == 0 else None,
                               right={'sz': 12, 'color': '000000'} if i == 4 else None)

    # --- 4. TERMS AND CONDITIONS ---
    p_terms = doc.add_paragraph()
    p_terms.paragraph_format.space_before = Pt(8)
    p_terms.paragraph_format.line_spacing = 1.15
    add_run(p_terms, "Terms and conditions:\n")
    add_run(p_terms, f"1. Lead time: {lead_time_days} days following receipt of written confirmation\n")
    add_run(p_terms, "2. Payment is due within 30 days of invoice receipt\n")
    add_run(p_terms, "3. An 11% Value Added Tax (VAT) will be applied to all prices\n")
    add_run(p_terms, "4. Pricing and delivery lead times are subject to change without prior notice\n\n")
    add_run(p_terms, "We hope this offer is satisfactory and look forward to receiving your order.\n\n")
    add_run(p_terms, "Best Regards,\n")

    # --- 5. SIGNATURE, STAMP & CONTACT ---
    t_sign = doc.add_table(rows=1, cols=2)
    t_sign.alignment = WD_TABLE_ALIGNMENT.CENTER
    t_sign.autofit = False
    t_sign.columns[0].width = Inches(5.0)
    t_sign.columns[1].width = Inches(2.2)

    cs_l = t_sign.rows[0].cells[0]
    ps_l = cs_l.paragraphs[0]
    if os.path.exists(stamp_path):
        ps_l.add_run().add_picture(stamp_path, width=Inches(1.6))

    ps_name = cs_l.add_paragraph()
    ps_name.paragraph_format.space_before = Pt(2)
    add_run(ps_name, "Arifin Purba Sigumonrong, M.Eng.(mech)\n", underline=True, size=8.5)

    p_wa = cs_l.add_paragraph()
    p_wa.paragraph_format.space_before = Pt(2)
    if os.path.exists(wa_icon_path):
        p_wa.add_run().add_picture(wa_icon_path, width=Inches(0.18))
    add_run(p_wa, "  0812 9398 6988", size=8.5)

    cs_r = t_sign.rows[0].cells[1]
    ps_r = cs_r.paragraphs[0]
    ps_r.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    add_run(ps_r, "1", size=8.5)

    buffer = io.BytesIO()
    doc.save(buffer)
    return buffer.getvalue()

def convert_docx_to_pdf_via_bridge(docx_bytes: bytes) -> Optional[bytes]:
    """Mengirim file docx ke Host Bridge (Windows Word native) untuk dikonversi menjadi PDF resmi."""
    try:
        b64_in = base64.b64encode(docx_bytes).decode("utf-8")
        url = f"{HOST_BRIDGE_URL}/convert-docx-to-pdf"
        resp = requests.post(url, json={"docx_base64": b64_in}, timeout=30)
        if resp.status_code == 200:
            res_data = resp.json()
            if res_data.get("ok") and res_data.get("pdf_base64"):
                return base64.b64decode(res_data.get("pdf_base64"))
            else:
                logger.error(f"Bridge convert returned error: {res_data.get('message')}")
        else:
            logger.error(f"Host bridge HTTP error: {resp.status_code}")
    except Exception as e:
        logger.error(f"Gagal menghubungkan ke host bridge untuk convert docx->pdf: {e}")

    # Fallback ke ReportLab jika bridge tidak tersedia
    try:
        from reportlab.lib.pagesizes import letter
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
        from reportlab.lib.styles import getSampleStyleSheet
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=letter)
        styles = getSampleStyleSheet()
        elements = [Paragraph("<b>PT APSINDO GANANCIA PERKASA - QUOTATION</b>", styles["Title"]), Spacer(1, 20)]
        elements.append(Paragraph("Quotation Document generated automatically as fallback.", styles["Normal"]))
        doc.build(elements)
        return buffer.getvalue()
    except Exception as ex:
        logger.error(f"Reportlab fallback failed: {ex}")
    return None

def build_ai_quotation_payload(user_input_text: str, rfq_data: Dict[str, Any], rfq_items: list) -> Optional[Dict[str, Any]]:
    """Menganalisis teks yang diisi oleh user menggunakan AI dan memformatnya menjadi payload API resmi Honda."""
    items_context = []
    for it in rfq_items:
        items_context.append({
            "rfqItemId": it.get("rfqItId"),
            "partCode": it.get("purItCode"),
            "partName": it.get("purItName"),
            "qty": it.get("rfqItQty", 1),
            "currentPrice": it.get("quotItPrice", 0)
        })

    prompt = f"""Anda adalah asisten AI Procurement sistem manufaktur PT Honda Precision Parts Manufacturing (HPPM).
Tugas Anda adalah memvalidasi dan memetakan input pengisian penawaran harga dari pengguna ke format JSON resmi gpsystem.id.

Data Master RFQ dari Honda:
• Nomor RFQ: {rfq_data.get('rfqNumber')}
• Tanggal RFQ: {rfq_data.get('rfqDate')}
• Daftar Item RFQ:
{json.dumps(items_context, indent=2)}

Teks Input dari Pengguna:
--- AWAL TEKS USER ---
{user_input_text}
--- AKHIR TEKS USER ---

Instruksi Pemetaan:
1. Ekstrak nomor quotation (jika tidak ada gunakan nomor default QT{time.strftime('%Y')}-001).
2. Ekstrak tanggal (YYYY-MM-DD), validDate (YYYY-MM-DD), eta (YYYY-MM-DD).
3. Ekstrak paymentTerms (e.g. END_OF_NEXT_MONTH, NET 30, COD).
4. Untuk setiap item, cocokkan rfqItemId, qty, price (harus angka murni tanpa titik/koma/Rp), hsCode, hsCodeDescription, netto, nettoUnit.

Hasilkan HANYA output JSON valid sesuai skema berikut tanpa tambahan markdown penjelas:
{{
  "number": "QT...",
  "date": "YYYY-MM-DD",
  "validDate": "YYYY-MM-DD",
  "eta": "YYYY-MM-DD",
  "currencyCode": "IDR",
  "paymentTerms": "END_OF_NEXT_MONTH",
  "items": [
    {{
      "rfqItemId": {items_context[0]['rfqItemId'] if items_context else 0},
      "partCode": "{items_context[0]['partCode'] if items_context else ''}",
      "partName": "{items_context[0]['partName'] if items_context else ''}",
      "qty": {items_context[0]['qty'] if items_context else 1},
      "price": 0,
      "hsCode": "8504.40",
      "hsCodeDescription": "LAIN-LAIN",
      "netto": "1.0000",
      "nettoUnit": "KG"
    }}
  ]
}}"""

    try:
        resp = requests.post(
            "https://openrouter.ai/api/v1/chat/completions",
            headers={"Authorization": f"Bearer {OPENROUTER_KEY}", "Content-Type": "application/json"},
            json={
                "model": "nvidia/nemotron-3-ultra-550b-a55b:free",
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0.1
            },
            timeout=20
        )
        if resp.status_code == 200:
            res_content = resp.json()["choices"][0]["message"]["content"]
            cleaned = re.sub(r'```(?:json)?', '', res_content).strip()
            match = re.search(r'(\{[\s\S]*\})', cleaned)
            if match:
                return json.loads(match.group(1))
    except Exception as e:
        logger.warning(f"AI parsing via OpenRouter error: {e}")

    # Fallback Deterministik Regex Parser
    return parse_text_submission(user_input_text, rfq_items)

def build_text_template(rfq_data: Dict[str, Any], rfq_items: list, is_edit: bool = False) -> str:
    import datetime
    today = datetime.date.today().strftime("%Y-%m-%d")
    valid = (datetime.date.today() + datetime.timedelta(days=30)).strftime("%Y-%m-%d")
    eta = (datetime.date.today() + datetime.timedelta(days=60)).strftime("%Y-%m-%d")

    num = rfq_data.get("quotNumber") if is_edit else f"QT{datetime.date.today().year}-001"
    num = (num or f"QT{datetime.date.today().year}-001").strip()
    
    tgl = rfq_data.get("quotDate", today) if is_edit else today
    val_tgl = rfq_data.get("quotValidDate", valid) if is_edit else valid
    eta_tgl = rfq_data.get("quotEta", eta) if is_edit else eta
    curr = rfq_data.get("quotCurrencyCode", "IDR") if is_edit else "IDR"
    pay = rfq_data.get("quotPaymentTerms", "END_OF_NEXT_MONTH") if is_edit else "END_OF_NEXT_MONTH"

    lines = [
        f"RFQ: {rfq_data.get('rfqNumber')}",
        f"No Quotation: {num}",
        f"Tanggal: {tgl}",
        f"Valid Hingga: {val_tgl}",
        f"ETA Kirim: {eta_tgl}",
        f"Mata Uang: {curr}",
        f"Payment Terms: {pay}",
        ""
    ]

    for idx, it in enumerate(rfq_items, start=1):
        price = it.get("quotItPrice") if is_edit and it.get("quotItPrice") else 0
        hs = it.get("quotItHsCode") if is_edit and it.get("quotItHsCode") else "8504.40"
        hs_desc = it.get("quotItHsCodeDescription") if is_edit and it.get("quotItHsCodeDescription") else "LAIN-LAIN"
        netto = it.get("quotItNetto") if is_edit and it.get("quotItNetto") else "1.0000"
        unit = it.get("quotItNettoUnit") if is_edit and it.get("quotItNettoUnit") else "KG"

        lines.append(f"--- Item {idx} [ID: {it.get('rfqItId')}] ---")
        lines.append(f"Part Code: {it.get('purItCode')}")
        lines.append(f"Part Name: {it.get('purItName')}")
        lines.append(f"Qty: {it.get('rfqItQty')}")
        lines.append(f"Harga: {price}")
        lines.append(f"HS Code: {hs}")
        lines.append(f"Deskripsi HS: {hs_desc}")
        lines.append(f"Netto: {netto}")
        lines.append(f"Satuan Netto: {unit}")
        lines.append("")

    return "\n".join(lines).strip()

def parse_text_submission(text: str, rfq_items: list) -> Optional[Dict[str, Any]]:
    try:
        def get_val(pattern, default=""):
            m = re.search(pattern, text, re.IGNORECASE)
            return m.group(1).strip() if m else default

        payload = {
            "number": get_val(r"No Quotation\s*:\s*([^\n]+)", "QT-DEFAULT"),
            "date": get_val(r"Tanggal\s*:\s*([\d\-]+)", time.strftime("%Y-%m-%d")),
            "validDate": get_val(r"Valid Hingga\s*:\s*([\d\-]+)", ""),
            "eta": get_val(r"ETA Kirim\s*:\s*([\d\-]+)", ""),
            "currencyCode": get_val(r"Mata Uang\s*:\s*([A-Za-z]+)", "IDR"),
            "paymentTerms": get_val(r"Payment Terms\s*:\s*([^\n]+)", "END_OF_NEXT_MONTH"),
            "items": []
        }

        item_blocks = re.split(r'---\s*Item\s*\d+[^-\n]*---', text, flags=re.IGNORECASE)
        actual_blocks = [b for b in item_blocks[1:] if b.strip()]

        for idx, it in enumerate(rfq_items):
            block = actual_blocks[idx] if idx < len(actual_blocks) else ""
            p_match = re.search(r'Harga\s*:\s*([\d.,]+)', block, re.IGNORECASE)
            price = int(re.sub(r'[^\d]', '', p_match.group(1))) if p_match else 0

            hs_match = re.search(r'HS Code\s*:\s*([\d.]+)', block, re.IGNORECASE)
            hs = hs_match.group(1).strip() if hs_match else "8504.40"

            hsd_match = re.search(r'Deskripsi HS\s*:\s*([^\n]+)', block, re.IGNORECASE)
            hs_desc = hsd_match.group(1).strip() if hsd_match else "LAIN-LAIN"

            netto_match = re.search(r'Netto\s*:\s*([\d.]+)', block, re.IGNORECASE)
            netto = netto_match.group(1).strip() if netto_match else "1.0000"

            unit_match = re.search(r'Satuan Netto\s*:\s*([A-Za-z]+)', block, re.IGNORECASE)
            unit = unit_match.group(1).strip() if unit_match else "KG"

            payload["items"].append({
                "rfqItemId": it.get("rfqItId"),
                "partCode": it.get("purItCode"),
                "partName": it.get("purItName"),
                "qty": it.get("rfqItQty", 1),
                "price": price,
                "hsCode": hs,
                "hsCodeDescription": hs_desc,
                "netto": netto,
                "nettoUnit": unit
            })

        return payload
    except Exception as e:
        logger.error(f"Error parsing text submission: {e}")
        return None

def execute_honda_submission(rfq_id: int, quot_id: Optional[int], payload: Dict[str, Any], pdf_bytes: Optional[bytes] = None, pdf_name: Optional[str] = None):
    token = get_honda_token()
    if not token:
        return False, "Token Honda tidak ditemukan/tidak valid."

    form_data = {
        "_method": "post",
        "number": payload.get("number", ""),
        "date": payload.get("date", ""),
        "validDate": payload.get("validDate", ""),
        "eta": payload.get("eta", ""),
        "currencyCode": payload.get("currencyCode", "IDR"),
        "paymentTerms": payload.get("paymentTerms", "END_OF_NEXT_MONTH"),
        "hsCode": payload.get("items", [{}])[0].get("hsCode", "8504.40")
    }

    for idx, item in enumerate(payload.get("items", [])):
        form_data[f"items[{idx}][rfqItemId]"] = str(item.get("rfqItemId"))
        form_data[f"items[{idx}][qty]"] = str(item.get("qty", 1))
        form_data[f"items[{idx}][price]"] = str(item.get("price", 0))
        form_data[f"items[{idx}][hsCode]"] = str(item.get("hsCode", "8504.40"))
        form_data[f"items[{idx}][hsCodeDescription]"] = str(item.get("hsCodeDescription", "LAIN-LAIN"))
        form_data[f"items[{idx}][netto]"] = str(item.get("netto", "1.0000"))
        form_data[f"items[{idx}][nettoUnit]"] = str(item.get("nettoUnit", "KG"))

    files = None
    if pdf_bytes:
        filename = pdf_name or f"Quotation_{payload.get('number', 'Doc')}.pdf"
        files = {"quotFile1": (filename, pdf_bytes, "application/pdf")}

    try:
        assign_endpoint = f"/api/v1/supplier/rfqs/{rfq_id}/assign-quotation"
        res_assign = honda_api_post(assign_endpoint, data=form_data, files=files)
        
        if not res_assign or res_assign.status_code != 200:
            err = res_assign.text[:200] if res_assign else "Koneksi ke Honda gagal"
            code = res_assign.status_code if res_assign else 500
            return False, f"Gagal saat /assign-quotation (HTTP {code}): {err}"
        
        target_quot_id = quot_id
        if not target_quot_id:
            res_items = honda_api_get(f"/api/v1/supplier/rfqs/{rfq_id}/items")
            rows = res_items.json() if res_items and res_items.status_code == 200 else []
            rows = rows if isinstance(rows, list) else rows.get("data", [])
            if rows and rows[0].get("quotItQuotationId"):
                target_quot_id = rows[0].get("quotItQuotationId")
            else:
                rfq_check = honda_api_get("/api/v1/supplier/rfqs?rowsPerPage=10&page=1")
                rfq_rows = rfq_check.json() if rfq_check and rfq_check.status_code == 200 else []
                rfq_rows = rfq_rows if isinstance(rfq_rows, list) else rfq_rows.get("data", [])
                for r in rfq_rows:
                    if r.get("rfqId") == rfq_id:
                        target_quot_id = r.get("quotId")
                        break

        if not target_quot_id:
            return True, "Data berhasil di-assign ke Honda, tetapi quotId tidak ditemukan untuk submit final."

        submit_endpoint = f"/api/v1/supplier/rfqs/{target_quot_id}/submit-quotation"
        submit_data = {"_method": "put", "status_rfq": "QUOTATION"}
        res_submit = honda_api_post(submit_endpoint, data=submit_data)
        
        if res_submit and res_submit.status_code == 200:
            return True, "Quotation berhasil di-assign dan di-submit ke status COMPLETE ✅"
        else:
            err = res_submit.text[:200] if res_submit else "Koneksi ke Honda gagal"
            code = res_submit.status_code if res_submit else 500
            return False, f"Gagal saat /submit-quotation (HTTP {code}): {err}"

    except Exception as e:
        logger.error(f"Execution error on Honda API: {e}")
        return False, str(e)

# ==============================================================================
# WORKFLOW PEMROSESAN RFQ & QUOTATION
# ==============================================================================
def process_selected_rfq(chat_id: int, rfq_number: str):
    """Mengecek data RFQ di portal Honda dan langsung memberikan template pengisian siap copy."""
    user_sessions[chat_id] = {"state": "PROCESSING_RFQ"}
    send_message(chat_id, f"🔍 *Mengecek data RFQ `{rfq_number}` di portal Honda...*")
    
    rfq_info = search_rfq_on_honda(rfq_number)
    if not rfq_info:
        send_message(chat_id, f"❌ RFQ dengan nomor `{rfq_number}` tidak ditemukan di portal Honda.\nPastikan nomor RFQ sudah sesuai (cth: `24A-090291`).")
        user_sessions.pop(chat_id, None)
        return

    rfq_id = rfq_info.get("rfqId")
    items = get_rfq_items_on_honda(rfq_id)
    quot_id = rfq_info.get("quotId")
    is_edit = bool(quot_id)

    user_sessions[chat_id]["rfq_data"] = rfq_info
    user_sessions[chat_id]["rfq_items"] = items
    user_sessions[chat_id]["is_edit"] = is_edit
    user_sessions[chat_id]["state"] = "AWAITING_TEMPLATE_FILL"

    template_text = build_text_template(rfq_info, items, is_edit=is_edit)
    status_label = "🟡 EDIT / REVISI QUOTATION" if is_edit else "🟢 CREATE QUOTATION BARU"

    msg = (
        f"*{status_label}*\n"
        f"• *Nomor RFQ*   : `{rfq_info.get('rfqNumber')}`\n"
        f"• *Batas Waktu* : `{rfq_info.get('rfqEstQuotationDate', '-')[:10]}`\n"
        f"• *Jumlah Item* : `{len(items)} item`\n\n"
        f"📋 *Silakan SALIN template di bawah, isi harga/sesuaikan datanya, lalu kirim kembali ke Bot:*\n\n"
        f"```text\n{template_text}\n```\n\n"
        f"💡 _Tip: Cukup salin teks di dalam kotak abu-abu di atas, sesuaikan baris 'Harga', lalu kirim langsung ke chat ini._"
    )
    cancel_btn = {
        "inline_keyboard": [
            [{"text": "❌ Batalkan", "callback_data": "cancel_action"}]
        ]
    }
    send_message(chat_id, msg, reply_markup=cancel_btn)

def show_rfq_search_result(chat_id: int, rfq_number: str):
    """Menampilkan detail RFQ dari fitur Cari RFQ beserta tombol aksi Buat/Edit."""
    send_message(chat_id, f"🔍 *Mencari RFQ `{rfq_number}`...*")
    rfq_info = search_rfq_on_honda(rfq_number)
    if not rfq_info:
        send_message(chat_id, f"❌ RFQ `{rfq_number}` tidak ditemukan di portal Honda.")
        return

    rfq_id = rfq_info.get("rfqId")
    quot_id = rfq_info.get("quotId")
    items = get_rfq_items_on_honda(rfq_id)

    item_lines = []
    for idx, it in enumerate(items, start=1):
        item_lines.append(f"{idx}. *{it.get('purItName')}* ({it.get('purItCode')}) - Qty: {it.get('rfqItQty')}")
    items_str = "\n".join(item_lines) if item_lines else "Tidak ada item."

    is_edit = bool(quot_id)
    btn_text = "✏️ Edit Quotation Ini" if is_edit else "📝 Buat Quotation Ini"
    status_txt = "✅ SUDAH ADA QUOTATION" if is_edit else "⏳ BELUM ADA QUOTATION"

    card = (
        f"📋 *DETAIL RFQ HONDA*\n\n"
        f"• *Nomor RFQ*  : `{rfq_info.get('rfqNumber')}`\n"
        f"• *Tanggal RFQ*: `{rfq_info.get('rfqDate')}`\n"
        f"• *Batas Waktu*: `{rfq_info.get('rfqEstQuotationDate', '-')[:10]}`\n"
        f"• *Status*     : *{status_txt}*\n\n"
        f"*Daftar Barang:*\n{items_str}\n\n"
        f"Klik tombol di bawah untuk langsung memproses penawaran tanpa perlu mengetik ulang nomor RFQ:"
    )
    buttons = {
        "inline_keyboard": [
            [{"text": btn_text, "callback_data": f"select_rfq_{rfq_info.get('rfqNumber')}"}],
            [{"text": "❌ Tutup", "callback_data": "cancel_action"}]
        ]
    }
    send_message(chat_id, card, reply_markup=buttons)

def show_quotation_search_result(chat_id: int, query: str):
    """Menampilkan detail Quotation dari fitur Cari Quotation beserta tombol edit/revisi."""
    send_message(chat_id, f"🔎 *Mencari Quotation `{query}`...*")
    quot_info = search_quotation_on_honda(query)
    if not quot_info:
        send_message(chat_id, f"❌ Quotation dengan kata kunci `{query}` tidak ditemukan.")
        return

    rfq_num = quot_info.get("rfqNumber")
    quot_num = quot_info.get("quotNumber")
    amount = quot_info.get("quotAmount", 0)
    status = quot_info.get("quotStatus", "UNKNOWN")

    card = (
        f"📑 *DETAIL QUOTATION HONDA*\n\n"
        f"• *No Quotation* : `{quot_num}`\n"
        f"• *Nomor RFQ*    : `{rfq_num}`\n"
        f"• *Tanggal Buat* : `{quot_info.get('quotDate', '-')}`\n"
        f"• *Masa Berlaku* : `{quot_info.get('quotValidDate', '-')}`\n"
        f"• *Estimasi Kirim*: `{quot_info.get('quotEta', '-')}`\n"
        f"• *Total Nilai*   : `Rp {amount:,.0f}`\n"
        f"• *Status Portal* : *{status}*\n\n"
        f"Klik tombol di bawah jika Anda ingin mengedit atau merevisi quotation ini:"
    )
    buttons = {
        "inline_keyboard": [
            [{"text": "✏️ Edit / Revisi Quotation Ini", "callback_data": f"select_rfq_{rfq_num}"}],
            [{"text": "❌ Tutup", "callback_data": "cancel_action"}]
        ]
    }
    send_message(chat_id, card, reply_markup=buttons)

# ==============================================================================
# MAIN TELEGRAM EVENT LOOP
# ==============================================================================
def handle_telegram_updates():
    register_bot_commands()
    logger.info("Memulai Telegram Bot Honda Phase 2 dengan Workflow Lengkap...")
    offset = 0

    while True:
        try:
            url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/getUpdates?offset={offset}&timeout=15"
            resp = requests.get(url, timeout=25).json()

            if not resp.get("ok"):
                time.sleep(3)
                continue

            for update in resp.get("result", []):
                offset = update["update_id"] + 1

                # 1. Handle Callback Query (Klik Tombol Inline)
                if "callback_query" in update:
                    cb = update["callback_query"]
                    cb_id = cb["id"]
                    data = cb["data"]
                    chat_id = cb["message"]["chat"]["id"]
                    session = user_sessions.get(chat_id, {})

                    if data == "cancel_action":
                        user_sessions.pop(chat_id, None)
                        answer_callback(cb_id, "Dibatalkan")
                        send_message(chat_id, "❌ Operasi telah dibatalkan.")
                        continue

                    # Turunan: Pilih RFQ dari list atau cari
                    elif data.startswith("select_rfq_"):
                        rfq_num = data.replace("select_rfq_", "")
                        answer_callback(cb_id, f"Mempersiapkan template {rfq_num}...")
                        process_selected_rfq(chat_id, rfq_num)
                        continue

                    # Tahap 1: User klik "Ya, edit data" pada preview teks awal
                    elif data == "edit_text_input":
                        answer_callback(cb_id, "Mengembalikan data teks...")
                        last_text = session.get("last_raw_input", "")
                        session["state"] = "AWAITING_TEMPLATE_FILL"
                        edit_msg = (
                            "✏️ *Silakan perbaiki data di bawah, lalu kirim kembali ke bot:*\n\n"
                            f"```text\n{last_text}\n```"
                        )
                        send_message(chat_id, edit_msg)
                        continue

                    # Tahap 1: User klik "Kirim / Lanjut ke AI"
                    elif data == "proceed_to_ai":
                        answer_callback(cb_id, "Sedang memproses...")
                        send_chat_action(chat_id, "typing")
                        
                        # Kirim pesan progres awal yang akan di-update secara live
                        status_msg = send_message(
                            chat_id,
                            "⏳ *Memulai Pemrosesan Data...*\n"
                            "• [1/3] 🤖 Membaca & memvalidasi struktur data via AI...\n"
                            "• [2/3] ⏳ Menyiapkan template Word resmi...\n"
                            "• [3/3] ⏳ Menyusun file dokumen..."
                        )
                        status_msg_id = status_msg["result"]["message_id"] if status_msg and status_msg.get("ok") else None
                        
                        raw_text = session.get("last_raw_input", "")
                        rfq_data = session.get("rfq_data", {})
                        rfq_items = session.get("rfq_items", [])

                        payload = build_ai_quotation_payload(raw_text, rfq_data, rfq_items)
                        if not payload or not payload.get("items"):
                            if status_msg_id:
                                edit_message_text(chat_id, status_msg_id, "❌ Gagal memvalidasi data pengisian. Mohon periksa format dan kirim kembali.")
                            else:
                                send_message(chat_id, "❌ Gagal memvalidasi data pengisian. Mohon periksa format dan kirim kembali.")
                            continue

                        session["pending_payload"] = payload
                        session["state"] = "AWAITING_FINAL_CONFIRM"

                        # Update progress: AI selesai, mulai buat dokumen Word
                        if status_msg_id:
                            edit_message_text(
                                chat_id,
                                status_msg_id,
                                "⏳ *Sedang Membuat Dokumen Penawaran Resmi...*\n"
                                "• [1/3] ✅ AI berhasil memvalidasi payload resmi Honda\n"
                                "• [2/3] 📄 Menyusun format tabel & kop surat PT APSINDO...\n"
                                "• [3/3] ⏳ Mengunggah file Word preview..."
                            )
                        send_chat_action(chat_id, "upload_document")

                        # 1. Buat Dokumen Word
                        docx_bytes = generate_quotation_docx(payload, rfq_data, rfq_items)
                        session["pending_docx_bytes"] = docx_bytes
                        docx_filename = f"Quotation_{payload.get('number', 'Draft')}_{rfq_data.get('rfqNumber')}.docx"

                        # Update progress selesai
                        if status_msg_id:
                            edit_message_text(
                                chat_id,
                                status_msg_id,
                                "✅ *Pemrosesan Dokumen Selesai!*\n"
                                "• [1/3] ✅ Validasi AI Sukses\n"
                                "• [2/3] ✅ Dokumen Word Resmi Siap\n"
                                "• [3/3] ✅ Mengirimkan dokumen & rincian payload di bawah..."
                            )

                        # 2. Kirim File Word ke Telegram User
                        total_amount = sum(it.get("price", 0) * it.get("qty", 1) for it in payload.get("items", []))
                        caption = (
                            f"📄 *DOKUMEN WORD PREVIEW AWAL*\n\n"
                            f"• *Nomor RFQ*    : `{rfq_data.get('rfqNumber')}`\n"
                            f"• *No Quotation* : `{payload.get('number')}`\n"
                            f"• *Total Nilai*   : `Rp {total_amount:,.0f}`\n\n"
                            f"File Word ini dibuat otomatis sesuai format resmi penawaran harga."
                        )
                        send_document(
                            chat_id,
                            docx_bytes,
                            docx_filename,
                            caption=caption,
                            mime_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        )

                        # 3. Kirim Preview Payload & 2 Tombol Aksi
                        preview_items = []
                        for idx, it in enumerate(payload.get("items", []), start=1):
                            preview_items.append(
                                f"{idx}. *{it.get('partName', 'Item')}* ({it.get('qty')} x Rp {it.get('price', 0):,.0f}) | HS: `{it.get('hsCode')}`"
                            )
                        
                        safe_payment = str(payload.get("paymentTerms", "-")).replace("_", "\\_")
                        payload_preview = (
                            f"🔍 *PREVIEW PAYLOAD RESMI (SIAP SUBMIT)*\n\n"
                            f"• *Nomor RFQ*    : `{rfq_data.get('rfqNumber')}`\n"
                            f"• *No Quotation* : `{payload.get('number')}`\n"
                            f"• *Tanggal*      : `{payload.get('date')}`\n"
                            f"• *Valid Hingga* : `{payload.get('validDate')}`\n"
                            f"• *ETA Kirim*    : `{payload.get('eta')}`\n"
                            f"• *Payment Terms*: `{safe_payment}`\n\n"
                            f"*Rincian Barang:*\n" + "\n".join(preview_items) + f"\n\n"
                            f"💰 *Total Penawaran*: `Rp {total_amount:,.0f}`\n\n"
                            f"Silakan periksa dokumen Word di atas dan rincian payload.\n"
                            f"Pilih tindakan selanjutnya:"
                        )
                        final_buttons = {
                            "inline_keyboard": [
                                [{"text": "📤 Kirim ke Portal Honda", "callback_data": "confirm_submit_honda"}],
                                [{"text": "✏️ Edit Ulang Data", "callback_data": "edit_text_input"}],
                                [{"text": "❌ Batalkan", "callback_data": "cancel_action"}]
                            ]
                        }
                        send_message(chat_id, payload_preview, reply_markup=final_buttons)
                        continue

                    # Tahap 2: User klik "Kirim ke Portal Honda" (Final Submission)
                    elif data == "confirm_submit_honda":
                        answer_callback(cb_id, "Mengonversi ke PDF & Submit...")
                        payload = session.get("pending_payload")
                        rfq_data = session.get("rfq_data", {})
                        rfq_id = rfq_data.get("rfqId")
                        quot_id = rfq_data.get("quotId")
                        docx_bytes = session.get("pending_docx_bytes")

                        if not payload or not rfq_id:
                            send_message(chat_id, "❌ Data sesi tidak ditemukan. Silakan ulangi dengan /createqt.")
                            continue

                        send_message(chat_id, "🔄 *Mengonversi dokumen Word ke PDF resmi via Native Engine...*")
                        pdf_bytes = convert_docx_to_pdf_via_bridge(docx_bytes) if docx_bytes else None

                        send_message(chat_id, "⏳ *Sedang mengirim penawaran & melampirkan file ke portal Honda (gpsystem.id)...*")
                        pdf_filename = f"Quotation_{payload.get('number', 'Doc')}_{rfq_data.get('rfqNumber')}.pdf"
                        success, msg = execute_honda_submission(rfq_id, quot_id, payload, pdf_bytes, pdf_filename)

                        if success:
                            total_amount = sum(it.get("price", 0) * it.get("qty", 1) for it in payload.get("items", []))
                            success_card = (
                                f"🎉 *QUOTATION BERHASIL DI-SUBMIT KE HONDA!*\n\n"
                                f"• *Nomor RFQ*     : `{rfq_data.get('rfqNumber')}`\n"
                                f"• *No Quotation*  : `{payload.get('number')}`\n"
                                f"• *Tanggal Kirim* : `{payload.get('eta')}`\n"
                                f"• *Total Nilai*   : `Rp {total_amount:,.0f}`\n"
                                f"• *Status Portal* : `COMPLETE ✅`\n"
                                f"• *File Lampiran* : `PDF Resmi Terunggah ({len(pdf_bytes)//1024 if pdf_bytes else 0} KB) ✅`\n\n"
                                f"📢 *Catatan Penting:*\n"
                                f"Silakan untuk mengecek di *Portal Honda (`https://gpsystem.id`)* untuk memverifikasi dokumen tender Anda."
                            )
                            # Kirimkan juga salinan PDF resmi ke chat Telegram user
                            if pdf_bytes:
                                send_document(chat_id, pdf_bytes, pdf_filename, caption=success_card, mime_type="application/pdf")
                            else:
                                send_message(chat_id, success_card)

                            user_sessions.pop(chat_id, None)
                        else:
                            send_message(chat_id, f"❌ Terjadi kesalahan saat submit ke portal Honda:\n`{msg}`\n\nSilakan klik tombol Edit untuk memperbaiki data.")
                        continue

                # 2. Handle Pesan Teks
                if "message" in update:
                    msg = update["message"]
                    chat_id = msg["chat"]["id"]
                    text = msg.get("text", "").strip()

                    # Start / Menu Bantuan
                    if text in ["/start", "/help", "💡 Panduan Penggunaan"]:
                        welcome_card = (
                            "👋 *Selamat Datang di Honda Tender Assistant!*\n\n"
                            "Bot ini membantu Anda memproses tender pengadaan suku cadang PT Honda Precision Parts Manufacturing (HPPM):\n\n"
                            "📌 *Pilihan Fitur Lengkap:*\n"
                            "• `📝 Create Quotation` (`/createqt`) : Buat penawaran harga baru.\n"
                            "• `🔍 Cari RFQ` (`/carirfq`) : Cari tender RFQ berdasarkan nomor.\n"
                            "• `🔎 Cari Quotation` (`/cariqt`) : Cari & edit quotation yang sudah ada.\n"
                            "• `📋 Daftar RFQ Terbaru` (`/listrfq`) : Lihat 5 tender terbaru.\n"
                            "• `📊 Cek Status Portal` (`/status`) : Periksa koneksi akun PT APSINDO.\n\n"
                            "Gunakan tombol di keyboard bawah untuk navigasi cepat!"
                        )
                        send_message(chat_id, welcome_card)
                        continue

                    # Cek Status Portal
                    if text in ["/status", "📊 Cek Status Portal"]:
                        token = get_honda_token()
                        status_card = (
                            "📊 *STATUS KONEKSI SISTEM HONDA*\n\n"
                            f"• *Portal Target* : `https://gpsystem.id`\n"
                            f"• *Supplier*      : `PT APSINDO GANANCIA PERKASA`\n"
                            f"• *Supplier Code* : `5100025127`\n"
                            f"• *Token Auth*    : `{'AKTIF (365 Hari) ✅' if token else 'KEDALUWARSA ⚠️'}`\n"
                            f"• *Service Status*: `ONLINE & READY 🚀`\n\n"
                            "Semua request ke portal Honda menggunakan sesi token terenkripsi."
                        )
                        send_message(chat_id, status_card)
                        continue

                    # Daftar RFQ Terbaru
                    if text in ["/listrfq", "📋 Daftar RFQ Terbaru"]:
                        send_message(chat_id, "⏳ *Mengambil daftar RFQ terbaru dari portal Honda...*")
                        recent_rfqs = get_recent_rfqs(limit=5)
                        if not recent_rfqs:
                            send_message(chat_id, "⚠️ Tidak dapat memuat daftar RFQ atau daftar kosong.")
                            continue

                        inline_buttons = []
                        rfq_texts = []
                        for idx, r in enumerate(recent_rfqs, start=1):
                            rfq_num = r.get("rfqNumber")
                            rfq_date = r.get("rfqDate", "-")
                            quot_status = r.get("quotStatus")
                            status_badge = "✅ COMPLETE" if quot_status == "COMPLETE" else "⏳ BELUM ADA"
                            rfq_texts.append(f"{idx}. `{rfq_num}` ({rfq_date}) — *{status_badge}*")
                            inline_buttons.append([{"text": f"👉 Pilih {rfq_num} ({rfq_date})", "callback_data": f"select_rfq_{rfq_num}"}])

                        rfq_list_card = (
                            "📋 *5 TENDER RFQ TERBARU DI PORTAL HONDA:*\n\n"
                            + "\n".join(rfq_texts) +
                            "\n\n*Pilih salah satu nomor RFQ di bawah untuk mulai membuat/edit quotation:*"
                        )
                        send_message(chat_id, rfq_list_card, reply_markup={"inline_keyboard": inline_buttons})
                        continue

                    # Perintah Mandiri: Create Quotation
                    if text in ["/createqt", "📝 Create Quotation", "📝 Buat / Edit Quotation"]:
                        user_sessions[chat_id] = {"state": "AWAITING_CREATE_RFQ_NUMBER"}
                        send_message(chat_id, "Silakan masukkan *Number RFQ* (cth: `RFQ 24A-090291` atau `24A-090291`):")
                        continue

                    # Perintah Mandiri: Cari RFQ
                    if text in ["/carirfq", "🔍 Cari RFQ"]:
                        user_sessions[chat_id] = {"state": "AWAITING_SEARCH_RFQ_NUMBER"}
                        send_message(chat_id, "🔍 Masukkan *Nomor RFQ* yang ingin dicari (cth: `24A-001015`):")
                        continue

                    # Perintah Mandiri: Cari Quotation
                    if text in ["/cariqt", "🔎 Cari Quotation"]:
                        user_sessions[chat_id] = {"state": "AWAITING_SEARCH_QUOT_NUMBER"}
                        send_message(chat_id, "🔎 Masukkan *Nomor Quotation* atau *Nomor RFQ* (cth: `F399` atau `QT2024-F399`):")
                        continue

                    session = user_sessions.get(chat_id, {})
                    state = session.get("state")

                    # Handle Input Nomor RFQ untuk Create Quotation
                    if state == "AWAITING_CREATE_RFQ_NUMBER":
                        rfq_number = text.strip()
                        process_selected_rfq(chat_id, rfq_number)
                        continue

                    # Handle Input Cari RFQ
                    if state == "AWAITING_SEARCH_RFQ_NUMBER":
                        user_sessions.pop(chat_id, None)
                        show_rfq_search_result(chat_id, text.strip())
                        continue

                    # Handle Input Cari Quotation
                    if state == "AWAITING_SEARCH_QUOT_NUMBER":
                        user_sessions.pop(chat_id, None)
                        show_quotation_search_result(chat_id, text.strip())
                        continue

                    # Handle Pengisian Template oleh User (baik sedang dalam sesi AWAITING_TEMPLATE_FILL atau langsung paste teks RFQ)
                    is_template_text = ("RFQ:" in text or "Harga:" in text or "No Quotation" in text)
                    if state == "AWAITING_TEMPLATE_FILL" or (is_template_text and "RFQ:" in text):
                        # Jika sesi hilang (misal bot restart), pulihkan RFQ secara otomatis dari teks yang diinput user!
                        if not session.get("rfq_data"):
                            rfq_match = re.search(r"RFQ\s*:\s*([A-Za-z0-9\-]+)", text, re.IGNORECASE)
                            if rfq_match:
                                rfq_extracted = rfq_match.group(1).strip()
                                logger.info(f"Memulihkan sesi RFQ {rfq_extracted} dari teks input...")
                                rfq_info = search_rfq_on_honda(rfq_extracted)
                                if rfq_info:
                                    items = get_rfq_items_on_honda(rfq_info.get("rfqId"))
                                    user_sessions[chat_id] = {
                                        "rfq_data": rfq_info,
                                        "rfq_items": items,
                                        "is_edit": bool(rfq_info.get("quotId"))
                                    }
                                    session = user_sessions[chat_id]

                        session["last_raw_input"] = text
                        session["state"] = "CONFIRMING_INITIAL_TEXT"

                        # Tampilkan Preview Data yang diisi user
                        p_lines = []
                        for line in text.split("\n"):
                            clean_line = line.strip()
                            if any(k in clean_line for k in ["RFQ:", "No Quotation:", "Harga:", "ETA Kirim:", "Payment Terms:"]):
                                p_lines.append(f"• {clean_line}")
                        preview_summary = "\n".join(p_lines) if p_lines else text[:300]

                        # Escape underscore agar markdown telegram tidak error
                        safe_preview_summary = preview_summary.replace("_", "\\_")

                        preview_msg = (
                            f"📝 *PREVIEW DATA PENGISIAN ANDA:*\n\n"
                            f"{safe_preview_summary}\n\n"
                            f"Apakah data yang Anda masukkan sudah sesuai, atau ingin mengedit data terlebih dahulu?"
                        )
                        step1_buttons = {
                            "inline_keyboard": [
                                [{"text": "🚀 Lanjut & Buat File Word", "callback_data": "proceed_to_ai"}],
                                [{"text": "✏️ Ya, Edit Data", "callback_data": "edit_text_input"}],
                                [{"text": "❌ Batalkan", "callback_data": "cancel_action"}]
                            ]
                        }
                        send_message(chat_id, preview_msg, reply_markup=step1_buttons)
                        continue

        except Exception as e:
            logger.error(f"Error in Telegram polling loop: {e}")
            time.sleep(3)

def start_telegram_bot_background():
    t = threading.Thread(target=handle_telegram_updates, daemon=True)
    t.start()
    logger.info("Background thread Telegram Bot Phase 2 dengan Rich UI/UX berhasil dijalankan.")

if __name__ == "__main__":
    handle_telegram_updates()
