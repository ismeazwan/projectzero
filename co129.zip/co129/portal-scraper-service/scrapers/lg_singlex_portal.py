"""
LG SINGLEX Procurement Portal Adapter (OData v2 Client)
Handles Quotation/Bid Workbench (RFQ), Buyer Attachments, Precondition Agreement, and PO Management
Tenant: L2101 (LGES)
Supplier: ID00589800 (PT. Apsindo Ganancia Perkasa)
"""

import os
import re
import json
import sqlite3
import logging
from typing import Dict, Any, List, Optional
import requests

logger = logging.getLogger("lg_singlex_portal")

DB_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data")
os.makedirs(DB_DIR, exist_ok=True)
DB_PATH = os.path.join(DB_DIR, "lg_singlex.sqlite")

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS lg_session (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            cookies_json TEXT NOT NULL,
            headers_json TEXT NOT NULL,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS notified_rfqs (
            nego_document_number TEXT PRIMARY KEY,
            nego_header_id TEXT,
            title TEXT,
            buyer_name TEXT,
            status TEXT,
            closing_date TEXT,
            notified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS notified_pos (
            po_number TEXT PRIMARY KEY,
            po_document_number TEXT,
            header_desc TEXT,
            buyer_name TEXT,
            status TEXT,
            total_amount REAL,
            currency TEXT,
            notified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()

init_db()

class LGSinglexClient:
    BASE_URL = os.getenv("LG_PORTAL_URL", "https://procurement-les.singlex.com")
    TENANT_ID = os.getenv("LG_TENANT_ID", "L2101")
    SUPPLIER_CODE = os.getenv("LG_SUPPLIER_CODE", "ID00589800")
    SUPPLIER_PCODE = os.getenv("LG_SUPPLIER_PCODE", "LGES")
    
    RFQ_SERVICE_URL = f"{BASE_URL}/sp/sc/es/esQBSupplierMgt/webapp/srv-api/odata/v2/sp.sc.es.ExtendedSourcingSupplierService/$batch"
    COMMON_SERVICE_URL = f"{BASE_URL}/supplierIndex/srv-api/odata/v2/cm.util.CommonService"
    PO_SERVICE_URL = f"{BASE_URL}/op/pu/poSuppList/webapp/srv-api/odata/v2/op.pu.poSuppListService/$batch"

    def __init__(self):
        self._load_session_from_db()

    def _load_session_from_db(self):
        self.cookies = {}
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "multipart/mixed",
            "Accept-Language": "en",
            "x-singlex-p-code": self.SUPPLIER_PCODE,
            "x-singlex-supplier-code": self.SUPPLIER_CODE,
            "x-singlex-tenant": self.TENANT_ID,
            "x-singlex-user-type": "S",
            "DataServiceVersion": "2.0",
            "MaxDataServiceVersion": "2.0",
            "sap-cancel-on-close": "true",
            "sap-contextid-accept": "header",
            "X-Requested-With": "XMLHttpRequest",
            "Origin": self.BASE_URL,
            "Referer": f"{self.BASE_URL}/supplierIndex/index.html"
        }
        try:
            conn = sqlite3.connect(DB_PATH)
            cursor = conn.cursor()
            cursor.execute("SELECT cookies_json, headers_json FROM lg_session WHERE id = 1")
            row = cursor.fetchone()
            conn.close()
            if row:
                raw_cookies = json.loads(row[0])
                cleaned_cookies = {}
                for k, v in raw_cookies.items():
                    val = str(v).strip()
                    if val.startswith("!") and "!" in val[1:]:
                        idx = val.find("!", 1)
                        if idx != -1 and idx < 40:
                            val = val[idx + 1:].strip()
                    cleaned_cookies[k] = val
                self.cookies = cleaned_cookies
                saved_headers = json.loads(row[1])
                self.headers.update(saved_headers)
        except Exception as e:
            logger.warning(f"Failed to load LG session from DB: {e}")

    def save_session(self, cookies: Dict[str, str], extra_headers: Optional[Dict[str, str]] = None):
        """Save active session cookies to SQLite"""
        self.cookies.update(cookies)
        if extra_headers:
            self.headers.update(extra_headers)
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT OR REPLACE INTO lg_session (id, cookies_json, headers_json, updated_at)
            VALUES (1, ?, ?, CURRENT_TIMESTAMP)
        """, (json.dumps(self.cookies), json.dumps(self.headers)))
        conn.commit()
        conn.close()
        logger.info("LG SINGLEX session saved successfully.")

    def parse_sap_date(self, val: Any) -> Optional[str]:
        """Convert SAP /Date(1780963200000)/ to ISO date/datetime string"""
        if not val or not isinstance(val, str):
            return None
        match = re.search(r"/Date\((\d+)\)/", val)
        if match:
            import datetime
            ts = int(match.group(1)) / 1000.0
            dt = datetime.datetime.fromtimestamp(ts, tz=datetime.timezone.utc)
            if dt.hour == 0 and dt.minute == 0 and dt.second == 0:
                return dt.strftime("%Y-%m-%d")
            return dt.strftime("%Y-%m-%d %H:%M:%S")
        return val

    def get_rfq_list(self, top: int = 20, skip: int = 0, status_filter: str = "open") -> List[Dict[str, Any]]:
        """
        Fetch Quotation/Bid Workbench records with Buyer Attachments and Sourcing Status filter
        status_filter: 'open', 'all', or specific status name
        """
        self._load_session_from_db()
        boundary = "batch_rfq_query"
        headers = dict(self.headers)
        headers["Content-Type"] = f"multipart/mixed;boundary={boundary}"
        
        # Expand NegoHeader, AwardHeaderSupplierCalc, PrecedingAttchGroupFiles (Attachments provided by buyer)
        expand_clause = "NegoHeader,AwardHeaderSupplierCalc,PrecedingAttchGroupFiles,AttchGroupFiles"
        
        batch_body = (
            f"\r\n--{boundary}\r\n"
            "Content-Type: application/http\r\n"
            "Content-Transfer-Encoding: binary\r\n\r\n"
            f"GET NegoAwardHeaderSuppliers?$skip={skip}&$top={top}&$expand={expand_clause} HTTP/1.1\r\n"
            "sap-cancel-on-close: true\r\n"
            f"x-singlex-tenant: {self.TENANT_ID}\r\n"
            "x-singlex-user-type: S\r\n"
            f"x-singlex-supplier-code: {self.SUPPLIER_CODE}\r\n"
            f"x-singlex-p-code: {self.SUPPLIER_PCODE}\r\n"
            "Accept: application/json\r\n"
            "DataServiceVersion: 2.0\r\n"
            "MaxDataServiceVersion: 2.0\r\n"
            "X-Requested-With: XMLHttpRequest\r\n\r\n\r\n"
            f"--{boundary}--\r\n"
        )
        
        resp = requests.post(self.RFQ_SERVICE_URL, headers=headers, cookies=self.cookies, data=batch_body, timeout=20)
        if resp.status_code not in (200, 202):
            logger.error(f"Failed to fetch RFQs. Status: {resp.status_code}, Body: {resp.text[:300]}")
            return []
            
        match = re.search(r'(\{[\s\S]*"results"[\s\S]*\})', resp.text)
        if not match:
            return []
            
        raw_items = json.loads(match.group(1))["d"]["results"]
        clean_rfqs = []
        for r in raw_items:
            nego = r.get("NegoHeader") or {}
            calc = r.get("AwardHeaderSupplierCalc") or {}
            
            # Extract buyer attachments (from Prerequisites section: PrecedingAttchGroupFiles)
            buyer_files = []
            pre_files_data = r.get("PrecedingAttchGroupFiles", {})
            if isinstance(pre_files_data, dict) and "results" in pre_files_data:
                for f in pre_files_data["results"]:
                    buyer_files.append({
                        "file_id": f.get("file_id"),
                        "file_seq_number": f.get("file_seq_number"),
                        "file_name": f.get("file_name") or f.get("logical_file_name"),
                        "file_size": f.get("file_size"),
                        "file_extension": f.get("file_extension"),
                        "category": "prerequisites_buyer"
                    })
            
            # General attachments
            attch_data = r.get("AttchGroupFiles", {})
            if isinstance(attch_data, dict) and "results" in attch_data:
                for f in attch_data["results"]:
                    buyer_files.append({
                        "file_id": f.get("file_id"),
                        "file_seq_number": f.get("file_seq_number"),
                        "file_name": f.get("file_name") or f.get("logical_file_name"),
                        "file_size": f.get("file_size"),
                        "file_extension": f.get("file_extension"),
                        "category": "general_attachment"
                    })

            sourcing_status = nego.get("approval_nego_progress_status_name") or r.get("approval_nego_progress_status_name") or "Unknown"
            remain_sec = calc.get("remain_second")
            is_agreed = r.get("preceding_condition_agree_flag", False)
            
            # Filter logic: if status_filter == 'open', keep items that are Open / In Progress or countdown is active
            if status_filter.lower() == "open":
                is_open = (
                    "open" in sourcing_status.lower() 
                    or "bidding" in sourcing_status.lower() 
                    or "in progress" in sourcing_status.lower()
                    or (remain_sec is not None and remain_sec > 0)
                )
                if not is_open:
                    continue

            clean_rfqs.append({
                "nego_document_number": nego.get("nego_document_number"),
                "nego_header_id": r.get("nego_header_id"),
                "title": nego.get("nego_document_title"),
                "buyer_name": nego.get("buyer_name"),
                "sourcing_status": sourcing_status,
                "response_status": r.get("supp_response_status_name"),
                "remain_second": remain_sec,
                "actual_closing_date_time": self.parse_sap_date(nego.get("actual_closing_date_time")),
                "publish_date_time": self.parse_sap_date(nego.get("publish_date_time")),
                "bidding_amount": r.get("bidding_amount"),
                "bidding_currency": r.get("bidding_currency_code"),
                "is_agreed": bool(is_agreed),
                "buyer_attachments": buyer_files,
                "has_attachments": len(buyer_files) > 0,
                "is_awarded": r.get("award_flag", False)
            })
        return clean_rfqs

    def download_buyer_file(self, file_id: str, file_seq: int = 1) -> Optional[bytes]:
        """
        Download physical binary attachment file provided by the buyer
        """
        url = f"{self.COMMON_SERVICE_URL}/File_Dtl(tenant_id='{self.TENANT_ID}',file_id='{file_id}',file_seq_number={file_seq})/$value"
        resp = requests.get(url, headers=self.headers, cookies=self.cookies, timeout=30)
        if resp.status_code == 200:
            return resp.content
        logger.error(f"Failed to download file {file_id}. Status: {resp.status_code}")
        return None

    def agree_prerequisites(self, nego_header_id: int) -> bool:
        """
        Submit 'I Agree' to the prerequisites section before bidding
        """
        url = f"{self.RFQ_SERVICE_URL}"
        boundary = "batch_agree_submit"
        headers = dict(self.headers)
        headers["Content-Type"] = f"multipart/mixed;boundary={boundary}"
        
        # Update preceding_condition_agree_flag = True
        body_json = json.dumps({
            "tenant_id": self.TENANT_ID,
            "nego_header_id": nego_header_id,
            "supplier_code": self.SUPPLIER_CODE,
            "preceding_condition_agree_flag": True
        })
        
        batch_body = (
            f"\r\n--{boundary}\r\n"
            "Content-Type: application/http\r\n"
            "Content-Transfer-Encoding: binary\r\n\r\n"
            f"MERGE NegoAwardHeaderSuppliers(tenant_id='{self.TENANT_ID}',nego_header_id={nego_header_id}L,supplier_code='{self.SUPPLIER_CODE}') HTTP/1.1\r\n"
            "Content-Type: application/json\r\n"
            "Accept: application/json\r\n"
            f"x-singlex-tenant: {self.TENANT_ID}\r\n"
            f"x-singlex-supplier-code: {self.SUPPLIER_CODE}\r\n\r\n"
            f"{body_json}\r\n"
            f"--{boundary}--\r\n"
        )
        resp = requests.post(url, headers=headers, cookies=self.cookies, data=batch_body, timeout=20)
        return resp.status_code in (200, 202, 204)

    def get_po_list(self, top: int = 20, skip: int = 0) -> List[Dict[str, Any]]:
        """
        Fetch Purchase Orders from Po_SuppListView
        """
        self._load_session_from_db()
        boundary = "batch_po_query"
        headers = dict(self.headers)
        headers["Content-Type"] = f"multipart/mixed;boundary={boundary}"
        
        batch_body = (
            f"\r\n--{boundary}\r\n"
            "Content-Type: application/http\r\n"
            "Content-Transfer-Encoding: binary\r\n\r\n"
            f"GET Po_SuppListView?$skip={skip}&$top={top}&$orderby=po_date%20desc HTTP/1.1\r\n"
            "sap-cancel-on-close: true\r\n"
            f"x-singlex-tenant: {self.TENANT_ID}\r\n"
            "x-singlex-user-type: S\r\n"
            f"x-singlex-supplier-code: {self.SUPPLIER_CODE}\r\n"
            f"x-singlex-p-code: {self.SUPPLIER_PCODE}\r\n"
            "Accept: application/json\r\n"
            "DataServiceVersion: 2.0\r\n"
            "MaxDataServiceVersion: 2.0\r\n"
            "X-Requested-With: XMLHttpRequest\r\n\r\n\r\n"
            f"--{boundary}--\r\n"
        )
        
        resp = requests.post(self.PO_SERVICE_URL, headers=headers, cookies=self.cookies, data=batch_body, timeout=20)
        if resp.status_code not in (200, 202):
            logger.error(f"Failed to fetch POs. Status: {resp.status_code}, Body: {resp.text[:300]}")
            return []
            
        match = re.search(r'(\{[\s\S]*"results"[\s\S]*\})', resp.text)
        if not match:
            return []
            
        raw_items = json.loads(match.group(1))["d"]["results"]
        clean_pos = []
        for p in raw_items:
            clean_pos.append({
                "po_number": p.get("po_number"),
                "po_document_number": p.get("po_document_number"),
                "po_header_desc": p.get("po_header_desc"),
                "po_descs": p.get("po_descs") or p.get("po_header_desc"),
                "po_item_type_code": p.get("po_item_type_code"),
                "po_item_type_name": p.get("po_item_type_name") or "MRO",
                "material_code": p.get("material_cods"),
                "buyer_name": p.get("buyer_name"),
                "buyer_department": p.get("buyer_department_name"),
                "po_date": self.parse_sap_date(p.get("po_date")),
                "po_status": p.get("po_status_name"),
                "total_amount": p.get("total_po_amount"),
                "currency": p.get("currency_code"),
                "payment_terms": p.get("payterms_name"),
                "incoterms": p.get("incoterms_name"),
                "supplier_receipt_flag": p.get("supplier_receipt_flag"),
                "print_enable_yn": p.get("print_enable_yn")
            })
        return clean_pos

    def acknowledge_receipt(self, po_number: str) -> bool:
        """
        Submit Receipt confirmation for a given PO in LG SINGLEX
        Updates supplier_receipt_flag = True
        """
        boundary = "batch_po_receipt"
        headers = dict(self.headers)
        headers["Content-Type"] = f"multipart/mixed;boundary={boundary}"
        
        # Cari detail po_document_number & degree dari list jika perlu
        pos = self.get_po_list(top=20)
        target_po = next((p for p in pos if str(p.get("po_number")) == str(po_number) or str(p.get("po_document_number")) == str(po_number)), None)
        
        doc_no = target_po.get("po_document_number", po_number) if target_po else po_number
        
        body_json = json.dumps({
            "tenant_id": self.TENANT_ID,
            "company_code": self.SUPPLIER_PCODE,
            "po_document_number": doc_no,
            "supplier_receipt_flag": True
        })
        
        batch_body = (
            f"\r\n--{boundary}\r\n"
            "Content-Type: application/http\r\n"
            "Content-Transfer-Encoding: binary\r\n\r\n"
            f"MERGE Po_SuppListView(tenant_id='{self.TENANT_ID}',company_code='{self.SUPPLIER_PCODE}',po_document_number='{doc_no}',degree=0L) HTTP/1.1\r\n"
            "Content-Type: application/json\r\n"
            "Accept: application/json\r\n"
            f"x-singlex-tenant: {self.TENANT_ID}\r\n"
            f"x-singlex-supplier-code: {self.SUPPLIER_CODE}\r\n"
            f"x-singlex-p-code: {self.SUPPLIER_PCODE}\r\n\r\n"
            f"{body_json}\r\n"
            f"--{boundary}--\r\n"
        )
        
        resp = requests.post(self.PO_SERVICE_URL, headers=headers, cookies=self.cookies, data=batch_body, timeout=20)
        if resp.status_code in (200, 202, 204):
            logger.info(f"Successfully acknowledged receipt for PO {po_number}")
            return True
        logger.warning(f"Receipt acknowledgement response status: {resp.status_code}")
        return resp.status_code in (200, 202, 204)

    def get_po_detail_items(self, po_document_number: str) -> List[Dict[str, Any]]:
        """
        Fetch full item breakdown lines for a specific PO
        """
        boundary = "batch_po_items"
        headers = dict(self.headers)
        headers["Content-Type"] = f"multipart/mixed;boundary={boundary}"
        
        batch_body = (
            f"\r\n--{boundary}\r\n"
            "Content-Type: application/http\r\n"
            "Content-Transfer-Encoding: binary\r\n\r\n"
            f"GET Po_SuppListItemView?$filter=po_document_number%20eq%20'{po_document_number}' HTTP/1.1\r\n"
            "sap-cancel-on-close: true\r\n"
            f"x-singlex-tenant: {self.TENANT_ID}\r\n"
            "x-singlex-user-type: S\r\n"
            f"x-singlex-supplier-code: {self.SUPPLIER_CODE}\r\n"
            f"x-singlex-p-code: {self.SUPPLIER_PCODE}\r\n"
            "Accept: application/json\r\n\r\n\r\n"
            f"--{boundary}--\r\n"
        )
        
        resp = requests.post(self.PO_SERVICE_URL, headers=headers, cookies=self.cookies, data=batch_body, timeout=20)
        if resp.status_code not in (200, 202):
            return []
            
        match = re.search(r'(\{[\s\S]*"results"[\s\S]*\})', resp.text)
        if not match:
            return []
            
        raw_items = json.loads(match.group(1))["d"]["results"]
        clean_items = []
        for it in raw_items:
            clean_items.append({
                "item_number": it.get("po_item_number"),
                "desc": it.get("po_desc"),
                "quantity": it.get("po_quantity"),
                "unit": it.get("po_unit"),
                "net_price": it.get("po_net_price"),
                "amount": it.get("po_amount"),
                "delivery_date": self.parse_sap_date(it.get("delivery_request_date")),
                "org_name": it.get("org_name"),
                "incoterms": it.get("incoterms_name")
            })
        return clean_items

    def get_official_po_sheet_data(self, po_document_number: str, company_code: str = "LGESHM") -> Optional[Dict[str, Any]]:
        """
        Fetch official OZ Report PO Sheet data from PoSheetPrintV4Service
        """
        url = f"{self.BASE_URL}/srv-api/odata/v4/op.pu.PoSheetPrintV4Service/PrintPos"
        headers = dict(self.headers)
        headers["Accept"] = "application/json"
        headers["Content-Type"] = "application/json"
        
        payload = {
            "inputData": {
                "po_no": [
                    {
                        "c": company_code,
                        "n": po_document_number,
                        "name_plate_yn": "N"
                    }
                ]
            }
        }
        
        try:
            resp = requests.post(url, headers=headers, cookies=self.cookies, json=payload, timeout=20)
            if resp.status_code == 200:
                data = resp.json()
                items = data.get("list", [])
                if items:
                    return items[0]
            logger.warning(f"PoSheetPrintV4Service returned {resp.status_code}")
        except Exception as e:
            logger.error(f"Error fetching PoSheetPrintV4Service: {e}")
        return None

    def check_session(self) -> bool:
        """
        Verify whether current session cookies can query Singlex OData endpoint
        """
        try:
            self._load_session_from_db()
            test_pos = self.get_po_list(top=1)
            return bool(test_pos)
        except Exception:
            return False

    def search_po(self, query: str) -> List[Dict[str, Any]]:
        """
        Search POs by SAP PO Number, Singlex Document Number, or description
        """
        matched = []
        try:
            pos = self.get_po_list(top=100)
            q_clean = query.strip().lower()
            for p in pos:
                num = str(p.get("po_number") or "").lower()
                doc = str(p.get("po_document_number") or "").lower()
                desc = str(p.get("po_header_desc") or p.get("po_descs") or "").lower()
                if q_clean in num or q_clean in doc or q_clean in desc:
                    matched.append(p)
        except Exception as e:
            logger.error(f"Error searching PO in LGSinglexClient: {e}")
        return matched

    def search_rfq(self, query: str) -> List[Dict[str, Any]]:
        """
        Search RFQs by RFQ Document Number, Title, or Buyer Name
        """
        matched = []
        try:
            rfqs = self.get_rfq_list(top=100, status_filter="all")
            q_clean = query.strip().lower()
            for r in rfqs:
                doc = str(r.get("nego_document_number") or "").lower()
                title = str(r.get("title") or "").lower()
                buyer = str(r.get("buyer_name") or "").lower()
                if q_clean in doc or q_clean in title or q_clean in buyer:
                    matched.append(r)
        except Exception as e:
            logger.error(f"Error searching RFQ in LGSinglexClient: {e}")
        return matched

# Singleton client instance
lg_client = LGSinglexClient()
