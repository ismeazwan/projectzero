import os
import time
import pyotp
from playwright.sync_api import sync_playwright

def scrape_hyundai_portal(user_id: str, password: str, totp_secret: str, base_url: str = None):
    """
    Melakukan login otomatis ke Portal Hyundai (GSCM/Mock) dengan Google Authenticator (TOTP),
    dan mengekstrak data Purchase Order (PO) serta buletin regulasi CSR.
    """
    target_url = base_url or os.getenv("HYUNDAI_TARGET_URL", "http://host.docker.internal:3000/index.html")
    
    result = {
        "status": "success",
        "portal": "Hyundai GSCM & VAATZ",
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "authenticatedUser": user_id,
        "scrapedPurchaseOrders": [],
        "scrapedBulletins": [],
        "errors": []
    }

    with sync_playwright() as p:
        browser = p.chromium.launch(
            headless=True,
            args=["--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage"]
        )
        context = browser.new_context(viewport={"width": 1920, "height": 1080})
        page = context.new_page()

        # Intercept respon data API jika tersedia
        def on_response(response):
            if "/api/dashboard-data" in response.url:
                try:
                    data = response.json()
                    if "purchaseOrders" in data:
                        result["scrapedPurchaseOrders"] = data["purchaseOrders"]
                    if "bulletins" in data:
                        result["scrapedBulletins"] = data["bulletins"]
                except:
                    pass

        page.on("response", on_response)

        try:
            print(f"[*] Membuka portal di: {target_url}")
            page.goto(target_url, timeout=30000)
            page.wait_for_selector("#userId, input[name='userId']", timeout=15000)

            # 1. Input ID & Password
            page.fill("#userId, input[name='userId']", user_id)
            page.fill("#userPwd, input[name='password']", password)

            # 2. Hitung OTP Google Authenticator secara otomatis
            totp = pyotp.TOTP(totp_secret)
            otp_code = totp.now()
            print(f"[*] OTP dihitung: {otp_code}")
            page.fill("#userOtp, input[name='otp']", otp_code)

            # 3. Klik tombol Login
            page.click("#loginBtn, button[type='submit']")

            # 4. Tunggu transisi ke dashboard
            page.wait_for_timeout(4000)

            # 5. Jika network intercept belum menangkap, ambil dari DOM tabel
            if not result["scrapedPurchaseOrders"]:
                rows = page.locator("#poTableBody tr, table tr").all()
                for r in rows:
                    tds = r.locator("td").all_inner_texts()
                    if len(tds) >= 5:
                        result["scrapedPurchaseOrders"].append({
                            "poNumber": tds[0],
                            "partNumber": tds[1],
                            "partName": tds[2],
                            "quantity": tds[3],
                            "deliveryDate": tds[4]
                        })

        except Exception as e:
            result["status"] = "partial_or_failed"
            result["errors"].append(str(e))
            print(f"[-] Error saat scraping: {e}")
        finally:
            browser.close()

    return result

