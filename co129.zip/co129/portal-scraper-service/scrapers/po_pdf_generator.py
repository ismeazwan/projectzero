import io
import os
from reportlab.lib.pagesizes import A4  # 595.27 x 841.89 pt
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

LOGO_PATH = os.path.join(os.path.dirname(__file__), "lg_logo.jpg")
if not os.path.exists(LOGO_PATH):
    LOGO_PATH = os.path.join(os.path.dirname(__file__), "scrapers", "lg_logo.jpg")

# =========================================================================
# 1. MRO LAYOUT GENERATOR (100% Faithful to Singlex MRO Narrow Margin)
# =========================================================================
def draw_mro_lg_po_pdf(oz_data: dict) -> bytes:
    buffer = io.BytesIO()
    
    # Narrow Margin: 20pt all around -> Printable Width = 555.27 pt
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        leftMargin=20,
        rightMargin=20,
        topMargin=20,
        bottomMargin=20
    )
    
    styles = getSampleStyleSheet()
    
    company_right_style = ParagraphStyle(
        'CompanyRightMRO_v3',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=7,
        leading=9.2,
        alignment=0
    )
    title_style = ParagraphStyle(
        'DocTitleMRO_v3',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=18,
        leading=22,
        alignment=1
    )
    meta_label = ParagraphStyle('MetaLabelMRO_v3', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=7.5, leading=9.5)
    meta_val = ParagraphStyle('MetaValMRO_v3', parent=styles['Normal'], fontName='Helvetica', fontSize=7.5, leading=9.5)
    
    th_style = ParagraphStyle('THMRO_v3', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=7, leading=9, alignment=1)
    td_c = ParagraphStyle('TDCMRO_v3', parent=styles['Normal'], fontName='Helvetica', fontSize=7, leading=9, alignment=1)
    td_l = ParagraphStyle('TDLMRO_v3', parent=styles['Normal'], fontName='Helvetica', fontSize=7, leading=9, alignment=0)
    td_r = ParagraphStyle('TDRMRO_v3', parent=styles['Normal'], fontName='Helvetica', fontSize=7, leading=9, alignment=2)
    
    tot_label = ParagraphStyle('TotLblMRO_v3', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=7.5, leading=9.5, alignment=0)
    tot_curr = ParagraphStyle('TotCurMRO_v3', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=7.5, leading=9.5, alignment=2)
    tot_val = ParagraphStyle('TotValMRO_v3', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=7.5, leading=9.5, alignment=2)
    inco_val = ParagraphStyle('IncoValMRO_v3', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=7.5, leading=9.5, alignment=1)
    
    num_style = ParagraphStyle('NumMRO_v3', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=6.5, leading=8.5, alignment=0)
    clause_body = ParagraphStyle('ClauseMRO_v3', parent=styles['Normal'], fontName='Helvetica', fontSize=6.2, leading=7.8)
    
    story = []
    
    # 1. Header (Logo on Left, HLI Green Power Address on Right)
    logo_img = Image(LOGO_PATH, width=150, height=28) if os.path.exists(LOGO_PATH) else Paragraph("<b>LG Energy Solution</b>", title_style)
    hli_addr_text = (
        "<b>PT. HLI Green Power</b><br/>"
        "KNIC (Karawang New Industry City) Jl Trans<br/>"
        "Heksa Karawang Km. 7 Block C No. 1, Wanajaya,<br/>"
        "Telukjambe Barat Jawa Barat – 41361, Indonesia<br/>"
        "<b>NPWP No : 43.250.897.6-408.000</b><br/>"
        "Tel)<br/>Fax)"
    )
    t_top = Table([[logo_img, Paragraph(hli_addr_text, company_right_style)]], colWidths=[355, 200])
    t_top.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('LEFTPADDING', (0,0), (-1,-1), 0),
        ('RIGHTPADDING', (0,0), (-1,-1), 0),
        ('TOPPADDING', (0,0), (-1,-1), 0),
        ('BOTTOMPADDING', (0,0), (-1,-1), 0),
    ]))
    story.append(t_top)
    story.append(Spacer(1, 8))
    
    # 2. Main Title: Purchase order
    story.append(Paragraph("Purchase order", title_style))
    story.append(Spacer(1, 10))
    
    # 3. Metadata Table
    po_no = str(oz_data.get('id') or oz_data.get('po_number') or '-')
    po_date = str(oz_data.get('po_date') or '-')
    buyer_name = str(oz_data.get('representative_name') or oz_data.get('buyer_name') or '-')
    buyer_email = str(oz_data.get('representative_email') or '-')
    vendor_name = str(oz_data.get('vendor_name') or 'PT. Apsindo Ganancia Perkasa')
    vendor_code = str(oz_data.get('vendor_id') or 'ID00589800')
    vendor_addr = f"{oz_data.get('address', 'Tangerang, Banten')}Jl. Kelapa Gading SelatanBH10/27Gading Serpong\nTangerang 15810"
    
    meta_rows = [
        [
            Paragraph("Supplier :", meta_label),
            Paragraph(vendor_name, meta_val),
            Paragraph("PO No. :", meta_label),
            Paragraph(po_no, meta_val)
        ],
        [
            Paragraph("Supplier Code :", meta_label),
            Paragraph(vendor_code, meta_val),
            Paragraph("PO Date :", meta_label),
            Paragraph(po_date, meta_val)
        ],
        [
            Paragraph(vendor_addr.replace("\n", "<br/>"), meta_val),
            "", # spanned
            Paragraph("Buyer :", meta_label),
            Paragraph(buyer_name, meta_val)
        ],
        [
            "",
            "",
            Paragraph("Buyer Email :", meta_label),
            Paragraph(buyer_email, meta_val)
        ]
    ]
    t_meta = Table(meta_rows, colWidths=[70, 260, 70, 155])
    t_meta.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('LEFTPADDING', (0,0), (-1,-1), 0),
        ('RIGHTPADDING', (0,0), (-1,-1), 0),
        ('TOPPADDING', (0,0), (-1,-1), 1),
        ('BOTTOMPADDING', (0,0), (-1,-1), 1),
        ('SPAN', (0,2), (1,3)),
    ]))
    story.append(t_meta)
    story.append(Spacer(1, 10))
    
    # 4. Item Table (Col widths sum to 555 pt: [28, 160, 48, 60, 65, 120, 74])
    currency = oz_data.get("currency_code", "IDR")
    total_amt = float(oz_data.get("total_amount") or 0)
    incoterms = str(oz_data.get("delivery_terms_condition") or oz_data.get("delivery_terms_name") or "DAP")
    items = oz_data.get("po_items", [])
    
    col_widths = [28, 160, 48, 60, 65, 120, 74]
    
    item_header = [
        Paragraph("No.", th_style),
        Paragraph("ItemCode/ItemName", th_style),
        Paragraph("Quantity", th_style),
        Paragraph("UoM", th_style),
        Paragraph("Unit Price", th_style),
        Paragraph("Amount", th_style),
        Paragraph("Delivery Date", th_style)
    ]
    
    table_rows = [item_header]
    if items:
        for it in items:
            code = it.get('item_code', '')
            name = it.get('item_name', '')
            item_desc = f"{code}/<br/>{name}" if code and code != '-' else name
            u_price = float(it.get('unit_price') or 0)
            amt = float(it.get('amount') or 0)
            qty = float(it.get('quantity') or 1)
            
            table_rows.append([
                Paragraph(str(it.get('item_line_no', 10)), td_c),
                Paragraph(item_desc, td_l),
                Paragraph(f"{qty:,.3f}", td_c),
                Paragraph(str(it.get('item_unit') or 'EA'), td_c),
                Paragraph(f"{u_price:,.2f}", td_r),
                Paragraph(f"{amt:,.2f}", td_r),
                Paragraph(str(it.get('delivery_due_date') or '-'), td_c)
            ])
    else:
        table_rows.append([
            Paragraph("10", td_c),
            Paragraph(str(oz_data.get('po_header_desc') or '-'), td_l),
            Paragraph("1.000", td_c),
            Paragraph("EA", td_c),
            Paragraph(f"{total_amt:,.2f}", td_r),
            Paragraph(f"{total_amt:,.2f}", td_r),
            Paragraph(po_date, td_c)
        ])
        
    # Total Amount row
    table_rows.append([
        "", "",
        Paragraph("<b>Total Amount :</b>", tot_label),
        "",
        Paragraph(f"<b>{currency}</b>", tot_curr),
        Paragraph(f"<b>{total_amt:,.2f}</b>", tot_val),
        ""
    ])
    
    # Incoterms row
    table_rows.append([
        "", "",
        Paragraph("<b>Incoterms :</b>", tot_label),
        "",
        Paragraph(f"<b>{incoterms}</b>", inco_val),
        "",
        ""
    ])
    
    t_items = Table(table_rows, colWidths=col_widths)
    t_items.setStyle(TableStyle([
        ('BOX', (0,0), (-1,-3), 0.75, colors.black),
        ('INNERGRID', (0,0), (-1,-3), 0.5, colors.black),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('TOPPADDING', (0,0), (-1,-1), 2.5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 2.5),
        ('LEFTPADDING', (0,0), (-1,-1), 3),
        ('RIGHTPADDING', (0,0), (-1,-1), 3),
        ('SPAN', (2,-2), (3,-2)),
        ('SPAN', (2,-1), (3,-1)),
    ]))
    story.append(t_items)
    story.append(Spacer(1, 6))
    
    # 5. Table 5: Origin & Payment Term (sum = 555 pt)
    payterm = str(oz_data.get('payment_terms_name') or 'T/T 60 Days from Document date')
    footer_row = [
        [
            Paragraph("<b>Origin :</b>", meta_label),
            "",
            Paragraph("<b>Payment Term :</b>", ParagraphStyle('PTL_v3', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=8, alignment=2)),
            Paragraph(f"<b>{payterm}</b>", ParagraphStyle('PTV_v3', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=8, alignment=0))
        ]
    ]
    t_foot = Table(footer_row, colWidths=[60, 210, 95, 190])
    t_foot.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('LEFTPADDING', (0,0), (-1,-1), 0),
        ('RIGHTPADDING', (0,0), (-1,-1), 0),
        ('TOPPADDING', (0,0), (-1,-1), 0),
        ('BOTTOMPADDING', (0,0), (-1,-1), 0),
    ]))
    story.append(t_foot)
    story.append(Spacer(1, 6))
    
    # 6. Table 6: Clauses 1 to 7 (sum = 555 pt)
    clauses_data = [
        [
            Paragraph("1.", num_style),
            Paragraph("<b>Quality and Inspection Standard :</b> The standard set by the parties, industry standard and country standard.<br/>In case of discrepancy, the highest standard shall apply.", clause_body)
        ],
        [
            Paragraph("2.", num_style),
            Paragraph("<b>Place of Delivery :</b> Buyer's plant or the place directed by Buyer.", clause_body)
        ],
        [
            Paragraph("3.", num_style),
            Paragraph("<b>Time is of the essence.</b> If Seller fails to make deliveries of perform services at the agreed time, any and all damages incurred to Buyer and any special premium transportation or other costs required to complete the specified delivery schedule will be charged at the expenses of Seller.<br/>Without prejudice to any other rights Buyer may have, in the event of failure in delivery within the guaranteed time specified in this Contract, Seller shall pay liquidated damages to the Purchaser, at the rate of zero point five percent(0.5%) of the contract price for each week of the delay.", clause_body)
        ],
        [
            Paragraph("4.", num_style),
            Paragraph("<b>Supplier represents and warrants</b> the products conform to the specification provided by Buyer, quality and packing standard mutually negotiated by parties, and free from defect. Buyer may claim replacement or refund of nonconforming products to Supplier and Supplier shall compensate the damage of Buyer.", clause_body)
        ],
        [
            Paragraph("5.", num_style),
            Paragraph("<b>Seller shall liable</b> for any or all damages and losses incurred by Buyer and occasioned by or arising out of (a) any defect in products, (b) Seller's breach of any obligations or (c) fault or negligence of Seller.", clause_body)
        ],
        [
            Paragraph("6.", num_style),
            Paragraph("<b>Dispute Resolution :</b> By Arbitration at __________________ Arbitration Association", clause_body)
        ],
        [
            Paragraph("7.", num_style),
            Paragraph("<b>Misc. :</b>", clause_body)
        ]
    ]
    t_clauses = Table(clauses_data, colWidths=[14, 541])
    t_clauses.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('LEFTPADDING', (0,0), (-1,-1), 0),
        ('RIGHTPADDING', (0,0), (-1,-1), 0),
        ('TOPPADDING', (0,0), (-1,-1), 0.5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 0.5),
    ]))
    story.append(t_clauses)
    story.append(Spacer(1, 4))
    
    # 7. Table 7: Additional Conditions (sum = 555 pt)
    add_cond_data = [
        [
            Paragraph("<b>Additional Conditions :</b>", ParagraphStyle('AC_v3', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=6.2, leading=8)),
            Paragraph("<b>1)</b> A product or service shall be provided in accordance with the agreed upon samples or specifications.", clause_body)
        ],
        [
            "",
            Paragraph("<b>2)</b> All matters related to supply shall be pursuant to our 'Basic Transaction(Sales) Agreement' or General Terms for Procurement'.", clause_body)
        ],
        [
            "",
            Paragraph("<b>3)</b> The contract can be revoked within 10 days after the due date when the product is not delivered.", clause_body)
        ]
    ]
    t_add_cond = Table(add_cond_data, colWidths=[95, 460])
    t_add_cond.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('LEFTPADDING', (0,0), (-1,-1), 0),
        ('RIGHTPADDING', (0,0), (-1,-1), 0),
        ('TOPPADDING', (0,0), (-1,-1), 0.5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 0.5),
    ]))
    story.append(t_add_cond)
    story.append(Spacer(1, 3))
    
    story.append(Paragraph("Please deliver the product in accordance with the above mentioned contents and the due date.", clause_body))
    story.append(Spacer(1, 3))
    story.append(Paragraph("<b>Remark :</b>", ParagraphStyle('RemLbl_v3', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=6.5, leading=8)))
    story.append(Spacer(1, 8))
    
    # 8. Signatures Block (Natural flow on Page 1 for standard 1-page PO)
    sig_cols = [
        [
            Paragraph("<b>PT. Apsindo Ganancia Perkasa</b>", ParagraphStyle('S1MRO_v3', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=8, alignment=1)),
            Paragraph("<b>PT. HLI Green Power</b>", ParagraphStyle('S2MRO_v3', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=8, alignment=1))
        ],
        [
            Paragraph("<br/><br/>________________________________________", ParagraphStyle('S3MRO_v3', parent=styles['Normal'], fontName='Helvetica', fontSize=8, alignment=1)),
            Paragraph("<br/><br/>________________________________________", ParagraphStyle('S4MRO_v3', parent=styles['Normal'], fontName='Helvetica', fontSize=8, alignment=1))
        ]
    ]
    t_sig = Table(sig_cols, colWidths=[277, 278])
    t_sig.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('ALIGN', (0,0), (-1,-1), 'CENTER'),
        ('TOPPADDING', (0,0), (-1,-1), 0),
        ('BOTTOMPADDING', (0,0), (-1,-1), 0),
    ]))
    story.append(t_sig)
    
    doc.build(story)
    buffer.seek(0)
    return buffer.getvalue()


# =========================================================================
# 2. EQUIPMENT LAYOUT GENERATOR (100% Faithful to Singlex Equipment Narrow Margin)
# =========================================================================
def draw_equipment_lg_po_pdf(oz_data: dict) -> bytes:
    buffer = io.BytesIO()
    
    # Narrow Margin: 20pt all around -> Printable Width = 555.27 pt
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        leftMargin=20,
        rightMargin=20,
        topMargin=20,
        bottomMargin=20
    )
    
    styles = getSampleStyleSheet()
    
    company_right_normal = ParagraphStyle(
        'CompanyRightEqN_v3',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=7.5,
        leading=9.8,
        alignment=0
    )
    title_style = ParagraphStyle(
        'DocTitleEq_v3',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=18,
        leading=22,
        alignment=1
    )
    meta_label = ParagraphStyle('MetaLabelEq_v3', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=7.5, leading=9.5)
    meta_val = ParagraphStyle('MetaValEq_v3', parent=styles['Normal'], fontName='Helvetica', fontSize=7.5, leading=9.5)
    
    th_style = ParagraphStyle('THEq_v3', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=7.5, leading=9.5, alignment=1)
    td_c = ParagraphStyle('TDCEq_v3', parent=styles['Normal'], fontName='Helvetica', fontSize=7.5, leading=9.5, alignment=1)
    td_l = ParagraphStyle('TDLEq_v3', parent=styles['Normal'], fontName='Helvetica', fontSize=7.5, leading=9.5, alignment=0)
    td_r = ParagraphStyle('TDREq_v3', parent=styles['Normal'], fontName='Helvetica', fontSize=7.5, leading=9.5, alignment=2)
    
    tot_label = ParagraphStyle('TotLblEq_v3', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=7.5, leading=9.5, alignment=0)
    tot_curr = ParagraphStyle('TotCurEq_v3', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=7.5, leading=9.5, alignment=2)
    tot_val = ParagraphStyle('TotValEq_v3', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=7.5, leading=9.5, alignment=2)
    
    clause_title = ParagraphStyle('ClauseTitleEq_v3', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=7, leading=8.8)
    clause_body = ParagraphStyle('ClauseBodyEq_v3', parent=styles['Normal'], fontName='Helvetica', fontSize=6.8, leading=8.5)
    legal_body = ParagraphStyle('LegalBodyEq_v3', parent=styles['Normal'], fontName='Helvetica', fontSize=6.5, leading=8.2)

    story = []
    
    # 1. Header (Logo on Left, HLI Address on Right)
    logo_img = Image(LOGO_PATH, width=150, height=28) if os.path.exists(LOGO_PATH) else Paragraph("<b>LG Energy Solution</b>", title_style)
    hli_addr_text = (
        "<b>PT. HLI Green Power</b><br/>"
        "KNIC (Karawang New Industry City) Jl Trans Heksa<br/>"
        "Karawang Km. 7 Block C No. 1, Wanajaya, Telukjambe<br/>"
        "Barat Jawa Barat – 41361, Indonesia NPWP No :<br/>"
        "43.250.897.6-408.000<br/>"
        "Tel)<br/>Fax)"
    )
    t_top = Table([[logo_img, Paragraph(hli_addr_text, company_right_normal)]], colWidths=[340, 215])
    t_top.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('LEFTPADDING', (0,0), (-1,-1), 0),
        ('RIGHTPADDING', (0,0), (-1,-1), 0),
        ('TOPPADDING', (0,0), (-1,-1), 0),
        ('BOTTOMPADDING', (0,0), (-1,-1), 0),
    ]))
    story.append(t_top)
    story.append(Spacer(1, 8))
    
    # 2. Main Title: Purchase Order
    story.append(Paragraph("Purchase Order", title_style))
    story.append(Spacer(1, 10))
    
    # 3. Metadata Table (Col widths sum to 555 pt: [65, 295, 65, 130])
    po_no = str(oz_data.get('id') or oz_data.get('po_number') or '-')
    po_date = str(oz_data.get('po_date') or '-')
    buyer_name = str(oz_data.get('representative_name') or oz_data.get('buyer_name') or '-')
    vendor_name = str(oz_data.get('vendor_name') or 'PT. Apsindo Ganancia Perkasa')
    vendor_addr = f"{oz_data.get('address', 'Tangerang, Banten')}Jl. Kelapa Gading SelatanBH10/27Gading Serpong Tangerang 15810"
    
    meta_rows = [
        [
            Paragraph("Supplier :", meta_label),
            Paragraph(vendor_name, meta_val),
            Paragraph("PO No. :", meta_label),
            Paragraph(po_no, meta_val)
        ],
        [
            Paragraph(vendor_addr, meta_val),
            "", # spanned
            Paragraph("PO Date :", meta_label),
            Paragraph(po_date, meta_val)
        ],
        [
            "",
            "",
            Paragraph("Buyer :", meta_label),
            Paragraph(buyer_name, meta_val)
        ]
    ]
    t_meta = Table(meta_rows, colWidths=[65, 295, 65, 130])
    t_meta.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('LEFTPADDING', (0,0), (-1,-1), 0),
        ('RIGHTPADDING', (0,0), (-1,-1), 0),
        ('TOPPADDING', (0,0), (-1,-1), 1),
        ('BOTTOMPADDING', (0,0), (-1,-1), 1),
        ('SPAN', (0,1), (1,2)),
    ]))
    story.append(t_meta)
    story.append(Spacer(1, 8))
    
    # 4. Item Table (Col widths sum to 555 pt: [28, 175, 48, 55, 65, 114, 70])
    currency = oz_data.get("currency_code", "IDR")
    total_amt = float(oz_data.get("total_amount") or 0)
    items = oz_data.get("po_items", [])
    
    col_widths = [28, 175, 48, 55, 65, 114, 70]
    
    item_header = [
        Paragraph("No.", th_style),
        Paragraph("ItemCode/ItemName", th_style),
        Paragraph("Quantity", th_style),
        Paragraph("UoM", th_style),
        Paragraph("Unit Price", th_style),
        Paragraph("Amount", th_style),
        Paragraph("Delievery Date", th_style)
    ]
    
    table_rows = [item_header]
    if items:
        for it in items:
            code = it.get('item_code', '')
            name = it.get('item_name', '')
            item_desc = f"{code}, {name}" if code and code != '-' else name
            u_price = float(it.get('unit_price') or 0)
            amt = float(it.get('amount') or 0)
            qty = float(it.get('quantity') or 1)
            
            table_rows.append([
                Paragraph(str(it.get('item_line_no', 10)), td_c),
                Paragraph(item_desc, td_l),
                Paragraph(f"{qty:,.3f}", td_c),
                Paragraph(str(it.get('item_unit') or 'EA'), td_c),
                Paragraph(f"{u_price:,.2f}", td_r),
                Paragraph(f"{amt:,.2f}", td_r),
                Paragraph(str(it.get('delivery_due_date') or '-'), td_c)
            ])
    else:
        table_rows.append([
            Paragraph("10", td_c),
            Paragraph(str(oz_data.get('po_header_desc') or '-'), td_l),
            Paragraph("1.000", td_c),
            Paragraph("EA", td_c),
            Paragraph(f"{total_amt:,.2f}", td_r),
            Paragraph(f"{total_amt:,.2f}", td_r),
            Paragraph(po_date, td_c)
        ])
        
    # Total Amount row (spanning col 2 and 3 = 48 + 55 = 103 pt)
    table_rows.append([
        "", "",
        Paragraph("<b>Total Amount :</b>", tot_label),
        "",
        Paragraph(f"<b>{currency}</b>", tot_curr),
        Paragraph(f"<b>{total_amt:,.2f}</b>", tot_val),
        ""
    ])
    
    t_items = Table(table_rows, colWidths=col_widths)
    t_items.setStyle(TableStyle([
        ('BOX', (0,0), (-1,-2), 0.75, colors.black),
        ('INNERGRID', (0,0), (-1,-2), 0.5, colors.black),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('TOPPADDING', (0,0), (-1,-1), 2.5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 2.5),
        ('LEFTPADDING', (0,0), (-1,-1), 3),
        ('RIGHTPADDING', (0,0), (-1,-1), 3),
        ('SPAN', (2,-1), (3,-1)),
    ]))
    story.append(t_items)
    story.append(Spacer(1, 6))
    
    # 5. Table 5: Equipment Specific Clauses (1 to 5)
    delivery_term = oz_data.get('delivery_terms_name') or 'Delivered at place'
    place_of_delivery = oz_data.get('termsdelv_desc') or oz_data.get('delivery_terms_condition') or 'DAP'
    pay_term = oz_data.get('payment_terms_name') or 'T/T 60 Days from Document date'
    pay_cond_add = oz_data.get('payment_cond_add') or 'Intermediate payments(100%,T/T 60 Days from Document date)'
    delay_penalty = oz_data.get('delay_penalty') or '0.3% of the contract amount per delay day, within 25% of the maximum contract amount'
    contract_expiry = oz_data.get('contract_due_date') or ''
    perf_date = oz_data.get('at_complete_date') or ''
    final_date = oz_data.get('pf_complete_date') or ''
    
    clauses_data = [
        [Paragraph(" 1. Delivery term :", clause_title), Paragraph(delivery_term, clause_body)],
        [Paragraph(" 2. Place of delivery :", clause_title), Paragraph(place_of_delivery, clause_body)],
        [Paragraph(" 3. Payment term :", clause_title), Paragraph(f"{pay_term} {pay_cond_add}", clause_body)],
        [Paragraph(" 4. Liquidated Damage :", clause_title), Paragraph(delay_penalty, clause_body)],
        [Paragraph("", clause_title), Paragraph(f"1) Contract Expiry Date : {contract_expiry}", clause_body)],
        [Paragraph("", clause_title), Paragraph(f"2) Performance Acceptance Test Date : {perf_date}", clause_body)],
        [Paragraph("", clause_title), Paragraph(f"3) Final Acceptance Test Date : {final_date}", clause_body)],
        [Paragraph(" 5. Buyer's note :", clause_title), Paragraph("", clause_body)],
        [Paragraph("Additional Conditions :", clause_title), Paragraph(
            "Specifications, performance, inspection requirements and method of the product provided by Supplier to LGES "
            "shall be subject to the Specifications attached to the individual purchase contract executed between Supplier and LGES.",
            clause_body
        )],
    ]
    t_clauses = Table(clauses_data, colWidths=[130, 425])
    t_clauses.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('LEFTPADDING', (0,0), (-1,-1), 0),
        ('RIGHTPADDING', (0,0), (-1,-1), 0),
        ('TOPPADDING', (0,0), (-1,-1), 0.5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 0.5),
    ]))
    story.append(t_clauses)
    story.append(Spacer(1, 5))
    
    # 6. Table 6: Contract Clauses
    acc_text = (
        "<b>ACCEPTANCE OF THE PURCHASE ORDER.</b><br/>"
        "LGES may issue a purchase order to Supplier (“Purchase Order”), and the Purchase Order shall be deemed "
        "to be accepted by Supplier and Supplier shall be bound by the Purchase Order, unless Supplier rejects the Purchase Order in writing within three (3) "
        "business days from receipt of the Purchase Order from LGES. Unless otherwise agreed by LGES in writing, any additional terms and conditions in any "
        "offer, quotation, or proposal of Supplier, which are not specified in the Purchase Order, shall in no way constitute an acceptance of LGES and shall not "
        "be binding on LGES."
    )
    story.append(Paragraph(acc_text, legal_body))
    story.append(Spacer(1, 4))
    
    comp_text = (
        "<b>COMPLAINCE WITH OTHER CONTRACT TERMS.</b><br/>"
        "Terms and provisions not specified in this Purchase Order, shall follow all terms and provisions of the "
        "Master Equipment Purchase Agreement, Equipment Purchase Contract, and related supplemental agreements."
    )
    story.append(Paragraph(comp_text, legal_body))
    story.append(Spacer(1, 5))
    
    # 7. Delivery note
    story.append(Paragraph("Please deliver the product in accordance with the above mentioned contents and the due date.", legal_body))
    story.append(Spacer(1, 10))
    
    # 8. Signatures Block (Natural flow on Page 1 for standard 1-page PO)
    sig_data = [
        [
            Paragraph("<b>PT. Apsindo Ganancia Perkasa</b>", ParagraphStyle('SEq1_v3', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=8, alignment=1)),
            Paragraph("<b>PT. HLI Green Power</b>", ParagraphStyle('SEq2_v3', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=8, alignment=1))
        ],
        [
            Paragraph("<br/><br/>________________________________________", ParagraphStyle('SEq3_v3', parent=styles['Normal'], fontName='Helvetica', fontSize=8, alignment=1)),
            Paragraph("<br/><br/>________________________________________", ParagraphStyle('SEq4_v3', parent=styles['Normal'], fontName='Helvetica', fontSize=8, alignment=1))
        ]
    ]
    t_sig = Table(sig_data, colWidths=[277, 278])
    t_sig.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('ALIGN', (0,0), (-1,-1), 'CENTER'),
        ('TOPPADDING', (0,0), (-1,-1), 0),
        ('BOTTOMPADDING', (0,0), (-1,-1), 0),
    ]))
    story.append(t_sig)
    
    doc.build(story)
    buffer.seek(0)
    return buffer.getvalue()


# =========================================================================
# 3. UNIFIED DISPATCHER (Type Detection & PDF Generation)
# =========================================================================
def generate_official_lg_po_pdf(oz_data: dict) -> bytes:
    """
    Automatically detects whether the PO is Equipment or MRO based on:
    - ozr_report_file (/core/op/poSheetCD_EN vs /core/op/op_pu_poSheetIn_US)
    - po_item_type_code ('C' for Equipment vs 'E' for MRO)
    - po_item_type / purchase_type / header description
    """
    ozr_file = str(oz_data.get('ozr_report_file') or '')
    item_type_code = str(oz_data.get('po_item_type_code') or '').upper()
    item_type = str(oz_data.get('po_item_type') or oz_data.get('purchase_type') or '').lower()
    desc = str(oz_data.get('po_header_desc') or '').lower()
    
    is_equipment = (
        'posheetcd' in ozr_file.lower() or
        item_type_code in ['C', 'EQ', 'F'] or
        'equipment' in item_type or
        'equipment' in desc or
        bool(oz_data.get('delay_penalty'))
    )
    
    if is_equipment:
        return draw_equipment_lg_po_pdf(oz_data)
    else:
        return draw_mro_lg_po_pdf(oz_data)
