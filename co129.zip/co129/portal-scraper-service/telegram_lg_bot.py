"""
Telegram Bot dedicated for LG SINGLEX (HLI Green Power) Portal
Supplier: PT. Apsindo Ganancia Perkasa (ID00589800)
Tenant: L2101 / LGES

Features:
- Native Bot Commands & Persistent Keyboard
- 📦 PO Masuk LG SINGLEX (Pagination, Item Detail, Status, Receipt Alert)
- 📢 Tender LG SINGLEX (Active Open vs All History, Buyer Attachments, Pre-requisite agreement)
- 🔍 Pencarian Universal (No. PO SAP, No. Dokumen PO, No. RFQ)
- ✅ Acknowledge Receipt PO langsung ke portal
- ✅ 'I Agree' Prasyarat Tender langsung ke portal
- 📄 Cetak Dokumen Resmi PDF via Playwright Native Browser Print (100% pixel-perfect)
"""

import os
import re
import time
import logging
import threading
import requests
import io
from typing import Dict, Any, Optional, List
from scrapers.lg_singlex_portal import lg_client
from scrapers.playwright_po_downloader import download_official_po_pdf_playwright

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger("telegram_lg_bot")

TELEGRAM_LG_BOT_TOKEN = os.getenv("TELEGRAM_LG_BOT_TOKEN", "9277394368:AAFjG7Tz7Y1wVbtTgh6H9OSNC53W0m0zpFg")

# User in-memory session
user_sessions: Dict[int, Dict[str, Any]] = {}

MAIN_MENU_KEYBOARD = {
    "keyboard": [
        [{"text": "📦 PO Masuk LG SINGLEX"}, {"text": "📢 Tender LG SINGLEX"}],
        [{"text": "🔍 Cari PO / RFQ Singlex"}],
        [{"text": "🔄 Sinkronkan Cookie"}, {"text": "📊 Status Koneksi Portal"}],
        [{"text": "💡 Panduan Singlex"}]
    ],
    "resize_keyboard": True,
    "is_persistent": True
}

def send_message(chat_id: int, text: str, reply_markup: Optional[Dict] = None):
    url = f"https://api.telegram.org/bot{TELEGRAM_LG_BOT_TOKEN}/sendMessage"
    payload = {
        "chat_id": chat_id,
        "text": text,
        "parse_mode": "Markdown",
        "disable_web_page_preview": True
    }
    if reply_markup:
        payload["reply_markup"] = reply_markup
    try:
        resp = requests.post(url, json=payload, timeout=12)
        return resp.json()
    except Exception as e:
        logger.error(f"Gagal mengirim Telegram message: {e}")
        return None

def edit_message_text(chat_id: int, message_id: int, text: str, reply_markup: Optional[Dict] = None):
    url = f"https://api.telegram.org/bot{TELEGRAM_LG_BOT_TOKEN}/editMessageText"
    payload = {
        "chat_id": chat_id,
        "message_id": message_id,
        "text": text,
        "parse_mode": "Markdown",
        "disable_web_page_preview": True
    }
    if reply_markup:
        payload["reply_markup"] = reply_markup
    try:
        resp = requests.post(url, json=payload, timeout=12).json()
        if not resp.get("ok"):
            return send_message(chat_id, text, reply_markup)
        return resp
    except Exception as e:
        logger.error(f"Gagal mengedit Telegram message {message_id}: {e}")
        return send_message(chat_id, text, reply_markup)

def send_document(chat_id: int, file_bytes: bytes, filename: str, caption: str = ""):
    url = f"https://api.telegram.org/bot{TELEGRAM_LG_BOT_TOKEN}/sendDocument"
    files = {"document": (filename, file_bytes, "application/pdf")}
    data = {
        "chat_id": chat_id,
        "caption": caption[:1024],
        "parse_mode": "Markdown"
    }
    try:
        resp = requests.post(url, data=data, files=files, timeout=40)
        return resp.json()
    except Exception as e:
        logger.error(f"Gagal mengirim dokumen Telegram: {e}")
        return None

def answer_callback(callback_query_id: str, text: str = ""):
    url = f"https://api.telegram.org/bot{TELEGRAM_LG_BOT_TOKEN}/answerCallbackQuery"
    try:
        requests.post(url, json={"callback_query_id": callback_query_id, "text": text}, timeout=6)
    except Exception:
        pass

def register_bot_commands():
    url = f"https://api.telegram.org/bot{TELEGRAM_LG_BOT_TOKEN}/setMyCommands"
    commands = [
        {"command": "start", "description": "Mulai bot & Tampilkan Menu Utama"},
        {"command": "lgpo", "description": "Daftar Purchase Order (PO) Terbaru"},
        {"command": "lgrfq", "description": "Daftar Tender RFQ Terbuka (Open)"},
        {"command": "lgrfq_all", "description": "Riwayat Seluruh Tender RFQ (All)"},
        {"command": "cari", "description": "Pencarian Dokumen PO SAP / Singlex / RFQ"},
        {"command": "status", "description": "Cek Status Koneksi Portal Singlex"},
        {"command": "help", "description": "Panduan Penggunaan Bot LG SINGLEX"}
    ]
    try:
        requests.post(url, json={"commands": commands}, timeout=8)
        logger.info("Perintah /setMyCommands berhasil didaftarkan untuk LG Singlex Bot.")
    except Exception as e:
        logger.warning(f"Gagal register bot commands: {e}")

def trigger_cookie_sync(chat_id: int):
    send_message(chat_id, "🔄 *Menghubungi bridge komputer Windows untuk mengambil cookie browser...*")
    try:
        resp = requests.get("http://host.docker.internal:5005/sync-cookies", timeout=35)
        data = resp.json()
        if data.get("ok"):
            lg_client._load_session_from_db()
            ok = lg_client.check_session()
            status_badge = "🟢 AKTIF & SIAP" if ok else "🟡 PERLU RE-VERIFIKASI"
            msg = (
                f"🎉 *BERHASIL MENYINKRONKAN COOKIE!*\n\n"
                f"• *Browser Sumber* : `{data.get('browser')}`\n"
                f"• *Jumlah Cookie*  : `{data.get('count')} item`\n"
                f"• *Status Sesi*    : {status_badge}\n\n"
                f"Sesi portal LG SINGLEX kini telah diperbarui dan siap digunakan."
            )
            send_message(chat_id, msg)
        elif data.get("locked"):
            msg = (
                f"⚠️ *BROWSER SEDANG DIKUNCI OLEH WINDOWS*\n\n"
                f"Browser *{data.get('browser')}* sedang aktif membuka file cookie.\n\n"
                f"👉 *Cara Cepat:*\n"
                f"1. Tutup aplikasi browser Anda sebentar (sekitar 2 detik),\n"
                f"2. Lalu klik tombol *`🔄 Sinkronkan Cookie`* kembali.\n\n"
                f"_Atau Anda bisa ketik `/update_cookie <cookie_string>` langsung di chat ini._"
            )
            send_message(chat_id, msg)
        else:
            send_message(chat_id, f"❌ *Gagal Sinkronisasi Cookie:*\n{data.get('message', 'Tidak ditemukan cookie Singlex.')}\n\nPastikan Anda sudah login ke portal LG di browser.")
    except Exception as err:
        send_message(
            chat_id,
            f"❌ *Tidak dapat menjangkau host bridge Windows:*\n`{err}`\n\n"
            f"Pastikan `host_bridge_service.py` berjalan di komputer Windows Anda,\n"
            f"atau gunakan perintah: `/update_cookie <cookie_string>` untuk input manual."
        )

def check_portal_status(chat_id: int):
    send_message(chat_id, "🔍 *Memeriksa status sesi & koneksi ke Portal LG SINGLEX...*")
    try:
        ok = lg_client.check_session()
        rfq_count = len(lg_client.get_rfq_list(top=5, status_filter="all")) if ok else 0
        po_count = len(lg_client.get_po_list(top=5)) if ok else 0
        
        status_icon = "🟢 AKTIF & SIAP" if ok else "🔴 PERLU REFRESH COOKIE"
        msg = (
            f"📊 *STATUS KONEKSI PORTAL LG SINGLEX*\n\n"
            f"• *Tenant*        : `L2101 (LGES / HLI Green Power)`\n"
            f"• *Vendor ID*     : `ID00589800`\n"
            f"• *Vendor Name*   : `PT. Apsindo Ganancia Perkasa`\n"
            f"• *Status Sesi*   : {status_icon}\n"
            f"• *Akses RFQ*     : {'✅ Terhubung (' + str(rfq_count) + ' riwayat)' if ok else '❌ Gagal'}\n"
            f"• *Akses PO*      : {'✅ Terhubung (' + str(po_count) + ' terdaftar)' if ok else '❌ Gagal'}\n"
            f"• *Cetak Dokumen* : ✅ Playwright Native Engine Ready\n\n"
            f"_Klik tombol di bawah untuk menyinkronkan cookie langsung dari browser Windows Anda:_"
        )
        inline_btn = {"inline_keyboard": [[{"text": "🔄 Sinkronkan Cookie Sekarang", "callback_data": "lg_sync_cookie"}]]}
        send_message(chat_id, msg, reply_markup=inline_btn)
    except Exception as e:
        send_message(chat_id, f"❌ Terjadi kesalahan saat memeriksa portal: `{e}`")

def send_po_page(chat_id: int, page_num: int = 1, message_id: Optional[int] = None):
    page_size = 5
    skip = (page_num - 1) * page_size
    pos = lg_client.get_po_list(top=page_size + 1, skip=skip)
    
    if not pos and page_num > 1:
        return send_po_page(chat_id, page_num=1, message_id=message_id)

    if not pos:
        msg_text = "⚠️ Tidak dapat memuat daftar PO LG SINGLEX atau daftar kosong."
        if message_id:
            return edit_message_text(chat_id, message_id, msg_text)
        return send_message(chat_id, msg_text)

    has_next = len(pos) > page_size
    current_items = pos[:page_size]

    lines = [f"📦 *DAFTAR PURCHASE ORDER (PO) LG SINGLEX (Hal {page_num}):*\n"]
    inline_buttons = []

    for idx, it in enumerate(current_items, (page_num - 1) * page_size + 1):
        raw_amt = it.get('total_amount', 0)
        try:
            formatted_amt = f"{float(raw_amt):,.0f}"
        except Exception:
            formatted_amt = str(raw_amt)
        amt = f"{it.get('currency', 'IDR')} {formatted_amt}"
        po_num = it.get('po_number') or it.get('po_document_number')
        doc_no = it.get('po_document_number') or '-'
        is_receipted = it.get('supplier_receipt_flag', False)
        receipt_status = "✅ SUDAH RECEIPT (Diterima)" if is_receipted else "⏳ *BELUM DITERIMA (Perlu Receipt)*"
        item_desc = (it.get('po_descs') or it.get('po_header_desc') or '-').replace('[', '(').replace(']', ')')
        po_type = it.get('po_item_type_name') or ('Equipment' if it.get('po_item_type_code') == 'C' else 'MRO')
        po_date = str(it.get('po_date') or '-').split(' ')[0]

        lines.append(
            f"*{idx}. No. PO SAP:* `{po_num}`\n"
            f"   📄 *No. Dokumen:* `{doc_no}`\n"
            f"   📦 *Tipe PO:* `{po_type}`\n"
            f"   🏷 *Item:* {item_desc}\n"
            f"   👤 *Buyer:* {it.get('buyer_name')} ({it.get('buyer_department', 'MRO')})\n"
            f"   💵 *Nilai:* {amt}\n"
            f"   📅 *Tanggal:* `{po_date}`\n"
            f"   📊 *Status:* `{it.get('po_status') or '-'}`\n"
            f"   📌 *Receipt:* {receipt_status}\n"
        )
        row_btn = []
        if not is_receipted and po_num:
            row_btn.append({"text": f"✅ Receipt {po_num}", "callback_data": f"lg_receipt_{po_num}"})
        btn_target = doc_no if doc_no and doc_no != '-' else po_num
        row_btn.append({"text": f"📄 Cetak {po_num}", "callback_data": f"lg_print_{btn_target}"})
        inline_buttons.append(row_btn)

    # Navigasi halaman
    nav_row = []
    if page_num > 1:
        nav_row.append({"text": "⬅️ Sebelumnya", "callback_data": f"lg_popage_{page_num - 1}"})
    nav_row.append({"text": f"📄 Hal {page_num}", "callback_data": "noop"})
    if has_next:
        nav_row.append({"text": "Selanjutnya ➡️", "callback_data": f"lg_popage_{page_num + 1}"})
    inline_buttons.append(nav_row)

    reply_markup = {"inline_keyboard": inline_buttons}
    full_text = "\n".join(lines)
    if message_id:
        return edit_message_text(chat_id, message_id, full_text, reply_markup=reply_markup)
    else:
        return send_message(chat_id, full_text, reply_markup=reply_markup)

def send_rfq_page(chat_id: int, page_num: int = 1, filter_mode: str = "open", message_id: Optional[int] = None):
    page_size = 5
    skip = (page_num - 1) * page_size
    rfqs = lg_client.get_rfq_list(top=page_size + 1, skip=skip, status_filter=filter_mode)
    
    if not rfqs and page_num > 1:
        return send_rfq_page(chat_id, page_num=1, filter_mode=filter_mode, message_id=message_id)

    if not rfqs:
        msg_text = (
            f"⚠️ Tidak ada tender RFQ dengan Sourcing Status *{filter_mode.upper()}* saat ini.\n"
            "Ketik `/lgrfq_all` jika ingin melihat riwayat tender sebelumnya."
        )
        if message_id:
            return edit_message_text(chat_id, message_id, msg_text)
        return send_message(chat_id, msg_text)

    has_next = len(rfqs) > page_size
    current_items = rfqs[:page_size]

    lines = [f"📢 *DAFTAR TENDER LG SINGLEX (STATUS: {filter_mode.upper()}, Hal {page_num}):*\n"]
    inline_buttons = []
    
    for idx, it in enumerate(current_items, (page_num - 1) * page_size + 1):
        doc_no = it.get('nego_document_number') or '-'
        nego_id = it.get('nego_header_id')
        files = it.get('buyer_attachments', [])
        is_agreed = it.get('is_agreed', False)
        
        file_info = f"📎 *Lampiran Buyer:* `{len(files)} file`" if files else "📎 *Lampiran Buyer:* Tidak ada file"
        agree_badge = "✅ Sudah Disetujui ('I Agree')" if is_agreed else "⚠️ *Belum Disetujui ('I Agree')*"
        
        lines.append(
            f"*{idx}. No. RFQ:* `{doc_no}`\n"
            f"   📌 *Judul:* {it.get('title')}\n"
            f"   👤 *Buyer:* {it.get('buyer_name')}\n"
            f"   📊 *Sourcing Status:* `{it.get('sourcing_status')}`\n"
            f"   ⏰ *Batas Waktu:* `{it.get('actual_closing_date_time') or '-'}`\n"
            f"   {file_info}\n"
            f"   📋 *Prasyarat:* {agree_badge}\n"
        )
        row_buttons = []
        if not is_agreed and nego_id:
            row_buttons.append({"text": f"✅ 'I Agree' {doc_no}", "callback_data": f"lg_agree_{nego_id}"})
        if row_buttons:
            inline_buttons.append(row_buttons)

    # Navigasi halaman
    nav_row = []
    if page_num > 1:
        nav_row.append({"text": "⬅️ Sebelumnya", "callback_data": f"lg_rfqpage_{page_num - 1}_{filter_mode}"})
    nav_row.append({"text": f"📋 Hal {page_num}", "callback_data": "noop"})
    if has_next:
        nav_row.append({"text": "Selanjutnya ➡️", "callback_data": f"lg_rfqpage_{page_num + 1}_{filter_mode}"})
    inline_buttons.append(nav_row)

    reply_markup = {"inline_keyboard": inline_buttons}
    full_text = "\n".join(lines)
    if message_id:
        return edit_message_text(chat_id, message_id, full_text, reply_markup=reply_markup)
    else:
        return send_message(chat_id, full_text, reply_markup=reply_markup)

def handle_singlex_search(chat_id: int, query: str):
    q = query.strip()
    if not q:
        send_message(chat_id, "⚠️ Masukkan nomor PO atau nomor RFQ yang ingin dicari.")
        return

    send_message(chat_id, f"🔍 *Mencari data PO / RFQ `{q}` di portal LG SINGLEX...*")
    try:
        found_pos = lg_client.search_po(q)
        found_rfqs = lg_client.search_rfq(q)

        if not found_pos and not found_rfqs:
            send_message(
                chat_id,
                f"❌ Data dengan kata kunci `{q}` tidak ditemukan di portal LG SINGLEX.\n\n"
                f"Tips: Masukkan format Nomor PO SAP (cth: `4570369788`), Nomor Dokumen (cth: `PO0000598080`), atau Nomor RFQ (cth: `169124-1`)."
            )
            return

        # Tampilkan PO jika ditemukan
        if found_pos:
            lines = [f"📦 *HASIL PENCARIAN PURCHASE ORDER (PO) ({len(found_pos)} ditemukan):*\n"]
            inline_buttons = []
            for idx, it in enumerate(found_pos[:5], 1):
                raw_amt = it.get('total_amount', 0)
                try:
                    formatted_amt = f"{float(raw_amt):,.0f}"
                except Exception:
                    formatted_amt = str(raw_amt)
                amt = f"{it.get('currency', 'IDR')} {formatted_amt}"
                po_num = it.get('po_number') or it.get('po_document_number')
                doc_no = it.get('po_document_number') or '-'
                is_receipted = it.get('supplier_receipt_flag', False)
                receipt_status = "✅ SUDAH RECEIPT (Diterima)" if is_receipted else "⏳ *BELUM DITERIMA (Perlu Receipt)*"
                item_desc = (it.get('po_descs') or it.get('po_header_desc') or '-').replace('[', '(').replace(']', ')')
                po_type = it.get('po_item_type_name') or ('Equipment' if it.get('po_item_type_code') == 'C' else 'MRO')

                lines.append(
                    f"*{idx}. No. PO SAP:* `{po_num}`\n"
                    f"   📄 *No. Dokumen:* `{doc_no}`\n"
                    f"   📦 *Tipe PO:* `{po_type}`\n"
                    f"   🏷 *Item:* {item_desc}\n"
                    f"   👤 *Buyer:* {it.get('buyer_name')} ({it.get('buyer_department', 'MRO')})\n"
                    f"   💵 *Nilai:* {amt}\n"
                    f"   📅 *Tanggal:* `{it.get('po_date')}`\n"
                    f"   📊 *Status:* `{it.get('po_status') or '-'}`\n"
                    f"   📌 *Receipt:* {receipt_status}\n"
                )
                row_btn = []
                if not is_receipted and po_num:
                    row_btn.append({"text": f"✅ Receipt {po_num}", "callback_data": f"lg_receipt_{po_num}"})
                btn_target = doc_no if doc_no and doc_no != '-' else po_num
                row_btn.append({"text": f"📄 Cetak {po_num}", "callback_data": f"lg_print_{btn_target}"})
                inline_buttons.append(row_btn)

            send_message(chat_id, "\n".join(lines), reply_markup={"inline_keyboard": inline_buttons} if inline_buttons else None)

        # Tampilkan RFQ jika ditemukan
        if found_rfqs:
            lines = [f"📢 *HASIL PENCARIAN TENDER / RFQ ({len(found_rfqs)} ditemukan):*\n"]
            inline_buttons = []
            for idx, it in enumerate(found_rfqs[:5], 1):
                doc_no = it.get('nego_document_number') or '-'
                nego_id = it.get('nego_header_id')
                is_agreed = it.get('is_agreed', False)
                agree_badge = "✅ Sudah Disetujui" if is_agreed else "⚠️ *Belum Disetujui*"

                lines.append(
                    f"*{idx}. No. RFQ:* `{doc_no}`\n"
                    f"   📌 *Judul:* {it.get('title')}\n"
                    f"   👤 *Buyer:* {it.get('buyer_name')}\n"
                    f"   📊 *Status:* `{it.get('sourcing_status')}`\n"
                    f"   ⏰ *Closing:* `{it.get('actual_closing_date_time') or '-'}`\n"
                    f"   📋 *Prasyarat:* {agree_badge}\n"
                )
                row_btn = []
                if not is_agreed and nego_id:
                    row_btn.append({"text": f"✅ 'I Agree' {doc_no}", "callback_data": f"lg_agree_{nego_id}"})
                if row_btn:
                    inline_buttons.append(row_btn)

            send_message(chat_id, "\n".join(lines), reply_markup={"inline_keyboard": inline_buttons} if inline_buttons else None)

    except Exception as e:
        send_message(chat_id, f"❌ Terjadi kesalahan saat mencari: `{e}`")

def handle_telegram_updates():
    register_bot_commands()
    logger.info("Memulai LG Singlex Dedicated Bot Polling Listener...")
    offset = 0

    while True:
        try:
            url = f"https://api.telegram.org/bot{TELEGRAM_LG_BOT_TOKEN}/getUpdates?offset={offset}&timeout=15"
            resp = requests.get(url, timeout=25).json()

            if not resp.get("ok"):
                time.sleep(3)
                continue

            for update in resp.get("result", []):
                offset = update["update_id"] + 1

                # 1. Handle Callback Query (Klik Tombol Inline)
                if "callback_query" in update:
                    cb = update["callback_query"]
                    cb_id = cb["id"]
                    data = cb["data"]
                    chat_id = cb["message"]["chat"]["id"]

                    if data.startswith("lg_agree_"):
                        nego_id = int(data.replace("lg_agree_", ""))
                        answer_callback(cb_id, "Memproses I Agree...")
                        send_message(chat_id, f"⏳ *Mengonfirmasi persetujuan syarat tender ('I Agree') untuk ID `{nego_id}` ke portal LG...*")
                        try:
                            ok = lg_client.agree_prerequisites(nego_id)
                            if ok:
                                send_message(chat_id, f"✅ *BERHASIL:* Prasyarat tender `{nego_id}` telah disetujui (*'I Agree'*) di portal LG SINGLEX!\nBagian Header & Line harga kini sudah terbuka.")
                            else:
                                send_message(chat_id, f"❌ Gagal menyetujui prasyarat tender `{nego_id}`. Periksa sesi login.")
                        except Exception as ex:
                            send_message(chat_id, f"❌ Error: `{ex}`")
                        continue

                    elif data.startswith("lg_receipt_"):
                        po_num = data.replace("lg_receipt_", "")
                        answer_callback(cb_id, "Memproses Receipt PO...")
                        send_message(chat_id, f"⏳ *Mengonfirmasi penerimaan resmi (Receipt) untuk PO `{po_num}` ke portal LG...*")
                        try:
                            ok = lg_client.acknowledge_receipt(po_num)
                            if ok:
                                send_message(chat_id, f"🎉 *BERHASIL RECEIPT PO:* PO `{po_num}` resmi diterima & disetujui di portal LG SINGLEX!\nStatus PO kini telah berubah menjadi *Confirmed/Receipted*.")
                            else:
                                send_message(chat_id, f"❌ Gagal memproses Receipt untuk PO `{po_num}`. Periksa koneksi atau status PO di portal.")
                        except Exception as ex:
                            send_message(chat_id, f"❌ Error saat memproses Receipt: `{ex}`")
                        continue

                    elif data.startswith("lg_print_"):
                        target_id = data.replace("lg_print_", "").strip()
                        answer_callback(cb_id, "Mencetak Dokumen Asli...")
                        send_message(chat_id, f"⏳ *Sedang mengambil cetakan PDF native browser untuk PO `{target_id}` langsung dari portal Singlex...*")
                        try:
                            oz_data = None
                            doc_no = None
                            po_num = target_id
                            target_po = None

                            if target_id.upper().startswith("PO"):
                                doc_no = target_id.upper()
                                oz_data = lg_client.get_official_po_sheet_data(doc_no, company_code="LGESHM")
                                if oz_data:
                                    po_num = str(oz_data.get("id") or po_num)

                            if not oz_data:
                                pos = lg_client.get_po_list(top=100)
                                for p in pos:
                                    if p.get("po_number") == target_id or p.get("po_document_number") == target_id:
                                        target_po = p
                                        doc_no = p.get("po_document_number")
                                        po_num = p.get("po_number")
                                        break
                                if doc_no:
                                    oz_data = lg_client.get_official_po_sheet_data(doc_no, company_code="LGESHM")

                            if not oz_data and target_po:
                                oz_data = {
                                    "id": po_num,
                                    "doc_no": doc_no,
                                    "super_organization_name": "PT. HLI Green Power",
                                    "representative_name": target_po.get("buyer_name", "-"),
                                    "department_name": target_po.get("buyer_department", "-"),
                                    "currency_code": target_po.get("currency", "IDR"),
                                    "total_amount": target_po.get("total_amount", 0),
                                    "po_item_type": target_po.get("po_item_type_name", "MRO")
                                }

                            pdf_bytes = None
                            if doc_no and doc_no.upper().startswith("PO"):
                                try:
                                    logger.info(f"Triggering Playwright Native Browser Print for {doc_no}...")
                                    pdf_bytes = download_official_po_pdf_playwright(doc_no, company_code="LGESHM")
                                except Exception as err:
                                    logger.error(f"Playwright PDF download failed: {err}")

                            if not pdf_bytes:
                                send_message(chat_id, f"❌ Dokumen PO `{target_id}` tidak dapat dirender dari portal Singlex. Pastikan nomor PO benar.")
                                continue

                            pdf_filename = f"Official_PO_{po_num}_{doc_no}.pdf"
                            po_type_disp = (oz_data.get('po_item_type') or 'MRO') if oz_data else 'MRO'
                            caption = (
                                f"📄 *DOKUMEN RESMI PURCHASE ORDER (PO) SINGLEX*\n\n"
                                f"• *No. PO SAP*  : `{po_num}`\n"
                                f"• *No. Dokumen* : `{doc_no}`\n"
                                f"• *Tipe PO*     : `{po_type_disp}`\n"
                                f"• *Penerbit*    : `{oz_data.get('super_organization_name', 'PT. HLI Green Power') if oz_data else 'PT. HLI Green Power'}`\n"
                                f"• *Buyer*       : {oz_data.get('representative_name', (target_po or {}).get('buyer_name')) if oz_data else '-'}\n"
                                f"• *Total Nilai* : `{oz_data.get('currency_code', 'IDR') if oz_data else 'IDR'} {float(oz_data.get('total_amount', 0) if oz_data else 0):,.0f}`\n\n"
                                f"_Dokumen cetak PDF native browser A4 (Narrow margin) siap digunakan._"
                            )
                            send_document(chat_id, pdf_bytes, pdf_filename, caption=caption)
                        except Exception as ex:
                            logger.error(f"Error generating PDF for {target_id}: {ex}")
                            send_message(chat_id, f"❌ Gagal membuat PDF PO: `{ex}`")
                        continue

                    elif data.startswith("lg_popage_"):
                        target_page = int(data.replace("lg_popage_", "").strip())
                        answer_callback(cb_id, f"Membuka Halaman {target_page}...")
                        send_po_page(chat_id, page_num=target_page, message_id=cb.get("message", {}).get("message_id"))
                        continue

                    elif data.startswith("lg_rfqpage_"):
                        parts = data.replace("lg_rfqpage_", "").split("_")
                        target_page = int(parts[0])
                        target_filter = parts[1] if len(parts) > 1 else "open"
                        answer_callback(cb_id, f"Membuka Halaman {target_page}...")
                        send_rfq_page(chat_id, page_num=target_page, filter_mode=target_filter, message_id=cb.get("message", {}).get("message_id"))
                        continue

                    elif data == "lg_sync_cookie":
                        answer_callback(cb_id, "Menyinkronkan cookie...")
                        trigger_cookie_sync(chat_id)
                        continue

                    elif data == "noop":
                        answer_callback(cb_id)
                        continue

                # 2. Handle Text Message
                if "message" in update:
                    msg = update["message"]
                    chat_id = msg["chat"]["id"]
                    text = msg.get("text", "").strip()

                    if not text:
                        continue

                    if text in ["/start", "/menu"]:
                        welcome_card = (
                            "👋 *SELAMAT DATANG DI BOT PORTAL LG SINGLEX*\n"
                            "🏢 *PT. Apsindo Ganancia Perkasa* (Vendor ID: `ID00589800`)\n"
                            "Client: *PT. HLI Green Power / LG Energy Solution*\n\n"
                            "Gunakan tombol di bawah untuk navigasi cepat:\n"
                            "• *📦 PO Masuk LG SINGLEX* : Lihat daftar PO, konfirmasi receipt, & cetak PDF asli\n"
                            "• *📢 Tender LG SINGLEX* : Pantau RFQ tender & persetujuan 'I Agree'\n"
                            "• *🔍 Cari PO / RFQ* : Cari nomor PO SAP / Dokumen / RFQ\n"
                            "• *📊 Status Koneksi Portal* : Cek ketersediaan sesi portal Singlex\n\n"
                            "_Ketik `/help` untuk panduan lengkap._"
                        )
                        send_message(chat_id, welcome_card, reply_markup=MAIN_MENU_KEYBOARD)
                        continue

                    if text in ["/help", "💡 Panduan Singlex"]:
                        guide = (
                            "💡 *PANDUAN PENGGUNAAN BOT LG SINGLEX*\n\n"
                            "1. *Melihat & Menyetujui Tender (RFQ):*\n"
                            "   • Klik menu `📢 Tender LG SINGLEX` atau ketik `/lgrfq`.\n"
                            "   • Klik tombol `✅ 'I Agree'` untuk menyetujui prasyarat tender agar penawaran terbuka.\n"
                            "   • Untuk melihat riwayat semua tender, ketik `/lgrfq_all`.\n\n"
                            "2. *Mengecek PO & Konfirmasi Receipt:*\n"
                            "   • Klik menu `📦 PO Masuk LG SINGLEX` atau ketik `/lgpo`.\n"
                            "   • Jika PO baru masuk, klik tombol `✅ Receipt <No PO>` untuk konfirmasi penerimaan resmi ke portal LG.\n\n"
                            "3. *Mencetak Dokumen Resmi PO:*\n"
                            "   • Klik tombol `📄 Cetak <No PO>` pada rincian PO.\n"
                            "   • Bot akan otomatis menjalankan engine Playwright untuk mengambil cetakan PDF native browser A4 presisi.\n\n"
                            "4. *Pencarian Cepat:*\n"
                            "   • Anda bisa langsung ketikkan nomor PO SAP (cth: `4570354380`) atau No. Dokumen (cth: `PO0000595150`) langsung di chat ini."
                        )
                        send_message(chat_id, guide)
                        continue

                    if text in ["/status", "📊 Status Koneksi Portal"]:
                        check_portal_status(chat_id)
                        continue

                    if text in ["/sync", "/refresh_cookie", "🔄 Sinkronkan Cookie"]:
                        trigger_cookie_sync(chat_id)
                        continue

                    if text.startswith("/update_cookie ") or text.startswith("/setcookie "):
                        raw_val = text.split(" ", 1)[1].strip()
                        cookies_dict = {}
                        for part in raw_val.split(";"):
                            if "=" in part:
                                k, v = part.strip().split("=", 1)
                                cookies_dict[k.strip()] = v.strip()
                        if cookies_dict:
                            lg_client.save_session(cookies_dict)
                            ok = lg_client.check_session()
                            status_badge = "🟢 AKTIF & SIAP" if ok else "🔴 Cookie belum valid"
                            send_message(
                                chat_id,
                                f"✅ *COOKIE BERHASIL DIUPDATE MANUAL!*\n\n"
                                f"• *Jumlah Cookie* : `{len(cookies_dict)} item`\n"
                                f"• *Status Sesi*   : {status_badge}\n"
                            )
                        else:
                            send_message(chat_id, "⚠️ Format cookie tidak dikenali. Format: `key1=val1; key2=val2`")
                        continue

                    if text in ["/cari", "/search", "🔍 Cari PO / RFQ Singlex"]:
                        user_sessions[chat_id] = {"state": "AWAITING_SINGLEX_SEARCH"}
                        send_message(
                            chat_id,
                            "🔍 *PENCARIAN DOKUMEN LG SINGLEX*\n\n"
                            "Silakan ketikkan *Nomor PO SAP* (cth: `4570354380`), *Nomor Dokumen PO* (cth: `PO0000595150`), atau *Nomor RFQ* (cth: `169124-1`):\n\n"
                            "_Atau Anda bisa langsung ketik: `/cari <nomor>` kapan saja._"
                        )
                        continue

                    if text.startswith("/cari ") or text.startswith("/search "):
                        query = text.split(" ", 1)[1].strip()
                        handle_singlex_search(chat_id, query)
                        continue

                    if text in ["/lgrfq", "📢 Tender LG SINGLEX", "/lgrfq_all"]:
                        is_all = "/lgrfq_all" in text
                        filter_mode = "all" if is_all else "open"
                        send_rfq_page(chat_id, page_num=1, filter_mode=filter_mode)
                        continue

                    if text in ["/lgpo", "📦 PO Masuk LG SINGLEX"]:
                        send_po_page(chat_id, page_num=1)
                        continue

                    session = user_sessions.get(chat_id)
                    if session and session.get("state") == "AWAITING_SINGLEX_SEARCH":
                        user_sessions.pop(chat_id, None)
                        handle_singlex_search(chat_id, text)
                        continue

                    # Auto-detection PO SAP / Singlex PO / Singlex RFQ
                    if re.match(r'^(45\d{8}|PO\d{10}|\d{5,7}-\d+)$', text.strip()):
                        handle_singlex_search(chat_id, text.strip())
                        continue

                    send_message(
                        chat_id,
                        f"🤖 Perintah `{text}` tidak dikenali.\n"
                        "Gunakan tombol menu di bawah atau ketik `/help` untuk panduan.",
                        reply_markup=MAIN_MENU_KEYBOARD
                    )

        except Exception as e:
            logger.error(f"Error in LG Telegram polling loop: {e}")
            time.sleep(3)

def start_lg_bot_background():
    t = threading.Thread(target=handle_telegram_updates, daemon=True)
    t.start()
    logger.info("Background thread LG Singlex Dedicated Bot berhasil dijalankan.")

if __name__ == "__main__":
    handle_telegram_updates()
