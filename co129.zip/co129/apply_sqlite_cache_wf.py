import json

file_path = "n8n_workflow_honda_rfq_lifecycle.json"
with open(file_path, "r", encoding="utf-8") as f:
    wf = json.load(f)

for node in wf["nodes"]:
    if node["id"] == "node-4-auto-login-honda":
        node["name"] = "4. Ambil Token Sesi dari SQLite Cache"
        node["parameters"] = {
            "url": "http://scraper-worker:8000/api/auth/token",
            "method": "GET",
            "options": {}
        }
        print("Node 4 changed to SQLite token cache consumer!")
    elif node["id"] == "node-5-search-rfq":
        node["parameters"]["headerParameters"]["parameters"][0]["value"] = "={{ 'Bearer ' + $('4. Ambil Token Sesi dari SQLite Cache').first().json.token }}"
    elif node["id"] == "node-6-get-rfq-items":
        node["parameters"]["headerParameters"]["parameters"][0]["value"] = "={{ 'Bearer ' + $('4. Ambil Token Sesi dari SQLite Cache').first().json.token }}"
    elif node["id"] == "node-7-download-official-pdf":
        node["parameters"]["headerParameters"]["parameters"][0]["value"] = "={{ 'Bearer ' + $('4. Ambil Token Sesi dari SQLite Cache').first().json.token }}"

# Perbarui nama di connections jika ada
connections = {}
for src, targets in wf["connections"].items():
    new_src = "4. Ambil Token Sesi dari SQLite Cache" if src == "4. Auto-Login ke Portal Honda GP System" else src
    new_targets = {"main": []}
    for branch in targets.get("main", []):
        new_branch = []
        for it in branch:
            name = "4. Ambil Token Sesi dari SQLite Cache" if it["node"] == "4. Auto-Login ke Portal Honda GP System" else it["node"]
            new_branch.append({"node": name, "type": it["type"], "index": it["index"]})
        new_targets["main"].append(new_branch)
    connections[new_src] = new_targets

wf["connections"] = connections

with open(file_path, "w", encoding="utf-8") as f:
    json.dump(wf, f, indent=2)

print("SUCCESS: Workflow updated to use SQLite Token Cache!")

