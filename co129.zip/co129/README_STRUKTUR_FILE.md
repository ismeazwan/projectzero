# STRUKTUR FOLDER & ARSITEKTUR PROYEK CO129

Proyek otomasi OEM Procurement & RFQ Lifecycle ini dibagi secara modular dan terorganisir:

```
c:\Users\muham\Documents\co129\
├── 📂 portal-scraper-service/     # Layanan Backend FastAPI & Integrasi Scraper
│   ├── main.py                   # API Server & Live Bridge ke https://gpsystem.id
│   ├── rfq_quotation_cache.db    # Database Cache SQLite
│   └── scrapers/                 # Skrip Scraper (Hyundai TOTP, Honda)
│
├── 📂 mock_web_testing/           # [ARSIP / SIMULATOR] Dashboard Simulasi Web Mock
│   ├── server.js                 # Server Express lokal simulator
│   ├── honda_dashboard.html      # Tampilan UI tiruan Honda GPSystem
│   ├── dashboard.html            # Dashboard multi-OEM tiruan
│   ├── honda_login.html / index  # Halaman login mock
│   └── *.py, *.json              # Generator data dummy & file PDF mock
│
├── 📂 n8n_tools/                  # [INTERNAL / UTILITY] Skrip maintenance n8n
│   ├── sync_to_n8n.js            # Injektor langsung ke database n8n
│   ├── activate_wf.js            # Pengaktif status workflow
│   └── arsip workflow lama       # Backup versi workflow terdahulu
│
├── 📄 n8n_workflow_honda_rfq_lifecycle.json  # Workflow Utama n8n (Fase 1: Live Honda)
├── 📄 ai_summarizer.py           # Engine AI Penganalisis & Perangkum PDF RFQ
├── 📄 bulk_sender.py             # Tool pengirim email pengujian PO/RFQ
├── 📄 test.py                    # Script automation / Playwright E2E
├── 📄 docker-compose.yml         # Konfigurasi Container n8n & Worker
└── 📄 .env                       # Kredensial lingkungan (Aman)
```

