import json

with open("n8n_workflow_honda_rfq_lifecycle.json", "r", encoding="utf-8") as f:
    wf = json.load(f)

# Tambahkan Node IF setelah Node 2: Apakah ada email tender baru?
node_if_new_email = {
    "parameters": {
        "conditions": {
            "boolean": [
                {
                    "value1": "={{ $json.status === 'success' }}",
                    "value2": True
                }
            ]
        }
    },
    "id": "node-2b-if-new-email",
    "name": "2b. Apakah Ada Email Tender Baru?",
    "type": "n8n-nodes-base.if",
    "typeVersion": 2,
    "position": [540, 260]
}

# Update posisi node-node berikutnya
for node in wf["nodes"]:
    if node["id"] == "node-3-parse-rfq-no":
        node["position"] = [760, 200]
    elif node["id"] == "node-4-sync-and-cache-sqlite":
        node["position"] = [980, 200]
    elif node["id"] == "node-5-stream-pdf-from-db":
        node["position"] = [1200, 200]
    elif node["id"] == "node-6-send-telegram":
        node["position"] = [1420, 200]

# Sisipkan node-2b jika belum ada
wf["nodes"] = [n for n in wf["nodes"] if n["id"] != "node-2b-if-new-email"]
wf["nodes"].insert(2, node_if_new_email)

# Hubungkan connections:
# Node 2 -> Node 2b
# Node 2b (True) -> Node 3
wf["connections"]["2. Baca Email dari jaganetworks25@gmail.com"] = {
    "main": [
        [{"node": "2b. Apakah Ada Email Tender Baru?", "type": "main", "index": 0}]
    ]
}

wf["connections"]["2b. Apakah Ada Email Tender Baru?"] = {
    "main": [
        [{"node": "3. Ekstraksi Nomor RFQ (Mendukung Multi-Email)", "type": "main", "index": 0}],
        []
    ]
}

with open("n8n_workflow_honda_rfq_lifecycle.json", "w", encoding="utf-8") as f:
    json.dump(wf, f, indent=2)

print("SUCCESS: Guard node added to prevent duplicate triggers on empty / already-read inbox!")

