import json

file_path = "n8n_workflow_honda_rfq_lifecycle.json"
with open(file_path, "r", encoding="utf-8") as f:
    wf = json.load(f)

for node in wf["nodes"]:
    if node["id"] == "node-5-search-rfq":
        # Gunakan $('4. Auto-Login ke Portal Honda GP System').first().json.token secara eksplisit
        # Dan tambahkan User-Agent standar
        node["parameters"]["headerParameters"] = {
            "parameters": [
                {
                    "name": "Authorization",
                    "value": "={{ 'Bearer ' + $('4. Auto-Login ke Portal Honda GP System').first().json.token }}"
                },
                {
                    "name": "Referer",
                    "value": "https://gpsystem.id/"
                },
                {
                    "name": "Accept",
                    "value": "application/json, text/plain, */*"
                },
                {
                    "name": "User-Agent",
                    "value": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
                }
            ]
        }
        print("Updated Node 5 Authorization expression & User-Agent!")

with open(file_path, "w", encoding="utf-8") as f:
    json.dump(wf, f, indent=2)

print("SUCCESS: JSON updated.")

