import os
import json
import time
import pyotp
from playwright.sync_api import sync_playwright

def test_login_and_scrape():
    # Kredensial testing yang terdaftar di mock server
    USER_ID = "D004002"
    PASSWORD = "hyundai123!"
    TOTP_SECRET = "JBSWY3DPEHPK3PXP" # Base32 Google Authenticator Secret

    print("=" * 60)
    print("🚀 MEMULAI PENGUJIAN OTOMASI PLAYWRIGHT + GOOGLE AUTHENTICATOR")
    print("=" * 60)

    with sync_playwright() as p:
        # Buka Chromium headless (bisa diubah headless=False jika ingin melihat visualnya)
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(viewport={"width": 1920, "height": 1080})
        page = context.new_page()

        # Intercept Network Response untuk membuktikan ketahanan terhadap web dinamis
        intercepted_api_data = {}
        def on_response(response):
            if "/api/dashboard-data" in response.url:
                try:
                    intercepted_api_data["data"] = response.json()
                    print("\n[★ NETWORK INTERCEPT BERHASIL] Data backend berhasil disadap langsung dari aliran jaringan!")
                except:
                    pass

        page.on("response", on_response)

        # 1. Buka Halaman Login HMG Partner
        print("\n[1] Membuka halaman login mock di http://localhost:3000/index.html ...")
        page.goto("http://localhost:3000/index.html")
        page.wait_for_selector("#userId", timeout=10000)

        # 2. Input Kredensial ID dan Password
        print(f"[2] Mengisi User ID: {USER_ID} & Password...")
        page.fill("#userId", USER_ID)
        page.fill("#userPwd", PASSWORD)

        # 3. Hitung Kode OTP Google Authenticator secara Real-Time menggunakan pyotp
        totp = pyotp.TOTP(TOTP_SECRET)
        current_otp = totp.now()
        print(f"[3] Menghitung Kode TOTP Google Authenticator: {current_otp}")
        page.fill("#userOtp", current_otp)

        # 4. Klik Tombol Login
        print("[4] Klik Tombol Login & Menunggu Autentikasi 2FA...")
        page.click("#loginBtn")

        # 5. Tunggu Pengalihan Halaman ke Dashboard
        print("[5] Menunggu navigasi ke /dashboard.html ...")
        page.wait_for_url("**/dashboard.html", timeout=10000)
        print("    [✓] Sukses masuk ke halaman Dashboard!")

        # 6. Tunggu Data Tabel PO Selesai Dirender di Layar
        page.wait_for_selector("#poTableBody tr", timeout=10000)
        time.sleep(1) # Beri jeda rendering DOM

        # 7. Ekstraksi Data dari DOM (Scraping Tabel PO)
        print("\n[6] Mengekstrak data pesanan (PO) dari tabel DOM...")
        po_rows = page.locator("#poTableBody tr").all()
        scraped_po_list = []

        for r in po_rows:
            tds = r.locator("td").all_inner_texts()
            if len(tds) >= 7:
                scraped_po_list.append({
                    "poNumber": tds[0],
                    "partNumber": tds[1],
                    "partName": tds[2],
                    "quantity": tds[3],
                    "deliveryDate": tds[4],
                    "destination": tds[5],
                    "status": tds[6]
                })

        print(f"    [✓] Berhasil mengambil {len(scraped_po_list)} baris PO dari antarmuka visual!")

        # 8. Ekstraksi Dokumen Mutu CSR Edisi 5
        print("\n[7] Mengekstrak buletin regulasi CSR dari dashboard...")
        csr_items = page.locator(".csr-item").all_inner_texts()

        # 9. Tampilkan Hasil Akhir Ekstraksi
        output_result = {
            "testStatus": "PASSED_SUCCESSFULLY",
            "extractedAt": time.strftime("%Y-%m-%d %H:%M:%S"),
            "authenticatedUser": USER_ID,
            "scrapedPurchaseOrders": scraped_po_list,
            "scrapedBulletins": csr_items,
            "networkInterceptedPoCount": len(intercepted_api_data.get("data", {}).get("purchaseOrders", []))
        }

        # Simpan ke file JSON
        output_file = "test_scrape_result.json"
        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(output_result, f, indent=2, ensure_ascii=False)

        print(f"\n[8] Hasil pengujian lengkap disimpan ke file: {output_file}")
        print("=" * 60)
        print("HASIL DATA YANG BERHASIL DIAMBIL PLAYWRIGHT:")
        print(json.dumps(output_result, indent=2))
        print("=" * 60)

        browser.close()

if __name__ == "__main__":
    test_login_and_scrape()

