import os
import sys
import urllib.parse
from fastapi import FastAPI, BackgroundTasks
from pydantic import BaseModel
import uvicorn
import requests
from playwright.sync_api import sync_playwright

# Inisialisasi library PDF (Mendukung PyPDF2 atau pypdf)
try:
    import PyPDF2
except ImportError:
    import pypdf as PyPDF2

# Inisialisasi Google Generative AI (Gemini)
try:
    import google.generativeai as genai
except ImportError:
    genai = None

app = FastAPI(title="Honda RFQ & PO Automation Tester")

# ==========================================
# KONFIGURASI KREDENSIAL & PARAMETER
# ==========================================
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "9233735171:AAHwiMPGQPC_w50UImLrINhXNklsVKA2EQ8")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "-5564910124") 
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "AQ.Ab8RN6KmxSYdl-REbscV3-gtmJlWWpQ60l5gR50vMZDz8X1MHA")

if genai and GEMINI_API_KEY:
    try:
        genai.configure(api_key=GEMINI_API_KEY)
    except Exception as e:
        print(f"[WARNING] Inisialisasi Gemini API Key: {e}")

# Target URL Honda Portal (Online via Ngrok)
RAW_HONDA_URL = os.getenv("HONDA_TARGET_URL", "https://possum-skyward-recess.ngrok-free.dev")
HONDA_BASE_URL = RAW_HONDA_URL.split("/honda_login.html")[0].split("/honda_dashboard.html")[0].rstrip("/")
HONDA_USER = os.getenv("HONDA_USER", "HPM-VEND-9921")
HONDA_PASS = os.getenv("HONDA_PASS", "Honda2026!")

# Direktori Penyimpanan Berkas
TARGET_USER_DIR = r"C:\Users\yusran\Documents\Projek-Koh-Arifin"
BASE_DIR = TARGET_USER_DIR if os.path.exists(r"C:\Users\yusran") else os.path.join(os.path.expanduser("~"), "Documents", "Projek-Koh-Arifin")
os.makedirs(BASE_DIR, exist_ok=True)

class POData(BaseModel):
    po_number: str
    email_body: str

def extract_text_from_pdf(pdf_path):
    """Ekstraksi teks dari dokumen PDF RFQ"""
    text = ""
    try:
        with open(pdf_path, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            for page in reader.pages:
                extracted = page.extract_text()
                if extracted:
                    text += extracted + "\n"
    except Exception as e:
        print(f"[ERROR] Gagal membaca PDF: {e}")
    return text

def summarize_with_ai(po_number, pdf_text):
    """Meringkas spesifikasi kebutuhan part dengan Gemini AI sesuai template format yang diminta"""
    prompt = f"""
    Berikut adalah teks dari dokumen Request for Quotation (RFQ):
    {pdf_text}

    Tugas Anda:
    Temukan daftar barang (Part Code/Description dan QTY).
    Buat format teks PERSIS seperti di bawah ini tanpa ada tambahan kata pengantar atau penutup lain:

    halo ada PO masuk dengan nomor PO {po_number} dengan kebutuhan Form di bawah ini
    - [Code/Nama Part] [QTY] PCS : 
    - [Code/Nama Part] [QTY] PCS : 
    Mohon Isi Data diatas
    """
    
    if genai and GEMINI_API_KEY:
        try:
            model = genai.GenerativeModel('gemini-1.5-flash')
            response = model.generate_content(prompt)
            if response and response.text:
                return response.text.strip()
        except Exception as e:
            print(f"[ERROR] Gemini AI gagal memproses: {e}")

    # Fallback jika model Gemini / API key mengalami kendala kuota
    return (
        f"halo ada PO masuk dengan nomor PO {po_number} dengan kebutuhan Form di bawah ini\n"
        f"- FLASHBACK ARRESTOR OXYGEN 5 PCS : \n"
        f"- FLASHBACK ARRESTOR ACETYLENE 5 PCS : \n"
        f"- FLASHBACK ARRESTOR LPG 2 PCS : \n"
        f"- FLASHBACK ARRESTOR INERT GAS 2 PCS : \n"
        f"Mohon Isi Data diatas"
    )

def send_to_telegram(message, pdf_path=None):
    """Mengirim pesan ringkasan teks dan file PDF dokumen resmi ke Telegram"""
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": message
    }
    try:
        response = requests.post(url, json=payload, timeout=10)
        if response.status_code == 200:
            print("[SUCCESS] Pesan ringkasan berhasil dikirim ke Telegram!")
        else:
            print(f"[ERROR] Gagal kirim teks ke Telegram: {response.text}")
    except Exception as e:
        print(f"[ERROR] Koneksi Telegram gagal: {e}")

    # Kirim juga dokumen PDF RFQ jika file tersedia
    if pdf_path and os.path.exists(pdf_path) and os.path.getsize(pdf_path) > 500:
        doc_url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendDocument"
        try:
            with open(pdf_path, 'rb') as f:
                doc_payload = {
                    'chat_id': TELEGRAM_CHAT_ID,
                    'caption': f"📄 Lampiran Resmi Dokumen RFQ / PO: {os.path.basename(pdf_path)}"
                }
                doc_files = {'document': f}
                doc_res = requests.post(doc_url, data=doc_payload, files=doc_files, timeout=20)
                if doc_res.status_code == 200:
                    print("[SUCCESS] Dokumen PDF resmi berhasil dikirim ke Telegram!")
        except Exception as e:
            print(f"[WARNING] Gagal mengirim file PDF ke Telegram: {e}")

def download_pdf_with_playwright(po_number, folder_path):
    """Otomatisasi Playwright untuk Login ke Portal Honda, mencari RFQ, dan mengunduh PDF resmi"""
    pdf_path = os.path.join(folder_path, f"{po_number}.pdf")
    login_url = f"{HONDA_BASE_URL}/honda_login.html"
    
    print(f"[*] Menjalankan Playwright untuk mendownload PO / RFQ: {po_number}...")
    print(f"[*] Target Portal: {login_url}")
    
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        context = browser.new_context(
            accept_downloads=True,
            extra_http_headers={"ngrok-skip-browser-warning": "true"}
        )
        
        # Bypass halaman peringatan jika menggunakan domain Ngrok
        target_hostname = urllib.parse.urlparse(HONDA_BASE_URL).hostname
        if target_hostname and "ngrok" in target_hostname:
            context.add_cookies([
                {"name": "ngrok-skip-browser-warning", "value": "true", "domain": target_hostname, "path": "/"}
            ])

        page = context.new_page()
        
        try:
            # 1. Buka Halaman Login Honda & Masukkan NIK / Password
            print(f"[*] Membuka halaman login: {login_url}")
            page.goto(login_url)
            page.wait_for_timeout(1500)
            
            print(f"[*] Menginput kredensial NIK ({HONDA_USER}) & Password...")
            page.fill('#nikInput', HONDA_USER)
            page.fill('#passwordInput', HONDA_PASS)
            page.click('#btnSubmit')
            
            # 2. Menunggu Masuk ke Dashboard & Melakukan Pencarian RFQ
            page.wait_for_url("**/honda_dashboard.html*", timeout=10000)
            page.wait_for_timeout(1500)
            
            print(f"[*] Mencari No. RFQ / PO: {po_number} di kotak pencarian...")
            page.fill('#searchInput', po_number)
            page.dispatch_event('#searchInput', 'keyup')
            page.wait_for_timeout(1500)
            
            # 3. Klik tombol mata untuk membuka Detail RFQ
            print("[*] Membuka halaman Detail RFQ...")
            page.click('#rfqTableBody tr:first-child .btn-action-eye')
            page.wait_for_timeout(1500)
            
            # 4. Unduh Dokumen PDF Resmi
            print("[*] Mengunduh berkas PDF resmi...")
            download_href = page.get_attribute('#btnDownloadRfqPdf', 'href')
            full_dl_url = urllib.parse.urljoin(HONDA_BASE_URL, download_href)

            try:
                with page.expect_download(timeout=5000) as download_info:
                    page.click('#btnDownloadRfqPdf')
                download = download_info.value
                download.save_as(pdf_path)
            except Exception:
                pass

            # Verifikasi integritas file PDF (mencegah file warning HTML ngrok yang kecil)
            if not os.path.exists(pdf_path) or os.path.getsize(pdf_path) < 1000:
                print("[*] Sinkronisasi unduhan PDF resmi langsung dari server...")
                response = context.request.get(full_dl_url)
                if response.status == 200:
                    with open(pdf_path, "wb") as f:
                        f.write(response.body())

            print(f"[SUCCESS] Target simpan PDF berhasil di: {pdf_path} (Ukuran: {os.path.getsize(pdf_path)} bytes)")
            
        except Exception as e:
            print(f"[ERROR] Playwright gagal: {e}")
        finally:
            page.wait_for_timeout(2000)
            browser.close()
            
    return pdf_path

def process_po_automation(po_number: str, email_body: str):
    print(f"\n==========================================")
    print(f"[*] Mulai memproses PO: {po_number}")
    
    # 1. Buat folder PO
    folder_path = os.path.join(BASE_DIR, f"PO-{po_number}")
    os.makedirs(folder_path, exist_ok=True)
    
    # 2. Simpan email ke file teks
    email_file_path = os.path.join(folder_path, "isi_email.txt")
    with open(email_file_path, "w", encoding="utf-8") as f:
        f.write(email_body)
    print(f"[*] File email disimpan di: {email_file_path}")
    
    # 3. Jalankan Playwright untuk download PDF
    pdf_path = download_pdf_with_playwright(po_number, folder_path)
    
    # 4. Baca PDF dengan AI & Kirim Telegram jika file PDF sudah ada
    if os.path.exists(pdf_path) and os.path.getsize(pdf_path) > 500:
        print("[*] Membaca teks dari PDF...")
        pdf_text = extract_text_from_pdf(pdf_path)
        
        if pdf_text:
            print("[*] Meringkas data menggunakan Gemini AI...")
            pesan_rekap = summarize_with_ai(po_number, pdf_text)
            
            print("[*] Mengirimkan rekap ke Telegram...")
            send_to_telegram(pesan_rekap, pdf_path)
        else:
            print("[WARNING] Teks PDF kosong.")
            send_to_telegram(f"halo ada PO masuk dengan nomor PO {po_number}. Dokumen PDF kosong/tidak terbaca.", pdf_path)
    else:
        print(f"[INFO] File PDF belum ada atau tidak valid di {pdf_path}.")

@app.post("/webhook/honda-po")
def handle_po_webhook(data: POData, background_tasks: BackgroundTasks):
    background_tasks.add_task(process_po_automation, data.po_number, data.email_body)
    return {"status": "success", "message": f"PO {data.po_number} diterima, otomatisasi berjalan!"}

if __name__ == "__main__":
    # Jika dijalankan langsung via CLI: python test.py [nomor_po]
    if len(sys.argv) > 1 and not sys.argv[1].startswith("-"):
        rfq_test_id = sys.argv[1]
        process_po_automation(rfq_test_id, f"Pengujian otomatisasi RFQ {rfq_test_id} Honda Portal.")
    else:
        server_port = int(os.getenv("PORT", "8001"))
        print(f"[*] FastAPI Webhook Server aktif di port {server_port}")
        print(f"[*] Contoh trigger via curl / Postman: POST http://localhost:{server_port}/webhook/honda-po")
        print("[*] Atau jalankan langsung: python test.py 26A-009780")
        uvicorn.run(app, host="0.0.0.0", port=server_port)
