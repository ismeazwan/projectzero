"""
Host Windows Cookie Extractor & Sync Utility for LG SINGLEX
Dynamically auto-detects ALL installed Chromium browsers and profiles
(Google Chrome, Microsoft Edge, Opera, Opera GX, Brave), decrypts cookies
via Windows DPAPI, and synchronizes directly into the running Docker container.

Supports live non-blocking extraction even when the browser is actively running
and holding an exclusive file lock on the Cookies database.
"""

import os
import glob
import json
import base64
import sqlite3
import shutil
import tempfile
import subprocess
import ctypes
from ctypes import wintypes
from typing import Dict, Any, Optional, List, Tuple

try:
    import win32crypt
    from Crypto.Cipher import AES
    import psutil
except ImportError:
    win32crypt = None
    AES = None
    psutil = None

kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
ntdll = ctypes.WinDLL("ntdll")

PROCESS_DUP_HANDLE = 0x0040
DUPLICATE_SAME_ACCESS = 0x00000002

CloseHandle = kernel32.CloseHandle
CloseHandle.argtypes = [wintypes.HANDLE]
CloseHandle.restype = wintypes.BOOL

DuplicateHandle = kernel32.DuplicateHandle
DuplicateHandle.argtypes = [
    wintypes.HANDLE, wintypes.HANDLE, wintypes.HANDLE,
    ctypes.POINTER(wintypes.HANDLE), wintypes.DWORD, wintypes.BOOL, wintypes.DWORD
]
DuplicateHandle.restype = wintypes.BOOL

GetCurrentProcess = kernel32.GetCurrentProcess
GetCurrentProcess.restype = wintypes.HANDLE

OpenProcess = kernel32.OpenProcess
OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
OpenProcess.restype = wintypes.HANDLE

GetFinalPathNameByHandleW = kernel32.GetFinalPathNameByHandleW
GetFinalPathNameByHandleW.argtypes = [wintypes.HANDLE, wintypes.LPWSTR, wintypes.DWORD, wintypes.DWORD]
GetFinalPathNameByHandleW.restype = wintypes.DWORD

class SYSTEM_HANDLE_TABLE_ENTRY_INFO_EX(ctypes.Structure):
    _fields_ = [
        ("Object", ctypes.c_void_p),
        ("UniqueProcessId", ctypes.c_size_t),
        ("HandleValue", ctypes.c_size_t),
        ("GrantedAccess", wintypes.ULONG),
        ("CreatorBackTraceIndex", wintypes.USHORT),
        ("ObjectTypeIndex", wintypes.USHORT),
        ("HandleAttributes", wintypes.ULONG),
        ("Reserved", wintypes.ULONG),
    ]

appdata = os.environ.get("APPDATA", "")
localappdata = os.environ.get("LOCALAPPDATA", "")

def get_all_browser_targets() -> List[Tuple[str, str, str]]:
    """
    Dynamically scan all Chromium browser directories and user profiles on Windows.
    Returns list of (browser_label, cookie_db_path, local_state_path)
    """
    targets = []
    
    # 1. Opera & Opera GX
    for opera_name in ["Opera Stable", "Opera GX Stable"]:
        op_base = os.path.join(appdata, "Opera Software", opera_name)
        if os.path.exists(op_base):
            ls = os.path.join(op_base, "Local State")
            for sub in ["Default", ""]:
                c = os.path.join(op_base, sub, "Network", "Cookies") if sub else os.path.join(op_base, "Network", "Cookies")
                if os.path.exists(c):
                    targets.append((f"{opera_name} ({sub or 'Root'})", c, ls))

    # 2. Google Chrome (All Profiles: Default, Profile 1, Profile 2, etc.)
    chrome_base = os.path.join(localappdata, "Google", "Chrome", "User Data")
    if os.path.exists(chrome_base):
        ls = os.path.join(chrome_base, "Local State")
        for p in glob.glob(os.path.join(chrome_base, "*")):
            c = os.path.join(p, "Network", "Cookies")
            if os.path.exists(c):
                targets.append((f"Google Chrome ({os.path.basename(p)})", c, ls))

    # 3. Microsoft Edge (All Profiles: Default, Profile 1, etc.)
    edge_base = os.path.join(localappdata, "Microsoft", "Edge", "User Data")
    if os.path.exists(edge_base):
        ls = os.path.join(edge_base, "Local State")
        for p in glob.glob(os.path.join(edge_base, "*")):
            c = os.path.join(p, "Network", "Cookies")
            if os.path.exists(c):
                targets.append((f"Microsoft Edge ({os.path.basename(p)})", c, ls))

    # 4. Brave Browser
    brave_base = os.path.join(localappdata, "BraveSoftware", "Brave-Browser", "User Data")
    if os.path.exists(brave_base):
        ls = os.path.join(brave_base, "Local State")
        for p in glob.glob(os.path.join(brave_base, "*")):
            c = os.path.join(p, "Network", "Cookies")
            if os.path.exists(c):
                targets.append((f"Brave ({os.path.basename(p)})", c, ls))

    return targets

def copy_cookie_file_safely(c_path: str, temp_db: str) -> bool:
    """
    Copies Cookies SQLite database. If locked by running browser, duplicates
    the live file handle directly from the process without closing the browser.
    """
    try:
        shutil.copy2(c_path, temp_db)
        return True
    except PermissionError:
        pass
    except Exception:
        return False

    if not psutil:
        return False

    try:
        norm_target = os.path.normpath(c_path).lower()
        target_pid = None
        for p in psutil.process_iter(['name']):
            p_name = (p.info['name'] or '').lower()
            if any(b in p_name for b in ['opera', 'chrome', 'msedge', 'brave']):
                try:
                    for of in p.open_files():
                        if os.path.normpath(of.path).lower() == norm_target:
                            target_pid = p.pid
                            break
                except Exception:
                    pass
            if target_pid:
                break

        if not target_pid:
            return False

        h_proc = OpenProcess(PROCESS_DUP_HANDLE, False, target_pid)
        if not h_proc:
            return False

        size = 1024 * 1024 * 8
        buf = ctypes.create_string_buffer(size)
        ret_len = wintypes.ULONG()
        status = ntdll.NtQuerySystemInformation(64, buf, size, ctypes.byref(ret_len))
        if status != 0:
            CloseHandle(h_proc)
            return False

        num_handles = ctypes.c_size_t.from_buffer_copy(buf[:ctypes.sizeof(ctypes.c_size_t)]).value
        entry_size = ctypes.sizeof(SYSTEM_HANDLE_TABLE_ENTRY_INFO_EX)
        offset = ctypes.sizeof(ctypes.c_size_t) * 2

        duplicated_handle = None
        path_buf = ctypes.create_unicode_buffer(1024)

        for i in range(num_handles):
            entry_bytes = buf[offset:offset+entry_size]
            if len(entry_bytes) < entry_size:
                break
            entry = SYSTEM_HANDLE_TABLE_ENTRY_INFO_EX.from_buffer_copy(entry_bytes)
            offset += entry_size

            if entry.UniqueProcessId == target_pid:
                h_dup = wintypes.HANDLE()
                ok = DuplicateHandle(
                    h_proc,
                    wintypes.HANDLE(entry.HandleValue),
                    GetCurrentProcess(),
                    ctypes.byref(h_dup),
                    0,
                    False,
                    DUPLICATE_SAME_ACCESS
                )
                if ok and h_dup.value:
                    res_len = GetFinalPathNameByHandleW(h_dup, path_buf, 1024, 0)
                    if res_len > 0:
                        p_val = os.path.normpath(path_buf.value.replace('\\\\?\\', '')).lower()
                        if p_val == norm_target:
                            duplicated_handle = h_dup
                            break
                    CloseHandle(h_dup)

        CloseHandle(h_proc)

        if duplicated_handle:
            kernel32.SetFilePointer(duplicated_handle, 0, None, 0)
            f_size = kernel32.GetFileSize(duplicated_handle, None)
            if f_size > 0:
                read_buf = ctypes.create_string_buffer(f_size)
                bytes_read = wintypes.DWORD()
                kernel32.ReadFile(duplicated_handle, read_buf, f_size, ctypes.byref(bytes_read), None)
                with open(temp_db, 'wb') as f:
                    f.write(read_buf.raw[:bytes_read.value])
                CloseHandle(duplicated_handle)
                return True
            CloseHandle(duplicated_handle)
    except Exception as ex:
        print(f"Live copy exception: {ex}")
    return False

def get_master_key(path: str):
    if not os.path.exists(path) or not win32crypt:
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            local_state = json.load(f)
        encrypted_key = base64.b64decode(local_state["os_crypt"]["encrypted_key"])
        encrypted_key = encrypted_key[5:]
        return win32crypt.CryptUnprotectData(encrypted_key, None, None, None, 0)[1]
    except Exception as e:
        print(f"Error getting master key from {path}: {e}")
        return None

def decrypt_val(buff: bytes, master_key: bytes) -> str:
    if not win32crypt or not AES:
        return ""
    try:
        if buff[:3] == b'v10' or buff[:3] == b'v11':
            iv = buff[3:15]
            payload = buff[15:]
            cipher = AES.new(master_key, AES.MODE_GCM, iv)
            decrypted = cipher.decrypt(payload)[:-16].decode(errors="ignore")
            return decrypted
        else:
            return win32crypt.CryptUnprotectData(buff, None, None, None, 0)[1].decode(errors="ignore")
    except Exception:
        return ""

def clean_cookie_val(val: str) -> str:
    """Strip Opera / Chromium integrity wrapper prefix if present"""
    val = val.strip()
    if val.startswith("!") and "!" in val[1:]:
        second_bang = val.find("!", 1)
        if second_bang != -1 and second_bang < 40:
            val = val[second_bang + 1:].strip()
    return val

def extract_cookies_from_browser() -> Dict[str, Any]:
    browser_targets = get_all_browser_targets()
    
    for b_name, c_path, ls_path in browser_targets:
        if not (os.path.exists(c_path) and os.path.exists(ls_path)):
            continue
        
        mkey = get_master_key(ls_path)
        if not mkey:
            continue
            
        temp_db = os.path.join(tempfile.gettempdir(), f"cookie_tmp_{os.getpid()}_{abs(hash(b_name))}.sqlite")
        copied = copy_cookie_file_safely(c_path, temp_db)
        if not copied:
            continue

        try:
            conn = sqlite3.connect(temp_db)
            cursor = conn.cursor()
            cursor.execute("SELECT host_key, name, encrypted_value FROM cookies WHERE host_key LIKE '%singlex%' OR host_key LIKE '%ondemand%'")
            rows = cursor.fetchall()
            conn.close()
            try:
                os.remove(temp_db)
            except Exception:
                pass
            
            cookies_dict = {}
            for host, name, enc_val in rows:
                if "singlex" in host:
                    val = decrypt_val(enc_val, mkey)
                    if val:
                        cleaned = clean_cookie_val(val)
                        if cleaned:
                            cookies_dict[name] = cleaned
                        
            if cookies_dict:
                # 1. Update Host SQLite database
                base_dir = os.path.dirname(os.path.abspath(__file__))
                db_target = os.path.join(base_dir, "portal-scraper-service", "data", "lg_singlex.sqlite")
                os.makedirs(os.path.dirname(db_target), exist_ok=True)
                
                c_conn = sqlite3.connect(db_target)
                c_cur = c_conn.cursor()
                c_cur.execute("CREATE TABLE IF NOT EXISTS lg_session (id INTEGER PRIMARY KEY, cookies_json TEXT, headers_json TEXT, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)")
                c_cur.execute("SELECT headers_json FROM lg_session WHERE id = 1")
                h_row = c_cur.fetchone()
                headers_json = h_row[0] if h_row else "{}"
                c_cur.execute("""
                    INSERT OR REPLACE INTO lg_session (id, cookies_json, headers_json, updated_at)
                    VALUES (1, ?, ?, CURRENT_TIMESTAMP)
                """, (json.dumps(cookies_dict), headers_json))
                c_conn.commit()
                c_conn.close()

                # 2. Sync to Docker container oem_scraper_worker
                try:
                    subprocess.run(
                        ["docker", "cp", db_target, "oem_scraper_worker:/app/data/lg_singlex.sqlite"],
                        check=False,
                        capture_output=True
                    )
                except Exception as dex:
                    print(f"Docker sync warning: {dex}")

                return {
                    "ok": True,
                    "browser": b_name,
                    "count": len(cookies_dict),
                    "cookies": list(cookies_dict.keys()),
                    "message": f"Berhasil menyinkronkan {len(cookies_dict)} cookies dari {b_name}!"
                }
        except Exception as ex:
            print(f"Error accessing {b_name} cookies: {ex}")
            try:
                if os.path.exists(temp_db):
                    os.remove(temp_db)
            except Exception:
                pass

    return {
        "ok": False,
        "locked": False,
        "message": "Tidak ditemukan cookie portal Singlex di browser Chrome/Edge/Opera/Brave. Pastikan Anda sudah login ke portal LG di browser Anda."
    }

if __name__ == "__main__":
    res = extract_cookies_from_browser()
    print(json.dumps(res, indent=2))
