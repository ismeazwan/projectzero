import json

BOT_TOKEN = "9195418527:AAE86SeYoCnNHcCLD916RemhovjFMZGksYY"
CHAT_ID = "1859219519"

# PASSWORD SHA-256 HASHER
# nuclearportalhppm -> sha256
HASHED_PASS = "3e7f48b94ce55a9b31d68383c2ad2d5f9fc8776840742f5d9cc0e84b80a1334c"

workflow = {
  "name": "Honda HPPM - Fase 1: Live RFQ Lifecycle & Telegram Notifier",
  "nodes": [
    {
      "parameters": {
        "rule": {
          "interval": [
            {
              "field": "minutes",
              "minutesInterval": 1
            }
          ]
        }
      },
      "id": "node-1-schedule",
      "name": "1. Jadwal: Pantau Email Masuk Tiap 1 Menit",
      "type": "n8n-nodes-base.scheduleTrigger",
      "typeVersion": 1.2,
      "position": [180, 260]
    },
    {
      "parameters": {
        "url": "http://scraper-worker:8000/api/email/fetch-latest-rfq",
        "method": "GET",
        "options": {}
      },
      "id": "node-2-fetch-email",
      "name": "2. Baca Email dari jaganetworks25@gmail.com",
      "type": "n8n-nodes-base.httpRequest",
      "typeVersion": 4.2,
      "position": [400, 260]
    },
    {
      "parameters": {
        "jsCode": """// Ekstraksi Nomor RFQ dari Subjek atau Isi Email
const email = $input.first().json;
const fullText = (email.subject || '') + ' ' + (email.body || '');
const match = fullText.match(/(2[4-9][A-Z]-\\d{6})/);
const detectedRfqNumber = match ? match[1] : (email.rfqId || '24A-001227');

return [{
  json: {
    rfqNumber: detectedRfqNumber,
    emailSubject: email.subject,
    emailSender: email.from,
    emailDate: email.date
  }
}];"""
      },
      "id": "node-3-parse-rfq-no",
      "name": "3. Ekstraksi Nomor RFQ",
      "type": "n8n-nodes-base.code",
      "typeVersion": 2,
      "position": [620, 260]
    },
    {
      "parameters": {
        "url": "https://gpsystem.id/api/v1/auth/login",
        "method": "POST",
        "sendBody": True,
        "specifyBody": "json",
        "jsonBody": """={{ JSON.stringify({
  username: "apsindo@cbn.net.id",
  password: "3e7f48b94ce55a9b31d68383c2ad2d5f9fc8776840742f5d9cc0e84b80a1334c",
  rememberMe: true
}) }}""",
        "options": {}
      },
      "id": "node-4-auto-login-honda",
      "name": "4. Auto-Login ke Portal Honda GP System",
      "type": "n8n-nodes-base.httpRequest",
      "typeVersion": 4.2,
      "position": [840, 260]
    },
    {
      "parameters": {
        "url": "=https://gpsystem.id/api/v1/supplier/rfqs?search={{ $('3. Ekstraksi Nomor RFQ').first().json.rfqNumber }}&rowsPerPage=1&page=1",
        "method": "GET",
        "headerParameters": {
          "parameters": [
            {
              "name": "Authorization",
              "value": "={{ 'Bearer ' + $json.token }}"
            },
            {
              "name": "Referer",
              "value": "https://gpsystem.id/"
            },
            {
              "name": "Accept",
              "value": "application/json, text/plain, */*"
            }
          ]
        },
        "options": {}
      },
      "id": "node-5-search-rfq",
      "name": "5. Cari Detail & Dapatkan rfqId Asli",
      "type": "n8n-nodes-base.httpRequest",
      "typeVersion": 4.2,
      "position": [1060, 260]
    },
    {
      "parameters": {
        "url": "=https://gpsystem.id/api/v1/supplier/rfqs/{{ $json[0].rfqId }}/items?rowsPerPage=25&page=1",
        "method": "GET",
        "headerParameters": {
          "parameters": [
            {
              "name": "Authorization",
              "value": "={{ 'Bearer ' + $('4. Auto-Login ke Portal Honda GP System').first().json.token }}"
            },
            {
              "name": "Referer",
              "value": "https://gpsystem.id/"
            },
            {
              "name": "Accept",
              "value": "application/json, text/plain, */*"
            }
          ]
        },
        "options": {}
      },
      "id": "node-6-get-rfq-items",
      "name": "6. Ambil Rincian Item Parts Tender",
      "type": "n8n-nodes-base.httpRequest",
      "typeVersion": 4.2,
      "position": [1280, 260]
    },
    {
      "parameters": {
        "url": "=https://gpsystem.id/api/v1/document/download/print-rfq/{{ $('5. Cari Detail & Dapatkan rfqId Asli').first().json[0].rfqId }}",
        "method": "GET",
        "headerParameters": {
          "parameters": [
            {
              "name": "Authorization",
              "value": "={{ 'Bearer ' + $('4. Auto-Login ke Portal Honda GP System').first().json.token }}"
            },
            {
              "name": "Referer",
              "value": "https://gpsystem.id/"
            }
          ]
        },
        "responseFormat": "file",
        "options": {}
      },
      "id": "node-7-download-official-pdf",
      "name": "7. Download File PDF Resmi Berstempel Honda",
      "type": "n8n-nodes-base.httpRequest",
      "typeVersion": 4.2,
      "position": [1500, 260]
    },
    {
      "parameters": {
        "jsCode": """// Format Rangkuman Eksekutif untuk Telegram
const rfqData = $('5. Cari Detail & Dapatkan rfqId Asli').first().json[0] || {};
const items = $('6. Ambil Rincian Item Parts Tender').all().map(i => i.json);
const pdfBinary = $('7. Download File PDF Resmi Berstempel Honda').first().binary;

const rfqNum = rfqData.rfqNumber || '24A-001227';
const prNum = rfqData.prNumber || '-';
const dept = rfqData.deptName || 'DIE CASTING';
const buyer = rfqData.prByrName || 'Erpan Maulana';
const closingDate = (rfqData.rfqEstQuotationDate || '').split(' ')[0] || 'Segera';

let itemsList = '';
items.forEach((it, idx) => {
  itemsList += `\\n  ${idx + 1}. [${it.purItCode || '-'}] ${it.purItName || '-'}\\n     Qty: ${it.rfqItQty || 1} ${it.prItUomSymbol || 'Pcs'}`;
});

const caption = `📋 [NEW TENDER NOTIFICATION - HONDA HPPM]\\n` +
`===================================\\n` +
`• No. RFQ     : ${rfqNum}\\n` +
`• No. PR      : ${prNum}\\n` +
`• Department  : ${dept}\\n` +
`• Buyer PIC   : ${buyer}\\n` +
`• Batas Waktu : ${closingDate}\\n` +
`• Status      : ${rfqData.rfqStatus || 'ACTIVE'}\\n\\n` +
`📦 DAFTAR ITEM TENDER:${itemsList}\\n\\n` +
`👉 Dokumen PDF RFQ Resmi Asli dari Portal Honda terlampir.`;

return [{
  json: {
    rfqNumber: rfqNum,
    telegramCaption: caption.slice(0, 1020)
  },
  binary: pdfBinary
}];"""
      },
      "id": "node-8-format-telegram",
      "name": "8. Format Pesan & Gabung Dokumen PDF",
      "type": "n8n-nodes-base.code",
      "typeVersion": 2,
      "position": [1720, 260]
    },
    {
      "parameters": {
        "url": f"https://api.telegram.org/bot{BOT_TOKEN}/sendDocument",
        "method": "POST",
        "sendBody": True,
        "contentType": "multipart-form-data",
        "bodyParameters": {
          "parameters": [
            {
              "name": "chat_id",
              "value": CHAT_ID
            },
            {
              "name": "caption",
              "value": "={{ $json.telegramCaption }}"
            },
            {
              "parameterType": "formBinaryData",
              "name": "document",
              "inputDataFieldName": "data"
            }
          ]
        },
        "options": {}
      },
      "id": "node-9-send-telegram",
      "name": "9. Kirim Dokumen PDF & Rangkuman ke Telegram",
      "type": "n8n-nodes-base.httpRequest",
      "typeVersion": 4.2,
      "position": [1940, 260]
    }
  ],
  "connections": {
    "1. Jadwal: Pantau Email Masuk Tiap 1 Menit": {
      "main": [
        [{"node": "2. Baca Email dari jaganetworks25@gmail.com", "type": "main", "index": 0}]
      ]
    },
    "2. Baca Email dari jaganetworks25@gmail.com": {
      "main": [
        [{"node": "3. Ekstraksi Nomor RFQ", "type": "main", "index": 0}]
      ]
    },
    "3. Ekstraksi Nomor RFQ": {
      "main": [
        [{"node": "4. Auto-Login ke Portal Honda GP System", "type": "main", "index": 0}]
      ]
    },
    "4. Auto-Login ke Portal Honda GP System": {
      "main": [
        [{"node": "5. Cari Detail & Dapatkan rfqId Asli", "type": "main", "index": 0}]
      ]
    },
    "5. Cari Detail & Dapatkan rfqId Asli": {
      "main": [
        [{"node": "6. Ambil Rincian Item Parts Tender", "type": "main", "index": 0}]
      ]
    },
    "6. Ambil Rincian Item Parts Tender": {
      "main": [
        [{"node": "7. Download File PDF Resmi Berstempel Honda", "type": "main", "index": 0}]
      ]
    },
    "7. Download File PDF Resmi Berstempel Honda": {
      "main": [
        [{"node": "8. Format Pesan & Gabung Dokumen PDF", "type": "main", "index": 0}]
      ]
    },
    "8. Format Pesan & Gabung Dokumen PDF": {
      "main": [
        [{"node": "9. Kirim Dokumen PDF & Rangkuman ke Telegram", "type": "main", "index": 0}]
      ]
    }
  },
  "settings": {
    "executionOrder": "v1"
  }
}

with open("n8n_workflow_honda_rfq_lifecycle.json", "w", encoding="utf-8") as f:
    json.dump(workflow, f, indent=2)

print("SUCCESS: Workflow Phase 1 Live Honda generated cleanly!")

