"""
Host Bridge Service for LG Singlex Cookie Sync & Document Conversion
Runs on Windows host (port 5005) to bridge Telegram Bot running inside Docker
with host browser cookies, Windows DPAPI decryption, and MS Word native PDF conversion.
"""

import json
import logging
import base64
import os
import tempfile
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from auto_extract_cookies import extract_cookies_from_browser

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger("host_bridge_service")

PORT = 5005

def convert_docx_to_pdf_win32(docx_bytes: bytes) -> bytes:
    """Konversi file docx ke PDF menggunakan native MS Word via COM di Windows host."""
    import pythoncom
    import win32com.client
    
    pythoncom.CoInitialize()
    temp_dir = tempfile.gettempdir()
    unique_id = os.urandom(8).hex()
    in_docx = os.path.join(temp_dir, f"quot_{unique_id}.docx")
    out_pdf = os.path.join(temp_dir, f"quot_{unique_id}.pdf")
    
    word = None
    doc = None
    try:
        with open(in_docx, "wb") as f:
            f.write(docx_bytes)
            
        word = win32com.client.Dispatch("Word.Application")
        word.Visible = False
        word.DisplayAlerts = 0  # Matikan alert/dialog popups
        
        doc = word.Documents.Open(os.path.abspath(in_docx), ReadOnly=True)
        # Format 17 adalah wdFormatPDF
        doc.SaveAs(os.path.abspath(out_pdf), FileFormat=17)
        doc.Close(SaveChanges=0)
        doc = None
        
        word.Quit()
        word = None
        
        with open(out_pdf, "rb") as f:
            pdf_bytes = f.read()
        return pdf_bytes
    except Exception as e:
        logger.error(f"Error in convert_docx_to_pdf_win32: {e}")
        raise e
    finally:
        if doc:
            try:
                doc.Close(SaveChanges=0)
            except Exception:
                pass
        if word:
            try:
                word.Quit()
            except Exception:
                pass
        pythoncom.CoUninitialize()
        if os.path.exists(in_docx):
            try:
                os.remove(in_docx)
            except Exception:
                pass
        if os.path.exists(out_pdf):
            try:
                os.remove(out_pdf)
            except Exception:
                pass

class BridgeHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def _send_json(self, status_code: int, data: dict):
        resp_bytes = json.dumps(data).encode("utf-8")
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(resp_bytes)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(resp_bytes)

    def do_GET(self):
        if self.path == "/health":
            self._send_json(200, {"status": "ok", "service": "Host Bridge (Cookies & Docx2Pdf)"})
            return

        if self.path == "/sync-cookies":
            logger.info("Received /sync-cookies request from Docker bot...")
            try:
                import importlib
                import auto_extract_cookies
                importlib.reload(auto_extract_cookies)
                result = auto_extract_cookies.extract_cookies_from_browser()
                status_code = 200 if result.get("ok") else 400
                self._send_json(status_code, result)
            except Exception as e:
                logger.error(f"Error during cookie sync: {e}")
                self._send_json(500, {"ok": False, "message": str(e)})
            return

        self._send_json(404, {"error": "Not Found"})

    def do_POST(self):
        if self.path == "/sync-cookies":
            return self.do_GET()

        if self.path == "/convert-docx-to-pdf":
            try:
                content_length = int(self.headers.get("Content-Length", 0))
                post_body = self.rfile.read(content_length)
                req_data = json.loads(post_body.decode("utf-8"))
                
                b64_docx = req_data.get("docx_base64")
                if not b64_docx:
                    self._send_json(400, {"ok": False, "message": "Missing docx_base64"})
                    return
                
                docx_bytes = base64.b64decode(b64_docx)
                pdf_bytes = convert_docx_to_pdf_win32(docx_bytes)
                b64_pdf = base64.b64encode(pdf_bytes).decode("utf-8")
                
                self._send_json(200, {
                    "ok": True,
                    "pdf_base64": b64_pdf,
                    "pdf_size": len(pdf_bytes)
                })
            except Exception as e:
                logger.error(f"Error converting docx to pdf on bridge: {e}")
                self._send_json(500, {"ok": False, "message": str(e)})
            return

        self._send_json(404, {"error": "Not Found"})

    def log_message(self, format, *args):
        logger.info(f"{self.address_string()} - {format % args}")

def run_server():
    server_address = ("0.0.0.0", PORT)
    httpd = ThreadingHTTPServer(server_address, BridgeHandler)
    logger.info(f"Host Bridge Server started on http://0.0.0.0:{PORT}")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        logger.info("Stopping host bridge server...")
        httpd.server_close()

if __name__ == "__main__":
    run_server()

