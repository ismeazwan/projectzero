import json

BOT_TOKEN = "9195418527:AAE86SeYoCnNHcCLD916RemhovjFMZGksYY"
CHAT_ID = "1859219519"

workflow = {
  "name": "Honda HPPM - Fase 1: Live RFQ Lifecycle & Telegram Notifier",
  "nodes": [
    {
      "parameters": {
        "rule": {
          "interval": [
            {
              "field": "minutes",
              "minutesInterval": 1
            }
          ]
        }
      },
      "id": "node-1-schedule",
      "name": "1. Jadwal: Pantau Email Masuk Tiap 1 Menit",
      "type": "n8n-nodes-base.scheduleTrigger",
      "typeVersion": 1.2,
      "position": [180, 260]
    },
    {
      "parameters": {
        "url": "http://scraper-worker:8000/api/email/fetch-latest-rfq",
        "method": "GET",
        "options": {}
      },
      "id": "node-2-fetch-email",
      "name": "2. Baca Email dari jaganetworks25@gmail.com",
      "type": "n8n-nodes-base.httpRequest",
      "typeVersion": 4.2,
      "position": [420, 260]
    },
    {
      "parameters": {
        "jsCode": """// Ekstraksi Nomor RFQ dari Subjek atau Isi Email
// Mampu menangani 1 email maupun banyak email sekaligus (Batch/Loop)
const items = $input.all();
const results = [];

for (const item of items) {
  const email = item.json;
  const fullText = (email.subject || '') + ' ' + (email.body || '');
  const match = fullText.match(/(2[4-9][A-Z]-\\d{6})/);
  const detectedRfqNumber = match ? match[1] : (email.rfqId || '24A-001227');

  results.push({
    json: {
      rfqNumber: detectedRfqNumber,
      emailSubject: email.subject || '-',
      emailSender: email.from || '-',
      emailDate: email.date || '-'
    }
  });
}

return results;"""
      },
      "id": "node-3-parse-rfq-no",
      "name": "3. Ekstraksi Nomor RFQ (Mendukung Multi-Email)",
      "type": "n8n-nodes-base.code",
      "typeVersion": 2,
      "position": [660, 260]
    },
    {
      "parameters": {
        "url": "http://scraper-worker:8000/api/honda/sync-and-cache-rfq",
        "method": "POST",
        "sendBody": True,
        "contentType": "multipart-form-data",
        "bodyParameters": {
          "parameters": [
            {
              "name": "rfqNumber",
              "value": "={{ $json.rfqNumber }}"
            }
          ]
        },
        "options": {}
      },
      "id": "node-4-sync-and-cache-sqlite",
      "name": "4. Sedot Data Portal & Simpan ke SQLite Cache",
      "type": "n8n-nodes-base.httpRequest",
      "typeVersion": 4.2,
      "position": [900, 260]
    },
    {
      "parameters": {
        "url": "=http://scraper-worker:8000/api/honda/rfq-pdf-from-db/{{ $json.rfqId }}",
        "method": "GET",
        "responseFormat": "file",
        "options": {}
      },
      "id": "node-5-stream-pdf-from-db",
      "name": "5. Ambil Dokumen PDF Resmi dari SQLite Cache",
      "type": "n8n-nodes-base.httpRequest",
      "typeVersion": 4.2,
      "position": [1140, 260]
    },
    {
      "parameters": {
        "url": f"https://api.telegram.org/bot{BOT_TOKEN}/sendDocument",
        "method": "POST",
        "sendBody": True,
        "contentType": "multipart-form-data",
        "bodyParameters": {
          "parameters": [
            {
              "name": "chat_id",
              "value": CHAT_ID
            },
            {
              "name": "caption",
              "value": "={{ $('4. Sedot Data Portal & Simpan ke SQLite Cache').first().json.telegramCaption }}"
            },
            {
              "parameterType": "formBinaryData",
              "name": "document",
              "inputDataFieldName": "data"
            }
          ]
        },
        "options": {}
      },
      "id": "node-6-send-telegram",
      "name": "6. Kirim PDF Asli & Rangkuman Data ke Telegram",
      "type": "n8n-nodes-base.httpRequest",
      "typeVersion": 4.2,
      "position": [1380, 260]
    }
  ],
  "connections": {
    "1. Jadwal: Pantau Email Masuk Tiap 1 Menit": {
      "main": [
        [{"node": "2. Baca Email dari jaganetworks25@gmail.com", "type": "main", "index": 0}]
      ]
    },
    "2. Baca Email dari jaganetworks25@gmail.com": {
      "main": [
        [{"node": "3. Ekstraksi Nomor RFQ (Mendukung Multi-Email)", "type": "main", "index": 0}]
      ]
    },
    "3. Ekstraksi Nomor RFQ (Mendukung Multi-Email)": {
      "main": [
        [{"node": "4. Sedot Data Portal & Simpan ke SQLite Cache", "type": "main", "index": 0}]
      ]
    },
    "4. Sedot Data Portal & Simpan ke SQLite Cache": {
      "main": [
        [{"node": "5. Ambil Dokumen PDF Resmi dari SQLite Cache", "type": "main", "index": 0}]
      ]
    },
    "5. Ambil Dokumen PDF Resmi dari SQLite Cache": {
      "main": [
        [{"node": "6. Kirim PDF Asli & Rangkuman Data ke Telegram", "type": "main", "index": 0}]
      ]
    }
  },
  "settings": {
    "executionOrder": "v1"
  }
}

with open("n8n_workflow_honda_rfq_lifecycle.json", "w", encoding="utf-8") as f:
    json.dump(workflow, f, indent=2)

print("SUCCESS: Lean, AI-Free, SQLite-Powered Phase 1 workflow ready!")

