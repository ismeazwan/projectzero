Set WshShell = CreateObject("WScript.Shell")
' Jalankan host_bridge_service.py secara silent di background tanpa jendela console
WshShell.Run "python """ & CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName) & "\host_bridge_service.py""", 0, False
