"""
OEM Automation Suite - Desktop Control Center & Setup Manager
Standalone GUI Application for Credential Setup, Docker Compose Orchestration, and System Diagnostics.
"""

import os
import sys
import subprocess
import threading
import time
import json
import re
import sqlite3
import urllib.request
import webbrowser
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext

# Deteksi direktori dasar proyek (apakah running dari script .py atau file .exe ter-compile)
if getattr(sys, 'frozen', False):
    BASE_DIR = os.path.dirname(os.path.abspath(sys.executable))
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

ENV_PATH = os.path.join(BASE_DIR, ".env")
COMPOSE_PATH = os.path.join(BASE_DIR, "docker-compose.yml")

class OEMManagerApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("OEM Automation Suite - Control Center & Setup Manager (v2.3)")
        self.geometry("1040x780")
        self.minsize(880, 600)

        # Style & Theme
        self.style = ttk.Style(self)
        try:
            self.style.theme_use("clam")
        except Exception:
            pass

        self._init_styles()
        self._create_menu_bar()
        self._create_header()
        self._create_tabs()
        self._create_footer()

        # Load data awal
        self.load_env_to_ui()
        self.refresh_docker_status_async()
        self._refresh_users_table()

    def _init_styles(self):
        self.configure(bg="#F4F6F9")
        self.style.configure(".", background="#F4F6F9", font=("Segoe UI", 9))
        self.style.configure("TNotebook", background="#F4F6F9")
        self.style.configure("TNotebook.Tab", font=("Segoe UI", 10, "bold"), padding=[16, 8])
        self.style.map("TNotebook.Tab", background=[("selected", "#0066CC")], foreground=[("selected", "white")])

        self.style.configure("Header.TLabel", font=("Segoe UI", 16, "bold"), background="#1E293B", foreground="#FFFFFF")
        self.style.configure("SubHeader.TLabel", font=("Segoe UI", 9), background="#1E293B", foreground="#94A3B8")
        
        self.style.configure("TLabelframe", background="#FFFFFF", relief="solid", borderwidth=1)
        self.style.configure("TLabelframe.Label", font=("Segoe UI", 10, "bold"), background="#FFFFFF", foreground="#0066CC")
        
        self.style.configure("Action.TButton", font=("Segoe UI", 9, "bold"), padding=[10, 6])
        self.style.configure("Primary.TButton", font=("Segoe UI", 9, "bold"), padding=[12, 6], background="#0066CC", foreground="white")
        self.style.configure("Success.TButton", font=("Segoe UI", 9, "bold"), padding=[12, 6], background="#16A34A", foreground="white")
        self.style.configure("Danger.TButton", font=("Segoe UI", 9, "bold"), padding=[12, 6], background="#DC2626", foreground="white")

    def _create_menu_bar(self):
        menubar = tk.Menu(self)

        # 1. Menu File
        menu_file = tk.Menu(menubar, tearoff=0)
        menu_file.add_command(label="💾 Simpan Konfigurasi .env", command=self.save_ui_to_env)
        menu_file.add_command(label="🔄 Muat Ulang dari .env", command=self.load_env_to_ui)
        menu_file.add_command(label="📂 Buka Folder Proyek (Explorer)", command=lambda: os.startfile(BASE_DIR))
        menu_file.add_separator()
        menu_file.add_command(label="❌ Keluar", command=self.destroy)
        menubar.add_cascade(label="File", menu=menu_file)

        # 2. Menu Docker
        menu_docker = tk.Menu(menubar, tearoff=0)
        menu_docker.add_command(label="▶️ Jalankan Semua Container (Compose Up)", command=lambda: self._run_command_async("docker compose up -d", "Menjalankan Compose Up..."))
        menu_docker.add_command(label="⏹️ Hentikan Semua Container (Compose Down)", command=lambda: self._run_command_async("docker compose down", "Menghentikan Container..."))
        menu_docker.add_command(label="🔄 Restart Scraper Worker", command=lambda: self._run_command_async("docker restart oem_scraper_worker", "Restarting Worker..."))
        menu_docker.add_command(label="🔨 Rebuild & Start Container", command=lambda: self._run_command_async("docker compose up -d --build", "Rebuilding Containers..."))
        menu_docker.add_separator()
        menu_docker.add_command(label="💾 Backup Workflow n8n ke Proyek", command=self._backup_n8n_workflows)
        menu_docker.add_command(label="📥 Impor / Pulihkan Workflow n8n", command=self._restore_n8n_workflows)
        menu_docker.add_separator()
        menu_docker.add_command(label="🔄 Segarkan Status Live", command=self.refresh_docker_status_async)
        menubar.add_cascade(label="Docker", menu=menu_docker)

        # 3. Menu Akses Web
        menu_web = tk.Menu(menubar, tearoff=0)
        menu_web.add_command(label="🤖 Buka n8n Automation (Port 5678)", command=lambda: webbrowser.open("http://localhost:5678"))
        menu_web.add_command(label="📖 Buka API Documentation Swagger (Port 8000)", command=lambda: webbrowser.open("http://localhost:8000/docs"))
        menubar.add_cascade(label="Akses Web", menu=menu_web)

        # 4. Menu Bantuan
        menu_help = tk.Menu(menubar, tearoff=0)
        menu_help.add_command(label="🚀 Panduan Cepat (Quick Start)", command=lambda: self._show_help_topic("🚀 1. Panduan Cepat (Quick Start)"))
        menu_help.add_command(label="⚙️ Panduan Setting Dasar (.env)", command=lambda: self._show_help_topic("⚙️ 2. Setting Dasar (.env & Akun)"))
        menu_help.add_command(label="🔬 Panduan Setting Lanjutan (Advanced)", command=lambda: self._show_help_topic("🔬 3. Setting Lanjutan (Advanced)"))
        menu_help.add_command(label="🤖 Panduan Bot Telegram & Fitur", command=lambda: self._show_help_topic("🤖 4. Integrasi Bot Telegram & Fitur"))
        menu_help.add_command(label="🔄 Pemecahan Masalah (Troubleshooting & FAQ)", command=lambda: self._show_help_topic("🔄 5. Pemecahan Masalah (Troubleshooting & FAQ)"))
        menu_help.add_command(label="📦 Panduan Migrasi ke Server / Klien", command=lambda: self._show_help_topic("📦 6. Panduan Migrasi ke Server / Klien"))
        menu_help.add_separator()
        menu_help.add_command(label="ℹ️ Tentang OEM Automation Suite", command=self._show_about_dialog)
        menubar.add_cascade(label="Bantuan", menu=menu_help)

        self.config(menu=menubar)

    def _create_header(self):
        header_frame = tk.Frame(self, bg="#1E293B", height=70)
        header_frame.pack(fill=tk.X, side=tk.TOP)
        header_frame.pack_propagate(False)

        title_lbl = ttk.Label(header_frame, text="🏭 OEM AUTOMATION SUITE — CONTROL & SETUP CENTER", style="Header.TLabel")
        title_lbl.pack(anchor="w", padx=20, pady=(12, 2))

        sub_lbl = ttk.Label(header_frame, text="Honda HPPM & LG Singlex Procurement Engine • Unified Deployment & Environment Manager", style="SubHeader.TLabel")
        sub_lbl.pack(anchor="w", padx=20)

    def _create_tabs(self):
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=14, pady=10)

        # Tab 1: Kredensial & .env Setup
        self.tab_env = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(self.tab_env, text="  ⚙️ Konfigurasi .env & Akun  ")
        self._build_tab_env()

        # Tab 2: Docker Compose Orchestrator
        self.tab_docker = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(self.tab_docker, text="  🐳 Kontrol Docker Compose  ")
        self._build_tab_docker()

        # Tab 3: Manajemen Pengguna Telegram & Hak Akses
        self.tab_users = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(self.tab_users, text="  👥 Pengguna Telegram  ")
        self._build_tab_users()

        # Tab 4: Log Monitor & Diagnostik
        self.tab_logs = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(self.tab_logs, text="  📋 Log & Status Diagnostik  ")
        self._build_tab_logs()

        # Tab 5: Panduan & Bantuan Detail (Dasar - Advance)
        self.tab_help = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(self.tab_help, text="  📖 Panduan & Bantuan (Dasar - Advance)  ")
        self._build_tab_help()

    def _build_tab_env(self):
        # Scrollable container for environment settings
        canvas = tk.Canvas(self.tab_env, bg="#F4F6F9", highlightthickness=0)
        scrollbar = ttk.Scrollbar(self.tab_env, orient="vertical", command=canvas.yview)
        scroll_frame = ttk.Frame(canvas)

        scroll_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas_window = canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
        canvas.bind("<Configure>", lambda e: canvas.itemconfig(canvas_window, width=e.width))
        canvas.configure(xscrollcommand=scrollbar.set, yscrollcommand=scrollbar.set)

        def _on_env_mousewheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        canvas.bind("<Enter>", lambda _: canvas.bind_all("<MouseWheel>", _on_env_mousewheel))
        canvas.bind("<Leave>", lambda _: canvas.unbind_all("<MouseWheel>"))

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.entries = {}

        # 1. Honda GP System Portal
        lf_honda = ttk.LabelFrame(scroll_frame, text=" 🚗 1. Portal Honda GP System (https://gpsystem.id) ", padding=12)
        lf_honda.pack(fill=tk.X, pady=(0, 10))
        self._add_field(lf_honda, "HONDA_PORTAL_USER", "User / Email Login:", "apsindo@cbn.net.id", 0)
        self._add_field(lf_honda, "HONDA_PORTAL_PASS", "Password Portal:", "nuclearportalhppm", 1, is_pass=True)
        self._add_field(lf_honda, "HONDA_PORTAL_BASE", "Portal Base URL:", "https://gpsystem.id", 2)

        # 2. LG Singlex Portal
        lf_lg = ttk.LabelFrame(scroll_frame, text=" 🔋 2. Portal LG Singlex Procurement (HLI Green Power) ", padding=12)
        lf_lg.pack(fill=tk.X, pady=10)
        self._add_field(lf_lg, "LG_PORTAL_URL", "Portal Base URL:", "https://procurement-les.singlex.com", 0)
        self._add_field(lf_lg, "LG_USERNAME", "User / Email Login:", "apsindo@cbn.net.id", 1)
        self._add_field(lf_lg, "LG_PASSWORD", "Password Singlex:", "Nuclearsinglex2!", 2, is_pass=True)
        self._add_field(lf_lg, "LG_TENANT_ID", "Tenant ID:", "L2101", 3)
        self._add_field(lf_lg, "LG_SUPPLIER_CODE", "Vendor Code:", "ID00589800", 4)
        self._add_field(lf_lg, "LG_SUPPLIER_PCODE", "Supplier P-Code:", "LGES", 5)

        # 3. Email Monitoring (Gmail vs CBN Hosting)
        lf_email = ttk.LabelFrame(scroll_frame, text=" 📧 3. Email Notifikasi Tender RFQ (IMAP SSL) ", padding=12)
        lf_email.pack(fill=tk.X, pady=10)

        # Preset selector
        preset_frame = ttk.Frame(lf_email)
        preset_frame.grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 8))
        ttk.Label(preset_frame, text="Pilih Preset Email:", font=("Segoe UI", 9, "bold")).pack(side=tk.LEFT, padx=(0, 8))
        
        self.email_preset_var = tk.StringVar(value="Gmail")
        preset_cb = ttk.Combobox(preset_frame, textvariable=self.email_preset_var, values=["Gmail (Testing/Staging)", "Hosting Klien (@cbn.net.id)", "Custom IMAP"], state="readonly", width=30)
        preset_cb.pack(side=tk.LEFT)
        preset_cb.bind("<<ComboboxSelected>>", self._on_email_preset_change)

        self._add_field(lf_email, "EMAIL_IMAP_HOST", "IMAP Host Server:", "imap.gmail.com", 1)
        self._add_field(lf_email, "EMAIL_IMAP_PORT", "IMAP Port (SSL):", "993", 2)
        self._add_field(lf_email, "EMAIL_USER", "Email User / Akun:", "jaganetworks25@gmail.com", 3)
        self._add_field(lf_email, "EMAIL_PASS", "Email Password / App Password:", "dvluwqhrlcnttucd", 4, is_pass=True)

        # 4. Telegram Bot Tokens & Passcodes
        lf_tele = ttk.LabelFrame(scroll_frame, text=" 🤖 4. Bot Telegram & Role-Based Passcode Access Control ", padding=12)
        lf_tele.pack(fill=tk.X, pady=10)
        self._add_field(lf_tele, "TELEGRAM_BOT_TOKEN", "Bot Token (Honda HPPM):", "9195418527:AAE86SeYoCnNHcCLD916RemhovjFMZGksYY", 0)
        self._add_field(lf_tele, "TELEGRAM_LG_BOT_TOKEN", "Bot Token (LG Singlex Dedicated):", "9277394368:AAFjG7Tz7Y1wVbtTgh6H9OSNC53W0m0zpFg", 1)
        self._add_field(lf_tele, "PASSCODE_OWNER", "Passcode Owner (Super Admin):", "OWNER_APSINDO_2026", 2)
        self._add_field(lf_tele, "PASSCODE_SALES", "Passcode Sales (RFQ & Bidding):", "APSINDO_SALES_2026", 3)
        self._add_field(lf_tele, "PASSCODE_LOGISTIK", "Passcode Logistik (PO & Tracking):", "APSINDO_OPS_2026", 4)

        # 5. AI Reasoning Engine (OpenRouter)
        lf_ai = ttk.LabelFrame(scroll_frame, text=" 🧠 5. AI Reasoning Engine (OpenRouter) ", padding=12)
        lf_ai.pack(fill=tk.X, pady=10)
        self._add_field(lf_ai, "OPENROUTER_API_KEY", "OpenRouter AI API Key:", "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", 0, is_pass=True)

        # Action Buttons Bottom
        btn_bar = ttk.Frame(scroll_frame, padding=6)
        btn_bar.pack(fill=tk.X, pady=15)

        ttk.Button(btn_bar, text="💾 Simpan Perubahan ke File .env", style="Success.TButton", command=self.save_ui_to_env).pack(side=tk.LEFT, padx=6)
        ttk.Button(btn_bar, text="🔄 Muat Ulang dari .env", style="Action.TButton", command=self.load_env_to_ui).pack(side=tk.LEFT, padx=6)
        ttk.Button(btn_bar, text="📂 Buka Lokasi File .env", style="Action.TButton", command=lambda: os.startfile(BASE_DIR)).pack(side=tk.LEFT, padx=6)

    def _add_field(self, parent, key: str, label_text: str, default_val: str, row: int, is_pass: bool = False):
        lbl = ttk.Label(parent, text=label_text, width=28, anchor="w", font=("Segoe UI", 9))
        lbl.grid(row=row, column=0, sticky="w", padx=6, pady=4)

        var = tk.StringVar(value=default_val)
        entry = ttk.Entry(parent, textvariable=var, width=54, show="•" if is_pass else "")
        entry.grid(row=row, column=1, sticky="ew", padx=6, pady=4)

        parent.grid_columnconfigure(1, weight=1)
        self.entries[key] = var

    def _on_email_preset_change(self, event=None):
        choice = self.email_preset_var.get()
        if "CBN" in choice:
            self.entries["EMAIL_IMAP_HOST"].set("mail.cbn.net.id")
            self.entries["EMAIL_IMAP_PORT"].set("993")
            self.entries["EMAIL_USER"].set("apsindo@cbn.net.id")
            self.entries["EMAIL_PASS"].set("")
        elif "Gmail" in choice:
            self.entries["EMAIL_IMAP_HOST"].set("imap.gmail.com")
            self.entries["EMAIL_IMAP_PORT"].set("993")
            self.entries["EMAIL_USER"].set("jaganetworks25@gmail.com")
            self.entries["EMAIL_PASS"].set("dvluwqhrlcnttucd")

    def _build_tab_docker(self):
        # Scrollable container untuk Tab Docker Compose agar tidak terpotong pada layar laptop/resolusi kecil
        canvas = tk.Canvas(self.tab_docker, bg="#F4F6F9", highlightthickness=0)
        scrollbar = ttk.Scrollbar(self.tab_docker, orient="vertical", command=canvas.yview)
        scroll_frame = ttk.Frame(canvas)

        scroll_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas_window = canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
        canvas.bind("<Configure>", lambda e: canvas.itemconfig(canvas_window, width=e.width))
        canvas.configure(xscrollcommand=scrollbar.set, yscrollcommand=scrollbar.set)

        def _on_docker_mousewheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        canvas.bind("<Enter>", lambda _: canvas.bind_all("<MouseWheel>", _on_docker_mousewheel))
        canvas.bind("<Leave>", lambda _: canvas.unbind_all("<MouseWheel>"))

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # 1. Top Status Section
        status_frame = ttk.LabelFrame(scroll_frame, text=" 📊 Status Live Service & Kontainer Docker ", padding=12)
        status_frame.pack(fill=tk.X, pady=(0, 8))

        self.lbl_docker_engine = ttk.Label(status_frame, text="🐳 Docker Engine: Memeriksa...", font=("Segoe UI", 10, "bold"))
        self.lbl_docker_engine.grid(row=0, column=0, sticky="w", padx=8, pady=3)

        self.lbl_worker_status = ttk.Label(status_frame, text="⚙️ Scraper Worker (Port 8000): Memeriksa...", font=("Segoe UI", 10))
        self.lbl_worker_status.grid(row=1, column=0, sticky="w", padx=8, pady=3)

        self.lbl_n8n_status = ttk.Label(status_frame, text="🤖 n8n Automation (Port 5678): Memeriksa...", font=("Segoe UI", 10))
        self.lbl_n8n_status.grid(row=2, column=0, sticky="w", padx=8, pady=3)

        self.lbl_bridge_status = ttk.Label(status_frame, text="🌉 Host Bridge (Port 5005): Memeriksa...", font=("Segoe UI", 10))
        self.lbl_bridge_status.grid(row=3, column=0, sticky="w", padx=8, pady=3)

        ttk.Button(status_frame, text="🔄 Segarkan Status", style="Action.TButton", command=self.refresh_docker_status_async).grid(row=0, column=1, rowspan=4, padx=16, sticky="e")
        status_frame.grid_columnconfigure(0, weight=1)

        # 2. Control Action Buttons
        ctrl_frame = ttk.LabelFrame(scroll_frame, text=" 🕹️ Tindakan Orkestrasi Docker Compose ", padding=12)
        ctrl_frame.pack(fill=tk.X, pady=8)

        grid_btn = ttk.Frame(ctrl_frame)
        grid_btn.pack(fill=tk.X)

        ttk.Button(grid_btn, text="▶️ Jalankan Semua Container (Compose Up)", style="Primary.TButton",
                   command=lambda: self._run_command_async("docker compose up -d", "Menjalankan Docker Compose Up...")).grid(row=0, column=0, padx=5, pady=5, sticky="ew")

        ttk.Button(grid_btn, text="🔨 Build Ulang & Jalankan (Up --build)", style="Action.TButton",
                   command=lambda: self._run_command_async("docker compose up -d --build", "Rebuilding containers...")).grid(row=0, column=1, padx=5, pady=5, sticky="ew")

        ttk.Button(grid_btn, text="⏹️ Hentikan Semua Container (Down)", style="Danger.TButton",
                   command=lambda: self._run_command_async("docker compose down", "Menghentikan Docker Compose...")).grid(row=0, column=2, padx=5, pady=5, sticky="ew")

        ttk.Button(grid_btn, text="🔄 Restart Scraper Worker", style="Action.TButton",
                   command=lambda: self._run_command_async("docker restart oem_scraper_worker", "Restarting worker...")).grid(row=1, column=0, padx=5, pady=5, sticky="ew")

        ttk.Button(grid_btn, text="⚡ Jalankan Host Bridge Windows", style="Action.TButton",
                   command=self._start_host_bridge).grid(row=1, column=1, padx=5, pady=5, sticky="ew")

        ttk.Button(grid_btn, text="🛑 Hentikan Host Bridge Windows", style="Action.TButton",
                   command=self._stop_host_bridge).grid(row=1, column=2, padx=5, pady=5, sticky="ew")

        grid_btn.grid_columnconfigure(0, weight=1)
        grid_btn.grid_columnconfigure(1, weight=1)
        grid_btn.grid_columnconfigure(2, weight=1)

        # 3. Web Shortcuts
        web_frame = ttk.LabelFrame(scroll_frame, text=" 🌐 Akses Cepat Antarmuka Web ", padding=12)
        web_frame.pack(fill=tk.X, pady=8)

        grid_web = ttk.Frame(web_frame)
        grid_web.pack(fill=tk.X)

        ttk.Button(grid_web, text="🚀 Buka Portal n8n Workflow (http://localhost:5678)", style="Action.TButton",
                   command=lambda: webbrowser.open("http://localhost:5678")).grid(row=0, column=0, padx=6, pady=4, sticky="ew")

        ttk.Button(grid_web, text="📖 Buka API Documentation Swagger (http://localhost:8000/docs)", style="Action.TButton",
                   command=lambda: webbrowser.open("http://localhost:8000/docs")).grid(row=0, column=1, padx=6, pady=4, sticky="ew")

        grid_web.grid_columnconfigure(0, weight=1)
        grid_web.grid_columnconfigure(1, weight=1)

        # 4. n8n Workflow Backup & Restore Section (Migrasi)
        n8n_backup_frame = ttk.LabelFrame(scroll_frame, text=" 📦 Migrasi & Backup Template Workflow n8n (Honda & LG) ", padding=12)
        n8n_backup_frame.pack(fill=tk.X, pady=(8, 16))

        grid_backup = ttk.Frame(n8n_backup_frame)
        grid_backup.pack(fill=tk.X)

        ttk.Button(grid_backup, text="💾 Ekspor / Backup Workflow ke Proyek", style="Action.TButton",
                   command=self._backup_n8n_workflows).grid(row=0, column=0, padx=5, pady=5, sticky="ew")

        ttk.Button(grid_backup, text="📥 Impor / Pulihkan Workflow ke Container", style="Action.TButton",
                   command=self._restore_n8n_workflows).grid(row=0, column=1, padx=5, pady=5, sticky="ew")

        ttk.Button(grid_backup, text="📂 Buka File Backup (n8n_all_workflows.json)", style="Action.TButton",
                   command=self._open_n8n_backup_file).grid(row=0, column=2, padx=5, pady=5, sticky="ew")

        grid_backup.grid_columnconfigure(0, weight=1)
        grid_backup.grid_columnconfigure(1, weight=1)
        grid_backup.grid_columnconfigure(2, weight=1)

    def _build_tab_users(self):
        # Frame Kontrol Atas (Toolbar)
        ctrl_frame = ttk.LabelFrame(self.tab_users, text=" 🔐 Kelola Akses Telegram Karyawan & Passcode ", padding=10)
        ctrl_frame.pack(fill=tk.X, pady=(0, 10))

        info_lbl = ttk.Label(
            ctrl_frame, 
            text="Karyawan cukup mengetik '/start' di Bot Telegram dan memasukkan Passcode perannya. Akun yang terverifikasi akan langsung muncul di bawah ini secara otomatis.",
            font=("Segoe UI", 9, "italic"),
            foreground="#334155"
        )
        info_lbl.pack(anchor="w", pady=(0, 8))

        btn_bar = ttk.Frame(ctrl_frame)
        btn_bar.pack(fill=tk.X)

        ttk.Button(btn_bar, text="🔄 Segarkan Data Pengguna", style="Action.TButton", command=self._refresh_users_table).pack(side=tk.LEFT, padx=4)
        ttk.Button(btn_bar, text="🚫 Cabut Akses Terpilih (Revoke)", style="Danger.TButton", command=self._revoke_selected_user).pack(side=tk.LEFT, padx=4)
        ttk.Button(btn_bar, text="📢 Kirim Pesan Broadcast", style="Primary.TButton", command=self._open_broadcast_dialog).pack(side=tk.LEFT, padx=4)
        ttk.Button(btn_bar, text="🔑 Lihat Passcode Aktif", style="Action.TButton", command=self._show_active_passcodes).pack(side=tk.RIGHT, padx=4)

        # Frame Tabel (Treeview)
        table_frame = ttk.LabelFrame(self.tab_users, text=" 👥 Daftar Pengguna Terdaftar di Database (WAL SQLite) ", padding=10)
        table_frame.pack(fill=tk.BOTH, expand=True)

        columns = ("chat_id", "role", "name", "username", "registered_at", "status")
        self.users_tree = ttk.Treeview(table_frame, columns=columns, show="headings", selectmode="browse")
        
        self.users_tree.heading("chat_id", text="Telegram Chat ID")
        self.users_tree.heading("role", text="Role / Divisi")
        self.users_tree.heading("name", text="Nama Lengkap")
        self.users_tree.heading("username", text="Username (@)")
        self.users_tree.heading("registered_at", text="Waktu Terdaftar")
        self.users_tree.heading("status", text="Status Akses")

        self.users_tree.column("chat_id", width=130, anchor="center")
        self.users_tree.column("role", width=110, anchor="center")
        self.users_tree.column("name", width=180, anchor="w")
        self.users_tree.column("username", width=130, anchor="w")
        self.users_tree.column("registered_at", width=160, anchor="center")
        self.users_tree.column("status", width=110, anchor="center")

        tree_scroll_y = ttk.Scrollbar(table_frame, orient="vertical", command=self.users_tree.yview)
        self.users_tree.configure(yscrollcommand=tree_scroll_y.set)

        self.users_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        tree_scroll_y.pack(side=tk.RIGHT, fill=tk.Y)

        # Status Ringkasan Bawah
        self.user_stats_lbl = ttk.Label(self.tab_users, text="Memuat data pengguna...", font=("Segoe UI", 9, "bold"), foreground="#0066CC")
        self.user_stats_lbl.pack(anchor="w", pady=(6, 0))

    def _get_db_path(self):
        candidates = [
            os.path.join(BASE_DIR, "portal-scraper-service", "rfq_quotation_cache.db"),
            os.path.join(BASE_DIR, "rfq_quotation_cache.db")
        ]
        for p in candidates:
            if os.path.exists(p):
                return p
        return candidates[0]

    def _refresh_users_table(self):
        if not hasattr(self, "users_tree"):
            return
        for item in self.users_tree.get_children():
            self.users_tree.delete(item)

        db_path = self._get_db_path()
        if not os.path.exists(db_path):
            self.user_stats_lbl.config(text="ℹ️ Database SQLite belum terbentuk atau bot belum pernah diaktifkan.")
            return

        try:
            conn = sqlite3.connect(db_path, timeout=5)
            conn.row_factory = sqlite3.Row
            c = conn.cursor()
            c.execute("""
                SELECT chat_id, role, username, full_name, verified_at, is_active 
                FROM authorized_users 
                ORDER BY verified_at DESC
            """)
            rows = c.fetchall()
            conn.close()

            total = len(rows)
            active_count = 0
            role_counts = {"owner": 0, "sales": 0, "logistik": 0}

            for r in rows:
                is_act = bool(r["is_active"])
                if is_act:
                    active_count += 1
                    role_counts[r["role"]] = role_counts.get(r["role"], 0) + 1
                
                status_text = "🟢 AKTIF" if is_act else "🔴 DICABUT"
                full_name = r["full_name"] or "-"
                username = f"@{r['username']}" if r['username'] else "-"
                role_upper = (r["role"] or "").upper()
                ver_at = str(r["verified_at"]) if r["verified_at"] else "-"

                self.users_tree.insert("", tk.END, values=(
                    r["chat_id"],
                    role_upper,
                    full_name,
                    username,
                    ver_at,
                    status_text
                ))

            self.user_stats_lbl.config(
                text=f"📊 Total Pengguna: {total} | Aktif: {active_count} (👑 Owner: {role_counts['owner']}, 💼 Sales: {role_counts['sales']}, 📦 Logistik: {role_counts['logistik']})"
            )
        except Exception as e:
            self.user_stats_lbl.config(text=f"❌ Gagal memuat database: {e}")

    def _revoke_selected_user(self):
        sel = self.users_tree.selection()
        if not sel:
            messagebox.showwarning("Pilih Pengguna", "Silakan klik salah satu baris pengguna di tabel terlebih dahulu.")
            return

        item = self.users_tree.item(sel[0])
        chat_id = item["values"][0]
        name = item["values"][2]
        role = item["values"][1]

        confirm = messagebox.askyesno(
            "Konfirmasi Cabut Akses",
            f"Apakah Anda yakin ingin mencabut hak akses Telegram untuk:\n\n"
            f"• Nama: {name}\n"
            f"• Chat ID: {chat_id}\n"
            f"• Peran: {role}\n\n"
            f"Pengguna tidak akan bisa lagi mengakses bot kecuali diverifikasi ulang."
        )
        if not confirm:
            return

        db_path = self._get_db_path()
        try:
            conn = sqlite3.connect(db_path, timeout=5)
            c = conn.cursor()
            c.execute("UPDATE authorized_users SET is_active = 0 WHERE chat_id = ?", (chat_id,))
            conn.commit()
            conn.close()

            messagebox.showinfo("Akses Dicabut", f"Hak akses untuk Chat ID {chat_id} ({name}) berhasil dicabut.")
            self._refresh_users_table()
        except Exception as e:
            messagebox.showerror("Error", f"Gagal mencabut akses di database: {e}")

    def _open_broadcast_dialog(self):
        dialog = tk.Toplevel(self)
        dialog.title("📢 Kirim Notifikasi Broadcast ke Karyawan")
        dialog.geometry("520x400")
        dialog.minsize(450, 320)
        dialog.transient(self)
        dialog.grab_set()

        frm = ttk.Frame(dialog, padding=16)
        frm.pack(fill=tk.BOTH, expand=True)

        ttk.Label(frm, text="Target Divisi / Kategori:", font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(0, 4))
        target_var = tk.StringVar(value="all (Semua Karyawan Terdaftar)")
        cb = ttk.Combobox(frm, textvariable=target_var, values=["all (Semua Karyawan Terdaftar)", "sales (Divisi Sales / Penawaran)", "logistik (Divisi Logistik / PO)", "owner (Pimpinan / Owner)"], state="readonly")
        cb.pack(fill=tk.X, pady=(0, 10))

        ttk.Label(frm, text="Pesan Broadcast:", font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(0, 4))
        msg_text = scrolledtext.ScrolledText(frm, height=6, wrap=tk.WORD, font=("Segoe UI", 9))
        msg_text.pack(fill=tk.BOTH, expand=True, pady=(0, 12))
        msg_text.insert(tk.END, "📢 PENGUMUMAN RESMI OEM AUTOMATION:\n\n")

        def send_broadcast():
            raw_target = target_var.get().split()[0]
            msg = msg_text.get("1.0", tk.END).strip()
            if not msg:
                messagebox.showwarning("Pesan Kosong", "Silakan ketik pesan broadcast terlebih dahulu.")
                return

            db_path = self._get_db_path()
            try:
                conn = sqlite3.connect(db_path, timeout=5)
                c = conn.cursor()
                if raw_target == "all":
                    c.execute("SELECT chat_id FROM authorized_users WHERE is_active = 1")
                elif raw_target == "sales":
                    c.execute("SELECT chat_id FROM authorized_users WHERE is_active = 1 AND role IN ('sales', 'owner')")
                elif raw_target == "logistik":
                    c.execute("SELECT chat_id FROM authorized_users WHERE is_active = 1 AND role IN ('logistik', 'owner')")
                else:
                    c.execute("SELECT chat_id FROM authorized_users WHERE is_active = 1 AND role = ?", (raw_target,))
                recipients = [row[0] for row in c.fetchall()]
                conn.close()

                if not recipients:
                    messagebox.showinfo("Tidak Ada Target", f"Tidak ada pengguna aktif untuk kategori '{raw_target}'.")
                    return

                bot_token = self.entries.get("TELEGRAM_BOT_TOKEN", tk.StringVar()).get().strip()
                if not bot_token:
                    messagebox.showerror("Bot Token Kosong", "TELEGRAM_BOT_TOKEN belum diatur di Tab Konfigurasi.")
                    return

                delivered = 0
                for cid in recipients:
                    try:
                        url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
                        req = urllib.request.Request(
                            url,
                            data=json.dumps({"chat_id": cid, "text": msg, "parse_mode": "Markdown"}).encode("utf-8"),
                            headers={"Content-Type": "application/json"}
                        )
                        with urllib.request.urlopen(req, timeout=5) as resp:
                            if resp.status == 200:
                                delivered += 1
                    except Exception:
                        pass

                messagebox.showinfo("Broadcast Selesai", f"Pesan berhasil dikirim ke {delivered} dari {len(recipients)} pengguna aktif.")
                dialog.destroy()
            except Exception as e:
                messagebox.showerror("Gagal", f"Gagal mengirim broadcast: {e}")

        btn_row = ttk.Frame(frm)
        btn_row.pack(fill=tk.X)
        ttk.Button(btn_row, text="Kirim Sekarang", style="Primary.TButton", command=send_broadcast).pack(side=tk.RIGHT, padx=4)
        ttk.Button(btn_row, text="Batal", command=dialog.destroy).pack(side=tk.RIGHT, padx=4)

    def _show_active_passcodes(self):
        owner_pass = self.entries.get("PASSCODE_OWNER", tk.StringVar()).get().strip() or "OWNER_APSINDO_2026"
        sales_pass = self.entries.get("PASSCODE_SALES", tk.StringVar()).get().strip() or "APSINDO_SALES_2026"
        ops_pass = self.entries.get("PASSCODE_LOGISTIK", tk.StringVar()).get().strip() or "APSINDO_OPS_2026"

        text_to_show = (
            f"🔑 DAFTAR PASSCODE AKTIF RESMI:\n\n"
            f"1. Role Owner (Pimpinan / Super Admin):\n"
            f"   Passcode: {owner_pass}\n\n"
            f"2. Role Sales (Penawaran RFQ & Bidding Tender):\n"
            f"   Passcode: {sales_pass}\n\n"
            f"3. Role Logistik (PO Masuk & Unduh PDF):\n"
            f"   Passcode: {ops_pass}\n\n"
            f"Bagikan passcode ini hanya kepada karyawan yang berhak sesuai divisinya."
        )
        messagebox.showinfo("Daftar Passcode Aktif", text_to_show)

    def _build_tab_logs(self):
        log_ctrl = ttk.Frame(self.tab_logs)
        log_ctrl.pack(fill=tk.X, pady=(0, 8))

        ttk.Label(log_ctrl, text="Tampilkan Log:", font=("Segoe UI", 9, "bold")).pack(side=tk.LEFT, padx=(0, 8))
        ttk.Button(log_ctrl, text="Log Scraper Worker", command=lambda: self._run_command_async("docker logs --tail 80 oem_scraper_worker", "Mengambil log worker...")).pack(side=tk.LEFT, padx=4)
        ttk.Button(log_ctrl, text="Log n8n Automation", command=lambda: self._run_command_async("docker logs --tail 80 oem_n8n_automation", "Mengambil log n8n...")).pack(side=tk.LEFT, padx=4)
        ttk.Button(log_ctrl, text="Tes Endpoint Email RFQ", command=self._test_email_endpoint).pack(side=tk.LEFT, padx=4)
        ttk.Button(log_ctrl, text="Bersihkan Layar", command=self._clear_logs).pack(side=tk.RIGHT, padx=4)

        self.log_text = scrolledtext.ScrolledText(self.tab_logs, wrap=tk.WORD, font=("Consolas", 9), bg="#0F172A", fg="#38BDF8")
        self.log_text.pack(fill=tk.BOTH, expand=True)
        self.log_message("OEM Automation Suite Control Center initialized.\nReady to execute commands.")

    def _build_tab_help(self):
        # Container Split: Kiri = Daftar Topik, Kanan = Konten & Toolbar
        paned = ttk.PanedWindow(self.tab_help, orient=tk.HORIZONTAL)
        paned.pack(fill=tk.BOTH, expand=True)

        # Frame Kiri: Navigasi Topik
        left_frame = ttk.Frame(paned, padding=8, width=270)
        paned.add(left_frame, weight=1)

        ttk.Label(left_frame, text="📑 Pilih Topik Bantuan:", font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(0, 6))

        self.help_listbox = tk.Listbox(left_frame, font=("Segoe UI", 9), selectmode=tk.SINGLE, bg="#FFFFFF", fg="#1E293B",
                                       selectbackground="#0066CC", selectforeground="#FFFFFF", relief="solid", borderwidth=1)
        self.help_listbox.pack(fill=tk.BOTH, expand=True, pady=(0, 8))
        self.help_listbox.bind("<<ListboxSelect>>", self._on_help_topic_select)

        # Shortcut buttons di sidebar kiri
        side_shortcuts = ttk.LabelFrame(left_frame, text=" ⚡ Pintasan Navigasi ", padding=6)
        side_shortcuts.pack(fill=tk.X)

        ttk.Button(side_shortcuts, text="⚙️ Tab Konfigurasi .env", command=lambda: self.notebook.select(self.tab_env)).pack(fill=tk.X, pady=2)
        ttk.Button(side_shortcuts, text="🐳 Tab Kontrol Docker", command=lambda: self.notebook.select(self.tab_docker)).pack(fill=tk.X, pady=2)
        ttk.Button(side_shortcuts, text="🌐 Buka n8n (Port 5678)", command=lambda: webbrowser.open("http://localhost:5678")).pack(fill=tk.X, pady=2)
        ttk.Button(side_shortcuts, text="📖 Buka API Docs (8000)", command=lambda: webbrowser.open("http://localhost:8000/docs")).pack(fill=tk.X, pady=2)

        # Frame Kanan: Tampilan Konten & Toolbar Aksi
        right_frame = ttk.Frame(paned, padding=8)
        paned.add(right_frame, weight=4)

        # Top Bar
        top_bar = ttk.Frame(right_frame)
        top_bar.pack(fill=tk.X, pady=(0, 6))

        self.help_title_lbl = ttk.Label(top_bar, text="📖 Panduan Penggunaan & Konfigurasi", font=("Segoe UI", 12, "bold"), foreground="#0066CC")
        self.help_title_lbl.pack(side=tk.LEFT, anchor="w")

        ttk.Button(top_bar, text="📋 Salin Isi Topik", command=self._copy_help_content).pack(side=tk.RIGHT, padx=4)

        # Text Display Area
        self.help_text = scrolledtext.ScrolledText(right_frame, wrap=tk.WORD, font=("Segoe UI", 10), bg="#FFFFFF", fg="#1E293B", padx=14, pady=12, relief="solid", borderwidth=1)
        self.help_text.pack(fill=tk.BOTH, expand=True)

        # Tag Styles for Rich Text formatting
        self.help_text.tag_configure("title", font=("Segoe UI", 12, "bold"), foreground="#0066CC", spacing3=6)
        self.help_text.tag_configure("h1", font=("Segoe UI", 11, "bold"), foreground="#0F172A", spacing1=8, spacing3=4)
        self.help_text.tag_configure("h2", font=("Segoe UI", 10, "bold"), foreground="#1E293B", spacing1=6, spacing3=2)
        self.help_text.tag_configure("code", font=("Consolas", 9), background="#F1F5F9", foreground="#0F172A")
        self.help_text.tag_configure("badge", font=("Segoe UI", 9, "bold"), background="#E0F2FE", foreground="#0284C7")
        self.help_text.tag_configure("warning", font=("Segoe UI", 9, "bold"), foreground="#D97706")
        self.help_text.tag_configure("success", font=("Segoe UI", 9, "bold"), foreground="#16A34A")
        self.help_text.tag_configure("match", background="#FEF08A", foreground="#854D0E")

        # Bottom Search Bar
        search_frame = ttk.Frame(right_frame, padding=(0, 6, 0, 0))
        search_frame.pack(fill=tk.X)

        ttk.Label(search_frame, text="🔍 Cari di Panduan:", font=("Segoe UI", 9, "bold")).pack(side=tk.LEFT, padx=(0, 6))
        self.help_search_var = tk.StringVar()
        search_entry = ttk.Entry(search_frame, textvariable=self.help_search_var, width=32)
        search_entry.pack(side=tk.LEFT, padx=4)
        search_entry.bind("<Return>", lambda e: self._search_help_text())

        ttk.Button(search_frame, text="Cari", command=self._search_help_text).pack(side=tk.LEFT, padx=4)
        ttk.Button(search_frame, text="Reset Sorotan", command=self._clear_search_highlight).pack(side=tk.LEFT, padx=4)
        self.search_status_lbl = ttk.Label(search_frame, text="", font=("Segoe UI", 8), foreground="#64748B")
        self.search_status_lbl.pack(side=tk.LEFT, padx=8)

        # Inisialisasi Database Panduan
        self._init_help_docs()

        # Masukkan daftar topik ke listbox
        for topic in self.help_docs.keys():
            self.help_listbox.insert(tk.END, f"  {topic}")

        # Tampilkan topik pertama secara default
        self.help_listbox.selection_set(0)
        first_topic = list(self.help_docs.keys())[0]
        self._display_help_topic(first_topic)

    def _init_help_docs(self):
        self.help_docs = {
            "🚀 1. Panduan Cepat (Quick Start)": (
                "🚀 PANDUAN CEPAT MEMULAI (QUICK START GUIDE)\n"
                "════════════════════════════════════════════════════════════════════════════════\n\n"
                "Selamat datang di OEM Automation Suite Control Center!\n"
                "Aplikasi ini menyatukan orkestrasi otomasi tender, RFQ, dan procurement untuk:\n"
                "• Honda HPPM (Portal GP System https://gpsystem.id)\n"
                "• LG Singlex (HLI Green Power Procurement https://procurement-les.singlex.com)\n"
                "• n8n Orchestration Workflow & IMAP Email Polling Service\n\n"
                "────────────────────────────────────────────────────────────────────────────────\n"
                "📌 3 LANGKAH MUDAH DEPLOYMENT / SETUP MANDIRI:\n"
                "────────────────────────────────────────────────────────────────────────────────\n\n"
                "Langkah 1: Atur Kredensial di Tab 1 (⚙️ Konfigurasi .env & Akun)\n"
                "1. Isi user dan password portal Honda GP System.\n"
                "2. Isi user (contoh: apsindo@cbn.net.id) dan password LG Singlex.\n"
                "3. Pilih Preset Email:\n"
                "   - 'Gmail' untuk keperluan pengujian / staging.\n"
                "     (Wajib menggunakan 16 digit Google App Password, bukan password biasa).\n"
                "   - 'Hosting Klien (@cbn.net.id)' untuk server produksi CBN (mail.cbn.net.id:993 SSL).\n"
                "4. Masukkan Token Bot Telegram untuk Honda dan LG Singlex serta Chat ID tujuan.\n"
                "5. Klik tombol '💾 Simpan Perubahan ke File .env'.\n\n"
                "Langkah 2: Nyalakan Layanan di Tab 2 (🐳 Kontrol Docker Compose)\n"
                "1. Pastikan aplikasi Docker Desktop di Windows Anda sudah aktif (ikon paus stabil).\n"
                "2. Klik tombol '▶️ Jalankan Semua Container (Compose Up)'.\n"
                "3. Tunggu hingga indikator status berubah menjadi hijau:\n"
                "   - 🟢 Docker Engine  : AKTIF & BERJALAN\n"
                "   - 🟢 Scraper Worker : RUNNING (Uvicorn Port 8000 Ready)\n"
                "   - 🟢 n8n Automation : RUNNING (Web UI Port 5678 Ready)\n\n"
                "Langkah 3: Jalankan Pengujian\n"
                "1. Buka Bot Telegram Honda di HP atau Desktop Anda.\n"
                "2. Ketik nomor RFQ (misal: 26A-009603) untuk melihat status data penawaran.\n"
                "3. Buka Bot Telegram LG Singlex, klik '📦 PO Masuk' atau '🔄 Sinkronkan Cookie'.\n"
                "4. Klik tombol '🚀 Buka Portal n8n Workflow' di Tab Docker untuk melihat alur kerja visual.\n"
            ),
            "⚙️ 2. Setting Dasar (.env & Akun)": (
                "⚙️ RINCIAN LENGKAP SETTING DASAR (.env & KREDENSIAL)\n"
                "════════════════════════════════════════════════════════════════════════════════\n\n"
                "Setiap variabel di file .env memiliki fungsi khusus dalam ekosistem otomasi:\n\n"
                "1. PORTAL HONDA GP SYSTEM (https://gpsystem.id)\n"
                "   • HONDA_PORTAL_USER : Username atau email akun vendor Honda GP System.\n"
                "   • HONDA_PORTAL_PASS : Password login portal Honda GP System.\n"
                "   • HONDA_PORTAL_BASE : URL basis portal (Default: https://gpsystem.id).\n"
                "   Fungsi: Worker mengakses endpoint ini untuk mengecek status RFQ, menarik detail\n"
                "   part number, kuantitas, deskripsi barang, dan men-submit revisi penawaran harga.\n\n"
                "2. PORTAL LG SINGLEX (HLI GREEN POWER)\n"
                "   • LG_PORTAL_URL     : Basis URL pengadaan (https://procurement-les.singlex.com).\n"
                "   • LG_USERNAME       : Email user login resmi (Contoh: apsindo@cbn.net.id).\n"
                "   • LG_PASSWORD       : Password akun Singlex.\n"
                "   • LG_TENANT_ID      : ID Tenant resmi (Default: L2101).\n"
                "   • LG_SUPPLIER_CODE  : Kode Vendor resmi terdaftar di LGES (Default: ID00589800).\n"
                "   • LG_SUPPLIER_PCODE : Kode Purchasing Organization (Default: LGES).\n"
                "   Fungsi: Digunakan untuk autentikasi otomatis, monitoring purchase order (PO),\n"
                "   lelang/tender terbuka, dan unduh dokumen resmi.\n\n"
                "3. EMAIL MONITORING (IMAP SSL 993)\n"
                "   Membaca inbox email secara berkala untuk mendeteksi notifikasi RFQ baru:\n"
                "   • EMAIL_IMAP_HOST : Host server mail (imap.gmail.com atau mail.cbn.net.id).\n"
                "   • EMAIL_IMAP_PORT : Port komunikasi SSL (Standar: 993).\n"
                "   • EMAIL_USER      : Alamat email penerima tender.\n"
                "   • EMAIL_PASS      : Password akun email atau App Password.\n"
                "   ⚠️ Perhatian Gmail: Wajib membuat App Password di myaccount.google.com ->\n"
                "      Keamanan -> Verifikasi 2 Langkah -> Sandi Aplikasi (16 karakter).\n"
                "   ⚠️ Perhatian CBN: Gunakan password akun email hosting korporat Anda.\n\n"
                "4. BOT TELEGRAM NOTIFIKASI & INTERAKTIF\n"
                "   • TELEGRAM_BOT_TOKEN    : Token Bot utama Honda dari @BotFather.\n"
                "   • TELEGRAM_CHAT_ID      : ID User atau ID Group tujuan pengiriman notifikasi tender.\n"
                "   • TELEGRAM_LG_BOT_TOKEN : Token Bot khusus modul LG Singlex.\n\n"
                "5. AI REASONING ENGINE (OPENROUTER)\n"
                "   • OPENROUTER_API_KEY : Kunci API OpenRouter (Claude 3.5 Sonnet / Gemini Flash)\n"
                "     untuk ekstraksi spesifikasi item RFQ, estimasi HS Code, validasi part name, dan drafting penawaran resmi.\n"
            ),
            "🔬 3. Setting Lanjutan (Advanced)": (
                "🔬 PANDUAN SETTING LANJUTAN (ADVANCED ARCHITECTURE & TUNING)\n"
                "════════════════════════════════════════════════════════════════════════════════\n\n"
                "1. PLAYWRIGHT NATIVE DOCKER (AUTO-LOGIN TANPA BRIDGE WINDOWS)\n"
                "   • Pada versi terbaru, container 'oem_scraper_worker' telah dilengkapi browser\n"
                "     Chromium Playwright headless di lingkungan Linux container.\n"
                "   • Ketika tombol '🔄 Sinkronkan Cookie Sekarang' ditekan di bot Telegram LG,\n"
                "     Playwright di dalam Docker akan otomatis melakukan navigasi ke portal Singlex,\n"
                "     mengisi user & password, mengambil cookie auth, dan menyimpannya ke memori.\n"
                "   • Keuntungan: Anda tidak perlu lagi menjalankan program bridge di Windows!\n\n"
                "2. DOCKER LIVE VOLUME MOUNTING\n"
                "   • File 'docker-compose.yml' telah memetakan './portal-scraper-service:/app'.\n"
                "   • Artinya: Setiap perubahan script Python pada folder scraper langsung aktif\n"
                "     di dalam container tanpa memerlukan proses build ulang ('docker build').\n"
                "   • Setelah mengubah file .py, cukup klik '🔄 Restart Scraper Worker' di Tab Docker.\n\n"
                "3. ANTI-DUPLIKASI EMAIL & DUAL-TIER SQLITE CACHE\n"
                "   • Untuk mencegah pengiriman notifikasi berulang (spamming) saat email tender sama\n"
                "     terbaca kembali, sistem menerapkan 2 lapis pengaman:\n"
                "     Lapisan 1: IMAP UID Caching ('seen_uids.json') mencatat ID unik email yang telah diproses.\n"
                "     Lapisan 2: Database SQLite n8n mencatat Hash nomor RFQ dan timestamp pemrosesan.\n"
                "   • Email yang sudah berstatus 'SEEN' (terbaca) tidak akan memicu trigger notifikasi ulang.\n\n"
                "4. STANDAR FORMAT DOKUMEN PENAWARAN (WORD .DOCX & PDF)\n"
                "   • Generator dokumen penawaran harga resmi (Quotation) diatur dalam service worker.\n"
                "   • Format disesuaikan 100% mengikuti standar resmi penawaran:\n"
                "     - Kop Surat Resmi: PT Aneka Petroindo Raya\n"
                "     - Nomor Quotation, Tanggal Terbit, Masa Berlaku, Estimasi Pengiriman (ETA)\n"
                "     - Rincian Tabel: Item, Part Code, Description, Qty, Harga Satuan, Total, HS Code, Netto (KG)\n"
                "     - Ringkasan Finansial: Subtotal, PPN (VAT 11%), Grand Total\n"
                "     - Syarat Pembayaran: END_OF_NEXT_MONTH\n"
            ),
            "🤖 4. Integrasi Bot Telegram & Fitur": (
                "🤖 PANDUAN PENGGUNAAN BOT TELEGRAM (HONDA & LG SINGLEX)\n"
                "════════════════════════════════════════════════════════════════════════════════\n\n"
                "1. BOT HONDA HPPM:\n"
                "   • Cek Status RFQ:\n"
                "     Ketik langsung nomor RFQ di chat (contoh: 26A-009603).\n"
                "     Bot akan menampilkan informasi lengkap nomor RFQ, batas waktu, status penawaran,\n"
                "     serta rincian barang (Part Code, Nama Barang, dan Qty).\n\n"
                "   • Alur Pembuatan & Revisi Penawaran (Quotation):\n"
                "     1. Klik tombol 'Edit / Kirim Penawaran' di bawah pesan detail RFQ.\n"
                "     2. Bot akan memberikan format template teks resmi:\n"
                "        --------------------------------------------------\n"
                "        RFQ: 26A-009603\n"
                "        No Quotation: QT2026-F977\n"
                "        Tanggal: 2026-11-10\n"
                "        Valid Hingga: 2026-12-10\n"
                "        ETA Kirim: 2026-12-07\n"
                "        Mata Uang: IDR\n"
                "        Payment Terms: END_OF_NEXT_MONTH\n"
                "        --- Item 1 [ID: 89056] ---\n"
                "        Part Code: MAC-20592-R00\n"
                "        Part Name: FLOW METER FLOWPET-EG LS4976-4-0A OVAL\n"
                "        Qty: 1\n"
                "        Harga: 16728000\n"
                "        HS Code: 9026.10\n"
                "        Deskripsi HS: LAIN-LAIN\n"
                "        Netto: 5.0000\n"
                "        Satuan Netto: KG\n"
                "        --------------------------------------------------\n"
                "     3. Salin teks di atas, sesuaikan baris 'Harga:', lalu kirim kembali ke bot.\n"
                "     4. Bot akan menampilkan progress status, memvalidasi payload, meng-generate dokumen\n"
                "        Word (.docx) dan PDF resmi, lalu mengirimkan filenya ke chat Anda!\n\n"
                "2. BOT LG SINGLEX:\n"
                "   • 📦 PO Masuk LG SINGLEX   : Menampilkan daftar Purchase Order terbaru dan unduh PDF resmi.\n"
                "   • 📢 Tender LG SINGLEX     : Menampilkan tender/lelang terbuka dari HLI Green Power.\n"
                "   • 🔍 Cari PO / RFQ Singlex : Pencarian spesifik nomor pesanan atau tender.\n"
                "   • 🔄 Sinkronkan Cookie     : Memicu login otomatis Playwright untuk memperbarui sesi portal.\n"
                "   • 📊 Status Koneksi Portal : Memeriksa koneksi HTTP portal, sesi login, dan engine Playwright.\n"
            ),
            "🔄 5. Pemecahan Masalah (Troubleshooting & FAQ)": (
                "🔄 PEMECAHAN MASALAH (TROUBLESHOOTING & FAQ)\n"
                "════════════════════════════════════════════════════════════════════════════════\n\n"
                "❓ TANYA: Docker Engine berstatus 'TIDAK BERJALAN / BELUM NYALA'?\n"
                "💡 SOLUSI:\n"
                "   1. Buka aplikasi 'Docker Desktop' di Start Menu Windows Anda.\n"
                "   2. Tunggu hingga icon ikan paus di taskbar Windows tenang/hijau.\n"
                "   3. Buka kembali aplikasi ini dan klik '🔄 Segarkan Status' di Tab Docker.\n\n"
                "❓ TANYA: Muncul pesan 'Tidak dapat menjangkau host bridge Windows: None'?\n"
                "💡 SOLUSI:\n"
                "   Sistem terbaru sudah menggunakan Playwright Native di dalam Docker:\n"
                "   1. Buka Tab Docker Compose di aplikasi ini, klik '🔄 Restart Scraper Worker'.\n"
                "   2. Buka bot Telegram LG, klik kembali tombol '🔄 Sinkronkan Cookie Sekarang'.\n"
                "   3. Playwright akan otomatis login di dalam Docker tanpa memerlukan bridge luar.\n\n"
                "❓ TANYA: Email tender tidak terbaca atau muncul error autentikasi IMAP?\n"
                "💡 SOLUSI:\n"
                "   1. Buka Tab 3 ('Log & Status Diagnostik'), klik tombol 'Tes Endpoint Email RFQ'.\n"
                "   2. Jika menggunakan Gmail: Anda WAJIB membuat 'App Password' 16 digit di akun Google\n"
                "      (My Account -> Security -> 2-Step Verification -> App Passwords).\n"
                "   3. Jika menggunakan CBN Mail (@cbn.net.id): Gunakan host 'mail.cbn.net.id', port 993 SSL,\n"
                "      dan pastikan akun email CBN Anda aktif.\n\n"
                "❓ TANYA: Bot Telegram tidak merespon saat dikirimi pesan?\n"
                "💡 SOLUSI:\n"
                "   1. Periksa nilai TELEGRAM_BOT_TOKEN di Tab 1. Pastikan tidak ada spasi di awal/akhir.\n"
                "   2. Buka Tab 3 ('Log & Status Diagnostik') -> klik 'Log Scraper Worker' untuk melihat\n"
                "      apakah ada error traceback Python.\n"
                "   3. Lakukan restart worker dengan tombol '🔄 Restart Scraper Worker'.\n\n"
                "❓ TANYA: Di mana n8n menyimpan data konfigurasi workflow?\n"
                "💡 SOLUSI:\n"
                "   Data n8n tersimpan aman di Docker volume bernama 'n8n_data'. Data workflow, history\n"
                "   eksekusi, dan credentials tidak akan hilang meskipun container dimatikan (down).\n"
            ),
            "📦 6. Panduan Migrasi ke Server / Klien": (
                "📦 PANDUAN LENGKAP MIGRASI KE SERVER / KOMPUTER KLIEN\n"
                "════════════════════════════════════════════════════════════════════════════════\n\n"
                "Aplikasi OEM_Manager.exe dirancang khusus agar serah terima / migrasi ke komputer\n"
                "klien atau server produksi dapat dilakukan dengan sangat mudah (1-Click Setup):\n\n"
                "1. SPESIFIKASI MINIMAL KOMPUTER KLIEN:\n"
                "   • Sistem Operasi: Windows 10 (64-bit), Windows 11, atau Windows Server 2019/2022.\n"
                "   • RAM: Minimal 4 GB (Disarankan 8 GB).\n"
                "   • Perangkat Lunak Wajib: Docker Desktop for Windows (dengan backend WSL 2).\n"
                "   • TIDAK PERLU menginstal: Python, pip, Node.js, Git, atau compiler apapun di klien!\n\n"
                "2. TAHAPAN PROSES MIGRASI:\n"
                "   Langkah A: Salin Folder Proyek\n"
                "   • Salin seluruh folder 'co129' (atau rename menjadi 'OEM_Automation') ke drive target\n"
                "     di komputer klien (contoh: C:\\OEM_Automation).\n\n"
                "   Langkah B: Buka OEM_Manager.exe\n"
                "   • Cukup dobel-klik file 'OEM_Manager.exe'. Tidak perlu install apapun.\n\n"
                "   Langkah C: Sesuaikan Kredensial Klien\n"
                "   • Pada Tab '⚙️ Konfigurasi .env & Akun':\n"
                "     - Masukkan email produksi klien (contoh: apsindo@cbn.net.id) dan password.\n"
                "     - Masukkan token Bot Telegram resmi klien serta Passcode per peran (Owner, Sales, Logistik).\n"
                "     - Klik '💾 Simpan Perubahan ke File .env'.\n\n"
                "   Langkah D: Jalankan Sistem\n"
                "   • Pindah ke Tab '🐳 Kontrol Docker Compose'.\n"
                "   • Klik tombol '▶️ Jalankan Semua Container (Compose Up)'.\n"
                "   • Sistem akan otomatis menjalankan service n8n, worker scraper, dan bot Telegram.\n\n"
                "3. AUTO-START SAAT WINDOWS BOOTING (OPSIONAL):\n"
                "   • Anda dapat membuat Shortcut dari 'OEM_Manager.exe' atau 'start_all.bat' ke folder\n"
                "     Startup Windows (tekan Win + R -> ketik 'shell:startup') agar sistem otomatis\n"
                "     berjalan saat komputer klien dinyalakan.\n"
            ),
            "🔐 7. Hak Akses Passcode & Pencegahan Konflik": (
                "🔐 SISTEM PASSCODE MULTI-ROLE & PENCEGAHAN KONFLIK REVISI\n"
                "════════════════════════════════════════════════════════════════════════════════\n\n"
                "1. CARA KERJA SISTEM PASSCODE TELEGRAM:\n"
                "   • Anda TIDAK PERLU lagi mencari atau mendaftarkan Chat ID karyawan secara manual!\n"
                "   • Setiap karyawan cukup membuka bot Telegram (Honda atau LG) dan mengetik /start.\n"
                "   • Bot akan meminta: 'Ketik Passcode untuk Verifikasi Akun'.\n"
                "   • Karyawan memasukkan passcode sesuai divisi/peran mereka:\n"
                "     - Owner   : PASSCODE_OWNER (Akses Penuh, Hak Veto, Kelola Pengguna)\n"
                "     - Sales   : PASSCODE_SALES (Pembuatan Penawaran RFQ, Bidding Tender LG)\n"
                "     - Logistik: PASSCODE_LOGISTIK (Lihat & Unduh PO Masuk, Tracking Pengiriman)\n"
                "   • Sekali passcode benar dimasukkan, ID Telegram akun tersebut langsung aktif selamanya\n"
                "     dan tersinkronisasi di kedua bot (Honda & LG).\n\n"
                "2. PENCEGAHAN SALING TIMPA (CONCURRENCY & EDIT LOCK):\n"
                "   • State Pembuatan Penawaran terisolasi per user (rfq_number + chat_id).\n"
                "   • Saat seorang Sales sedang mengedit harga suatu RFQ, sistem mengunci RFQ tersebut\n"
                "     selama 10 menit (Temporary Edit-Lock).\n"
                "   • Jika Sales lain mencoba mengedit RFQ yang sama, bot akan memperingatkan:\n"
                "     '⚠️ RFQ sedang diproses oleh rekan Sales lain.'\n"
                "   • Jika suatu penawaran sudah berhasil dikirim ke portal, pengiriman revisi kedua\n"
                "     wajib mendapat konfirmasi agar harga tidak tertimpa tanpa sengaja.\n\n"
                "3. MANAJEMEN PENGGUNA & PENCABUTAN AKSES (REVOKE):\n"
                "   • Admin / Owner dapat mencabut hak akses karyawan yang mutasi/keluar langsung melalui:\n"
                "     - Tab '👥 Pengguna Telegram' di Control Center ini (Klik tombol 'Cabut Akses').\n"
                "     - Perintah Bot Telegram: /revoke <chat_id>.\n"
            )
        }

    def _on_help_topic_select(self, event=None):
        sel = self.help_listbox.curselection()
        if not sel:
            return
        selected_key = list(self.help_docs.keys())[sel[0]]
        self._display_help_topic(selected_key)

    def _display_help_topic(self, topic_key: str):
        content = self.help_docs.get(topic_key, "")
        self.help_title_lbl.config(text=f"📖 {topic_key}")
        
        self.help_text.config(state=tk.NORMAL)
        self.help_text.delete("1.0", tk.END)
        self.help_text.insert(tk.END, content)
        self.help_text.config(state=tk.DISABLED)
        self._clear_search_highlight()

    def _show_help_topic(self, topic_name: str):
        self.notebook.select(self.tab_help)
        keys = list(self.help_docs.keys())
        for idx, k in enumerate(keys):
            if topic_name.lower() in k.lower():
                self.help_listbox.selection_clear(0, tk.END)
                self.help_listbox.selection_set(idx)
                self.help_listbox.see(idx)
                self._display_help_topic(k)
                break

    def _copy_help_content(self):
        sel = self.help_listbox.curselection()
        if not sel:
            return
        selected_key = list(self.help_docs.keys())[sel[0]]
        content = self.help_docs.get(selected_key, "")
        self.clipboard_clear()
        self.clipboard_append(content)
        messagebox.showinfo("Tersalin", f"Isi panduan '{selected_key}' berhasil disalin ke clipboard.")

    def _search_help_text(self):
        query = self.help_search_var.get().strip()
        self._clear_search_highlight()
        if not query:
            return

        self.help_text.config(state=tk.NORMAL)
        start_pos = "1.0"
        match_count = 0
        while True:
            start_pos = self.help_text.search(query, start_pos, stopindex=tk.END, nocase=True)
            if not start_pos:
                break
            end_pos = f"{start_pos}+{len(query)}c"
            self.help_text.tag_add("match", start_pos, end_pos)
            if match_count == 0:
                self.help_text.see(start_pos)
            match_count += 1
            start_pos = end_pos

        self.help_text.config(state=tk.DISABLED)
        self.search_status_lbl.config(text=f"Ditemukan {match_count} hasil untuk '{query}'")

    def _clear_search_highlight(self):
        self.help_text.config(state=tk.NORMAL)
        self.help_text.tag_remove("match", "1.0", tk.END)
        self.help_text.config(state=tk.DISABLED)
        self.search_status_lbl.config(text="")

    def _show_about_dialog(self):
        messagebox.showinfo(
            "Tentang OEM Automation Suite",
            "🏭 OEM Automation Suite — Control & Setup Center\n"
            "Versi: 2.2 (Honda HPPM & LG Singlex Dedicated Edition)\n\n"
            "Modul yang Didukung:\n"
            "• Honda HPPM (GP System Portal RFQ, Dokumen Word & PDF)\n"
            "• LG Singlex (HLI Green Power Procurement, PO & Tender)\n"
            "• n8n Automation Engine & IMAP Email Watcher (Gmail & CBN)\n"
            "• Playwright Native Headless Browser Scraper\n\n"
            "Didesain untuk kemudahan migrasi dan setup 1-klik di komputer klien."
        )

    def _create_footer(self):
        footer = tk.Frame(self, bg="#E2E8F0", height=28)
        footer.pack(fill=tk.X, side=tk.BOTTOM)
        footer.pack_propagate(False)

        self.status_var = tk.StringVar(value=f"Lokasi Proyek: {BASE_DIR}")
        ttk.Label(footer, textvariable=self.status_var, font=("Segoe UI", 8), background="#E2E8F0").pack(side=tk.LEFT, padx=12, pady=4)

    def log_message(self, text: str):
        self.log_text.insert(tk.END, f"\n[{time.strftime('%H:%M:%S')}] {text}\n")
        self.log_text.see(tk.END)

    def _clear_logs(self):
        self.log_text.delete("1.0", tk.END)

    def load_env_to_ui(self):
        if not os.path.exists(ENV_PATH):
            self.log_message(f"File .env belum ditemukan di {ENV_PATH}. Nilai default digunakan.")
            return

        try:
            with open(ENV_PATH, "r", encoding="utf-8") as f:
                lines = f.readlines()

            loaded_count = 0
            for line in lines:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" in line:
                    k, v = line.split("=", 1)
                    k = k.strip()
                    v = v.strip().strip('"').strip("'")
                    if k in self.entries:
                        self.entries[k].set(v)
                        loaded_count += 1

            self.log_message(f"Berhasil memuat {loaded_count} variabel dari {ENV_PATH}")
            messagebox.showinfo("Sukses", f"Berhasil memuat konfigurasi dari file:\n{ENV_PATH}")
        except Exception as e:
            self.log_message(f"Error membaca .env: {e}")
            messagebox.showerror("Error", f"Gagal membaca file .env:\n{e}")

    def save_ui_to_env(self):
        # Update / buat file .env
        existing_lines = []
        if os.path.exists(ENV_PATH):
            with open(ENV_PATH, "r", encoding="utf-8") as f:
                existing_lines = f.readlines()

        saved_keys = set()
        new_lines = []

        # Tulis ulang dengan mengganti nilai yang ada atau mempertahankan komentar
        for line in existing_lines:
            match = re.match(r"^([A-Za-z0-9_]+)\s*=", line.strip())
            if match:
                k = match.group(1)
                if k in self.entries:
                    new_val = self.entries[k].get().strip()
                    new_lines.append(f"{k}={new_val}\n")
                    saved_keys.add(k)
                else:
                    new_lines.append(line)
            else:
                new_lines.append(line)

        # Tambahkan key yang belum ada
        for k, var in self.entries.items():
            if k not in saved_keys:
                new_lines.append(f"{k}={var.get().strip()}\n")

        try:
            with open(ENV_PATH, "w", encoding="utf-8") as f:
                f.writelines(new_lines)

            self.log_message(f"File .env berhasil disimpan ke {ENV_PATH}")
            messagebox.showinfo("Sukses", f"Konfigurasi kredensial berhasil disimpan ke file:\n{ENV_PATH}\n\nSilakan restart container agar perubahan langsung aktif.")
        except Exception as e:
            self.log_message(f"Gagal menulis file .env: {e}")
            messagebox.showerror("Error", f"Gagal menyimpan file .env:\n{e}")

    def refresh_docker_status_async(self):
        threading.Thread(target=self._check_docker_status_worker, daemon=True).start()

    def _check_docker_status_worker(self):
        # 1. Cek Docker Engine
        try:
            res = subprocess.run(["docker", "info"], capture_output=True, text=True, timeout=5)
            docker_ok = (res.returncode == 0)
        except Exception:
            docker_ok = False

        self.lbl_docker_engine.config(
            text="🐳 Docker Engine: 🟢 AKTIF & BERJALAN" if docker_ok else "🐳 Docker Engine: ❌ TIDAK BERJALAN / DOCKER BELUM NYALA",
            foreground="#16A34A" if docker_ok else "#DC2626"
        )

        if not docker_ok:
            self.lbl_worker_status.config(text="⚙️ Scraper Worker: ⏹️ Docker Mati", foreground="#64748B")
            self.lbl_n8n_status.config(text="🤖 n8n Automation: ⏹️ Docker Mati", foreground="#64748B")
            return

        # 2. Cek Container Scraper Worker (Port 8000)
        try:
            with urllib.request.urlopen("http://localhost:8000/docs", timeout=2) as r:
                worker_ok = (r.status == 200)
        except Exception:
            worker_ok = False

        self.lbl_worker_status.config(
            text="⚙️ Scraper Worker (Port 8000): 🟢 RUNNING (Uvicorn Ready)" if worker_ok else "⚙️ Scraper Worker (Port 8000): ⏳ OFFLINE / RESTARTING",
            foreground="#16A34A" if worker_ok else "#D97706"
        )

        # 3. Cek n8n (Port 5678)
        try:
            with urllib.request.urlopen("http://localhost:5678/", timeout=2) as r:
                n8n_ok = (r.status in [200, 302])
        except Exception:
            n8n_ok = False

        self.lbl_n8n_status.config(
            text="🤖 n8n Automation (Port 5678): 🟢 RUNNING (Web UI Ready)" if n8n_ok else "🤖 n8n Automation (Port 5678): ⏳ OFFLINE / STARTING",
            foreground="#16A34A" if n8n_ok else "#D97706"
        )

        # 4. Cek Host Bridge (Port 5005)
        try:
            with urllib.request.urlopen("http://localhost:5005/health", timeout=2) as r:
                bridge_ok = (r.status == 200)
        except Exception:
            bridge_ok = False

        self.lbl_bridge_status.config(
            text="🌉 Host Bridge (Port 5005): 🟢 AKTIF (Cookie Sync Ready)" if bridge_ok else "🌉 Host Bridge (Port 5005): ⚪ TIDAK AKTIF (Opsional)",
            foreground="#16A34A" if bridge_ok else "#64748B"
        )

    def _run_command_async(self, cmd: str, desc: str = ""):
        self.log_message(f"Menjalankan perintah: {cmd} ({desc})")
        threading.Thread(target=self._exec_cmd, args=(cmd,), daemon=True).start()

    def _exec_cmd(self, cmd: str):
        try:
            p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, cwd=BASE_DIR)
            for line in p.stdout:
                self.log_text.insert(tk.END, line)
                self.log_text.see(tk.END)
            p.wait()
            self.log_message(f"Perintah selesai dengan exit code: {p.returncode}")
            self.refresh_docker_status_async()
        except Exception as e:
            self.log_message(f"Error menjalankan perintah: {e}")

    def _backup_n8n_workflows(self):
        cmd = 'docker exec oem_n8n_automation n8n export:workflow --all --output=/tmp/workflows.json && docker cp oem_n8n_automation:/tmp/workflows.json ./n8n_all_workflows.json'
        self._run_command_async(cmd, "Mengekspor seluruh workflow n8n ke n8n_all_workflows.json...")

    def _restore_n8n_workflows(self):
        json_file = os.path.join(BASE_DIR, "n8n_all_workflows.json")
        if not os.path.exists(json_file):
            messagebox.showerror("Error", f"File backup {json_file} tidak ditemukan di direktori proyek!")
            return
        cmd = 'docker cp ./n8n_all_workflows.json oem_n8n_automation:/tmp/workflows.json && docker exec oem_n8n_automation n8n import:workflow --input=/tmp/workflows.json'
        self._run_command_async(cmd, "Mengimpor template workflow n8n ke container...")

    def _open_n8n_backup_file(self):
        json_file = os.path.join(BASE_DIR, "n8n_all_workflows.json")
        if os.path.exists(json_file):
            os.startfile(json_file)
        else:
            messagebox.showwarning("Perhatian", "File n8n_all_workflows.json belum dibuat. Klik tombol 'Ekspor / Backup' terlebih dahulu.")

    def _start_host_bridge(self):
        bridge_script = os.path.join(BASE_DIR, "host_bridge_service.py")
        if not os.path.exists(bridge_script):
            messagebox.showerror("Error", f"File host_bridge_service.py tidak ditemukan di:\n{bridge_script}")
            return
        self.log_message("Menjalankan host_bridge_service.py di background...")
        subprocess.Popen(["python", bridge_script], cwd=BASE_DIR, creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
        time.sleep(1.5)
        self.refresh_docker_status_async()
        messagebox.showinfo("Host Bridge", "Host Bridge Service telah dijalankan di background port 5005.")

    def _stop_host_bridge(self):
        self.log_message("Menghentikan host_bridge_service di port 5005...")
        subprocess.run("taskkill /F /IM python.exe /FI \"WINDOWTITLE eq host_bridge*\" 2>nul", shell=True)
        # Atau kill berdasarkan port 5005
        subprocess.run("powershell -Command \"Get-NetTCPConnection -LocalPort 5005 -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force }\"", shell=True)
        time.sleep(1)
        self.refresh_docker_status_async()
        messagebox.showinfo("Host Bridge", "Host Bridge Service telah dihentikan.")

    def _test_email_endpoint(self):
        self.log_message("Menguji endpoint: http://localhost:8000/api/email/fetch-latest-rfq ...")
        def _call():
            try:
                req = urllib.request.Request("http://localhost:8000/api/email/fetch-latest-rfq")
                with urllib.request.urlopen(req, timeout=12) as response:
                    res_body = response.read().decode("utf-8")
                    self.log_message(f"Response: {res_body}")
            except Exception as e:
                self.log_message(f"Test failed: {e}")
        threading.Thread(target=_call, daemon=True).start()

if __name__ == "__main__":
    app = OEMManagerApp()
    app.mainloop()
