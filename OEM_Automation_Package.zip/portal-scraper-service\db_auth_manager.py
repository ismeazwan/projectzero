"""
Database & Authentication Manager for OEM Automation Suite
Handles:
1. Role-Based Passcode Verification (Owner, Sales, Logistik)
2. Authorized Chat ID Persistence & Multi-User Broadcast
3. RFQ Edit Locks (TTL Concurrency Control)
4. Quotation Submission History & Audit Trail
"""

import os
import sqlite3
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List

logger = logging.getLogger("db_auth_manager")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "rfq_quotation_cache.db")

def get_db_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, timeout=15.0)
    conn.row_factory = sqlite3.Row
    # Gunakan mode DELETE kompatibel dengan bind mount Docker Windows VFS
    conn.execute("PRAGMA journal_mode = DELETE;")
    conn.execute("PRAGMA busy_timeout = 15000;")
    return conn

def init_auth_db():
    """Inisialisasi tabel autentikasi, lock, dan audit trail."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        
        # 1. Tabel Pengguna Terverifikasi
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS authorized_users (
                chat_id INTEGER PRIMARY KEY,
                username TEXT,
                full_name TEXT,
                role TEXT NOT NULL,
                is_active INTEGER DEFAULT 1,
                verified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        """)

        # 2. Tabel Kunci Pengeditan RFQ Sementara (Concurrency Lock)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS rfq_edit_locks (
                rfq_number TEXT PRIMARY KEY,
                locked_by_chat_id INTEGER NOT NULL,
                locked_by_name TEXT NOT NULL,
                locked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expires_at TIMESTAMP NOT NULL
            );
        """)

        # 3. Tabel Histori Penawaran (Quotation Audit Trail)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS rfq_quotations_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                rfq_number TEXT NOT NULL,
                quotation_no TEXT,
                submitted_by_chat_id INTEGER NOT NULL,
                submitted_by_name TEXT NOT NULL,
                total_amount REAL DEFAULT 0,
                payload_json TEXT,
                status TEXT DEFAULT 'SUBMITTED',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        """)
        conn.commit()
    logger.info("Tabel Auth, Lock, dan History SQLite siap.")

# Jalankan inisialisasi tabel saat modul di-import
init_auth_db()

# ==============================================================================
# 1. MANAJEMEN AUTENTIKASI & ROLE BERBASIS PASSCODE
# ==============================================================================

def get_passcodes() -> Dict[str, str]:
    """Mengambil kode passcode dari environment variable."""
    return {
        "owner": os.getenv("PASSCODE_OWNER", "OWNER_APSINDO_2026").strip(),
        "sales": os.getenv("PASSCODE_SALES", "APSINDO_SALES_2026").strip(),
        "logistik": os.getenv("PASSCODE_LOGISTIK", "APSINDO_OPS_2026").strip()
    }

def verify_and_register_user(chat_id: int, username: str, full_name: str, input_passcode: str) -> Dict[str, Any]:
    """
    Memverifikasi passcode yang dimasukkan pengguna.
    Jika valid, mendaftarkan akun ke role yang sesuai.
    """
    clean_code = (input_passcode or "").strip()
    passcodes = get_passcodes()
    
    assigned_role = None
    if clean_code and clean_code == passcodes["owner"]:
        assigned_role = "owner"
    elif clean_code and clean_code == passcodes["sales"]:
        assigned_role = "sales"
    elif clean_code and clean_code == passcodes["logistik"]:
        assigned_role = "logistik"
        
    if not assigned_role:
        return {
            "ok": False,
            "message": "❌ Passcode tidak valid! Pastikan Anda memasukkan passcode yang sesuai dengan divisi Anda."
        }

    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO authorized_users (chat_id, username, full_name, role, is_active, verified_at, last_active)
            VALUES (?, ?, ?, ?, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            ON CONFLICT(chat_id) DO UPDATE SET
                username = excluded.username,
                full_name = excluded.full_name,
                role = excluded.role,
                is_active = 1,
                last_active = CURRENT_TIMESTAMP;
        """, (chat_id, username or "", full_name or "", assigned_role))
        conn.commit()

    role_titles = {
        "owner": "👑 Owner / Manajemen / Super-Admin",
        "sales": "💼 Tim Sales, Pricing & Tender",
        "logistik": "📦 Tim Logistik & Purchase Order (Read-Only)"
    }

    return {
        "ok": True,
        "role": assigned_role,
        "role_title": role_titles.get(assigned_role, assigned_role),
        "message": f"🎉 *Verifikasi Berhasil!*\nAkun Anda telah terdaftar sebagai *{role_titles.get(assigned_role)}*."
    }

def get_user_info(chat_id: int) -> Optional[Dict[str, Any]]:
    """Mendapatkan data pengguna jika aktif."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM authorized_users WHERE chat_id = ? AND is_active = 1", (chat_id,))
        row = cursor.fetchone()
        if row:
            # Perbarui last_active
            cursor.execute("UPDATE authorized_users SET last_active = CURRENT_TIMESTAMP WHERE chat_id = ?", (chat_id,))
            conn.commit()
            return dict(row)
    return None

def is_user_authorized(chat_id: int) -> bool:
    """Cek apakah chat_id sudah terdaftar dan aktif."""
    return get_user_info(chat_id) is not None

def get_user_role(chat_id: int) -> Optional[str]:
    """Cek role pengguna ('owner', 'sales', 'logistik', atau None)."""
    info = get_user_info(chat_id)
    return info.get("role") if info else None

def list_all_users() -> List[Dict[str, Any]]:
    """Mendapatkan daftar seluruh pengguna terdaftar (untuk UI Admin / Manager)."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM authorized_users ORDER BY verified_at DESC")
        return [dict(row) for row in cursor.fetchall()]

def revoke_user_access(chat_id: int) -> bool:
    """Mencabut akses pengguna."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE authorized_users SET is_active = 0 WHERE chat_id = ?", (chat_id,))
        conn.commit()
        return cursor.rowcount > 0

def get_broadcast_subscribers(category: str = "all") -> List[int]:
    """
    Mendapatkan daftar chat_id untuk penyiaran (broadcast) notifikasi:
    - category='rfq'      -> role 'owner' dan 'sales'
    - category='po'       -> role 'owner', 'sales', dan 'logistik'
    - category='admin'    -> role 'owner'
    - category='all'      -> semua role aktif
    """
    with get_db_connection() as conn:
        cursor = conn.cursor()
        if category == "rfq":
            cursor.execute("SELECT chat_id FROM authorized_users WHERE is_active = 1 AND role IN ('owner', 'sales')")
        elif category == "po":
            cursor.execute("SELECT chat_id FROM authorized_users WHERE is_active = 1 AND role IN ('owner', 'sales', 'logistik')")
        elif category == "admin":
            cursor.execute("SELECT chat_id FROM authorized_users WHERE is_active = 1 AND role = 'owner'")
        else:
            cursor.execute("SELECT chat_id FROM authorized_users WHERE is_active = 1")
            
        rows = cursor.fetchall()
        return [row["chat_id"] for row in rows]

# ==============================================================================
# 2. CONCURRENCY CONTROL: RFQ EDIT LOCK (ANTI-SALING NIMPA)
# ==============================================================================

def acquire_rfq_lock(rfq_number: str, chat_id: int, user_name: str, ttl_minutes: int = 10) -> Dict[str, Any]:
    """
    Memasang kunci sementara pada RFQ tertentu saat karyawan mulai mengedit penawaran.
    Jika sedang dikunci oleh orang lain dan belum kedaluwarsa, permintaan ditolak.
    """
    rfq_key = rfq_number.strip().upper()
    now = datetime.now()
    new_expires = now + timedelta(minutes=ttl_minutes)

    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM rfq_edit_locks WHERE rfq_number = ?", (rfq_key,))
        existing = cursor.fetchone()

        if existing:
            exp_time = datetime.fromisoformat(existing["expires_at"])
            # Jika kunci milik orang lain dan belum expired
            if existing["locked_by_chat_id"] != chat_id and exp_time > now:
                remaining_sec = int((exp_time - now).total_seconds())
                remaining_min = max(1, remaining_sec // 60)
                return {
                    "ok": False,
                    "is_locked": True,
                    "locked_by_name": existing["locked_by_name"],
                    "remaining_minutes": remaining_min,
                    "message": (
                        f"⏳ *RFQ {rfq_key} sedang diproses oleh {existing['locked_by_name']}!*\n\n"
                        f"Kunci pengeditan sedang aktif agar harga tidak bertabrakan.\n"
                        f"• Sisa waktu kunci: *{remaining_min} menit*.\n"
                        f"Silakan koordinasi dengan rekan Anda atau tunggu beberapa menit."
                    )
                }

        # Pasang atau perpanjang kunci
        cursor.execute("""
            INSERT INTO rfq_edit_locks (rfq_number, locked_by_chat_id, locked_by_name, locked_at, expires_at)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(rfq_number) DO UPDATE SET
                locked_by_chat_id = excluded.locked_by_chat_id,
                locked_by_name = excluded.locked_by_name,
                locked_at = excluded.locked_at,
                expires_at = excluded.expires_at;
        """, (rfq_key, chat_id, user_name, now.isoformat(), new_expires.isoformat()))
        conn.commit()

    return {
        "ok": True,
        "is_locked": False,
        "ttl_minutes": ttl_minutes,
        "message": f"Kunci RFQ {rfq_key} berhasil diamankan untuk {user_name} ({ttl_minutes} menit)."
    }

def release_rfq_lock(rfq_number: str, chat_id: Optional[int] = None):
    """Melepaskan kunci pengeditan setelah penawaran disubmit atau dibatalkan."""
    rfq_key = rfq_number.strip().upper()
    with get_db_connection() as conn:
        cursor = conn.cursor()
        if chat_id:
            cursor.execute("DELETE FROM rfq_edit_locks WHERE rfq_number = ? AND locked_by_chat_id = ?", (rfq_key, chat_id))
        else:
            cursor.execute("DELETE FROM rfq_edit_locks WHERE rfq_number = ?", (rfq_key,))
        conn.commit()

# ==============================================================================
# 3. QUOTATION SUBMISSION & CONFLICT DETECTION
# ==============================================================================

def check_quotation_conflict(rfq_number: str, chat_id: int, new_total_amount: float) -> Optional[Dict[str, Any]]:
    """
    Mengecek apakah sudah pernah ada penawaran aktif untuk RFQ ini oleh karyawan lain.
    Jika ada perbedaan nilai dalam 24 jam terakhir, kembalikan data konflik.
    """
    rfq_key = rfq_number.strip().upper()
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT * FROM rfq_quotations_history 
            WHERE rfq_number = ? AND status = 'SUBMITTED'
            ORDER BY created_at DESC LIMIT 1
        """, (rfq_key,))
        last = cursor.fetchone()
        
        if last:
            last_dict = dict(last)
            # Jika user yang mengajukan berbeda dan ada perbedaan harga
            if last_dict["submitted_by_chat_id"] != chat_id:
                diff = abs(float(last_dict["total_amount"]) - float(new_total_amount))
                if diff > 100:  # Perbedaan harga signifikan
                    return last_dict
    return None

def record_quotation_submission(
    rfq_number: str,
    quotation_no: str,
    chat_id: int,
    user_name: str,
    total_amount: float,
    payload_json: str
):
    """Mencatat histori penawaran resmi ke database dan melepas lock."""
    rfq_key = rfq_number.strip().upper()
    with get_db_connection() as conn:
        cursor = conn.cursor()
        # Tandai penawaran lama sebagai SUPERSEDED
        cursor.execute("""
            UPDATE rfq_quotations_history 
            SET status = 'SUPERSEDED' 
            WHERE rfq_number = ? AND status = 'SUBMITTED'
        """, (rfq_key,))
        
        # Masukkan penawaran baru
        cursor.execute("""
            INSERT INTO rfq_quotations_history 
            (rfq_number, quotation_no, submitted_by_chat_id, submitted_by_name, total_amount, payload_json, status, created_at)
            VALUES (?, ?, ?, ?, ?, ?, 'SUBMITTED', CURRENT_TIMESTAMP)
        """, (rfq_key, quotation_no, chat_id, user_name, total_amount, payload_json))
        conn.commit()

    # Otomatis lepas lock
    release_rfq_lock(rfq_key, chat_id)
