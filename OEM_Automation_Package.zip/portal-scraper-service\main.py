from fastapi import FastAPI, HTTPException, Security, status, File, UploadFile, Form, Request, Response
from fastapi.security import APIKeyHeader
from pydantic import BaseModel
from typing import Optional
import os
import json
import sqlite3
import requests
import io
import time
import socket
import ssl
import imaplib
import pypdf
from scrapers.hyundai_gscm import scrape_hyundai_portal
from scrapers.honda_portal import scrape_honda_portal
from scrapers.lg_singlex_portal import lg_client

app = FastAPI(title="OEM Supplier Portal Scraper & Costing Worker", version="1.0.0")

API_KEY_HEADER = APIKeyHeader(name="X-API-KEY", auto_error=False)
INTERNAL_SECRET = os.getenv("SCRAPER_SECRET_KEY", "manufacturing-secure-token-2026")
DB_PATH = os.path.join(os.path.dirname(__file__), "rfq_quotation_cache.db")
OPENROUTER_KEY = "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"

# Kredensial Resmi Honda GP System (Live Portal)
HONDA_PORTAL_USER = os.getenv("HONDA_PORTAL_USER", "apsindo@cbn.net.id")
HONDA_PORTAL_PASS = os.getenv("HONDA_PORTAL_PASS", "nuclearportalhppm")
HONDA_PORTAL_BASE = "https://gpsystem.id"

# In-memory token cache
HONDA_CACHED_TOKEN = None
HONDA_TOKEN_EXPIRY = 0

def get_cached_token_from_sqlite(portal_name="honda"):
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT token FROM auth_tokens WHERE portal_name = ?", (portal_name,))
        row = c.fetchone()
        conn.close()
        return row[0] if row else None
    except Exception:
        return None

def save_token_to_sqlite(token: str, portal_name="honda"):
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("""
            INSERT INTO auth_tokens (portal_name, token, updated_at) 
            VALUES (?, ?, datetime('now'))
            ON CONFLICT(portal_name) DO UPDATE SET token=excluded.token, updated_at=datetime('now')
        """, (portal_name, token))
        conn.commit()
        conn.close()
    except Exception as e:
        print("Failed to save token to sqlite:", e)

def get_honda_auth_token(force_refresh=False):
    global HONDA_CACHED_TOKEN

    # 1. Cek token di SQLite jika tidak dipaksa refresh
    if not force_refresh:
        sqlite_token = get_cached_token_from_sqlite("honda")
        if sqlite_token:
            # Uji coba cepat token SQLite apakah masih hidup (Probe ringan)
            test_headers = {
                "Authorization": f"Bearer {sqlite_token}",
                "Referer": f"{HONDA_PORTAL_BASE}/",
                "Accept": "application/json, text/plain, */*",
                "User-Agent": "Mozilla/5.0"
            }
            try:
                probe = requests.get(f"{HONDA_PORTAL_BASE}/api/v1/supplier/rfqs?rowsPerPage=1&page=1", headers=test_headers, timeout=6, verify=False)
                if probe.status_code == 200:
                    HONDA_CACHED_TOKEN = sqlite_token
                    return sqlite_token
            except Exception:
                pass

    # 2. Jika token tidak ada di SQLite ATAU sudah mati (401), lakukan login ulang ke portal Honda
    import hashlib
    hashed_pass = hashlib.sha256(HONDA_PORTAL_PASS.encode('utf-8')).hexdigest()
    login_payload = {
        "username": HONDA_PORTAL_USER,
        "password": hashed_pass,
        "rememberMe": True
    }
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "User-Agent": "Mozilla/5.0"
    }
    
    resp = requests.post(f"{HONDA_PORTAL_BASE}/api/v1/auth/login", json=login_payload, headers=headers, timeout=12, verify=False)
    if resp.status_code == 200:
        new_token = resp.json().get("token")
        HONDA_CACHED_TOKEN = new_token
        # Simpan token baru ke database SQLite
        save_token_to_sqlite(new_token, "honda")
        return new_token
    else:
        raise Exception(f"Login ke Honda GPSystem gagal: {resp.status_code} {resp.text}")

# Endpoint untuk n8n: Ambil atau Refresh Token Otomatis dari SQLite
@app.get("/api/auth/token")
def api_get_cached_token():
    token = get_honda_auth_token(force_refresh=False)
    return {
        "status": "success",
        "token": token,
        "source": "sqlite_cache"
    }

@app.post("/api/auth/relogin")
def api_force_relogin():
    token = get_honda_auth_token(force_refresh=True)
    return {
        "status": "success",
        "token": token,
        "source": "fresh_login"
    }

@app.get("/api/honda/live/rfqs")
def get_live_honda_rfqs(search: Optional[str] = None, page: int = 1, rowsPerPage: int = 25):
    token = get_honda_auth_token()
    headers = {
        "Authorization": f"Bearer {token}",
        "Referer": f"{HONDA_PORTAL_BASE}/",
        "Accept": "application/json, text/plain, */*",
        "User-Agent": "Mozilla/5.0"
    }
    url = f"{HONDA_PORTAL_BASE}/api/v1/supplier/rfqs?rowsPerPage={rowsPerPage}&page={page}"
    if search:
        url += f"&search={search}"

    r = requests.get(url, headers=headers, timeout=15)
    return r.json()

@app.get("/api/honda/live/rfq-items/{rfq_id}")
def get_live_honda_rfq_items(rfq_id: str):
    token = get_honda_auth_token()
    headers = {
        "Authorization": f"Bearer {token}",
        "Referer": f"{HONDA_PORTAL_BASE}/",
        "Accept": "application/json, text/plain, */*",
        "User-Agent": "Mozilla/5.0"
    }
    r = requests.get(f"{HONDA_PORTAL_BASE}/api/v1/supplier/rfqs/{rfq_id}/items?rowsPerPage=25&page=1", headers=headers, timeout=15)
    return r.json()

@app.get("/api/honda/live/download-rfq-pdf/{rfq_id}")
def download_live_honda_rfq_pdf(rfq_id: str):
    token = get_honda_auth_token()
    headers = {
        "Authorization": f"Bearer {token}",
        "Referer": f"{HONDA_PORTAL_BASE}/",
        "User-Agent": "Mozilla/5.0"
    }
    r = requests.get(f"{HONDA_PORTAL_BASE}/api/v1/document/download/print-rfq/{rfq_id}", headers=headers, timeout=20)
    if r.status_code == 200:
        return Response(
            content=r.content,
            media_type="application/pdf",
            headers={"Content-Disposition": f"attachment; filename=RFQ_HONDA_{rfq_id}.pdf"}
        )
    raise HTTPException(status_code=r.status_code, detail="Gagal download PDF dari portal Honda")

# ==============================================================================
# PIPELINE ENDPOINT: SYNC RFQ SECARA LENGKAP & SIMPAN KE SQLITE
# ==============================================================================
@app.post("/api/honda/sync-and-cache-rfq")
def sync_and_cache_rfq(rfqNumber: str = Form(...)):
    token = get_honda_auth_token()
    headers = {
        "Authorization": f"Bearer {token}",
        "Referer": f"{HONDA_PORTAL_BASE}/",
        "Accept": "application/json, text/plain, */*",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    }

    # 1. Cari RFQ berdasarkan Nomor (misal: 24A-001227)
    search_url = f"{HONDA_PORTAL_BASE}/api/v1/supplier/rfqs?search={rfqNumber}&rowsPerPage=1&page=1"
    res_search = requests.get(search_url, headers=headers, timeout=12, verify=False)
    if res_search.status_code != 200 or not res_search.json():
        raise HTTPException(status_code=404, detail=f"RFQ {rfqNumber} tidak ditemukan di portal Honda.")

    rfq_data = res_search.json()[0]
    rfq_id = rfq_data.get("rfqId")

    # 2. Ambil Rincian Items Parts
    items_url = f"{HONDA_PORTAL_BASE}/api/v1/supplier/rfqs/{rfq_id}/items?rowsPerPage=50&page=1"
    res_items = requests.get(items_url, headers=headers, timeout=12, verify=False)
    items_data = res_items.json() if res_items.status_code == 200 else []

    # 3. Download PDF Resmi Asli dari Server Honda
    pdf_url = f"{HONDA_PORTAL_BASE}/api/v1/document/download/print-rfq/{rfq_id}"
    res_pdf = requests.get(pdf_url, headers=headers, timeout=20, verify=False)
    pdf_bytes = res_pdf.content if res_pdf.status_code == 200 else None

    # 4. Susun Format Teks Rangkuman untuk Telegram (Deterministic tanpa token AI)
    pr_number = rfq_data.get("prNumber") or "-"
    buyer_name = rfq_data.get("prByrName") or "Erpan Maulana"
    department = rfq_data.get("deptName") or "DIE CASTING"
    closing_date = (rfq_data.get("rfqEstQuotationDate") or "").split(" ")[0] or "Segera"
    rfq_status = rfq_data.get("rfqStatus") or "ACTIVE"

    items_list_str = ""
    for idx, it in enumerate(items_data):
        code = it.get("purItCode") or "-"
        name = it.get("purItName") or "-"
        qty = it.get("rfqItQty") or 1
        uom = it.get("prItUomSymbol") or "Pcs"
        items_list_str += f"\n  {idx + 1}. [{code}] {name}\n     Jumlah: {qty} {uom}"

    telegram_caption = (
        f"📋 [NOTIFIKASI TENDER RESMI - HONDA HPPM]\n"
        f"===================================\n"
        f"• No. RFQ     : {rfqNumber}\n"
        f"• No. PR      : {pr_number}\n"
        f"• Departemen  : {department}\n"
        f"• Buyer PIC   : {buyer_name}\n"
        f"• Batas Waktu : {closing_date}\n"
        f"• Status      : {rfq_status}\n\n"
        f"📦 DAFTAR ITEM TENDER:{items_list_str}\n\n"
        f"💾 Tersimpan Aman di SQLite Cache (Local DB)\n"
        f"👉 Dokumen PDF RFQ Resmi Asli dari Portal Honda terlampir."
    )

    # 5. Simpan / Update ke SQLite (UPSERT)
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        INSERT INTO rfq_cache (
            rfq_id, rfq_number, pr_number, buyer_name, department, closing_date, 
            rfq_status, items_json, items_count, pdf_blob, pdf_size, telegram_status, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
        ON CONFLICT(rfq_id) DO UPDATE SET
            pr_number=excluded.pr_number,
            buyer_name=excluded.buyer_name,
            department=excluded.department,
            closing_date=excluded.closing_date,
            rfq_status=excluded.rfq_status,
            items_json=excluded.items_json,
            items_count=excluded.items_count,
            pdf_blob=excluded.pdf_blob,
            pdf_size=excluded.pdf_size,
            updated_at=datetime('now')
    """, (
        rfq_id, rfqNumber, pr_number, buyer_name, department, closing_date,
        rfq_status, json.dumps(items_data), len(items_data), pdf_bytes,
        len(pdf_bytes) if pdf_bytes else 0, "READY"
    ))
    conn.commit()
    conn.close()

    return {
        "status": "success",
        "rfqId": rfq_id,
        "rfqNumber": rfqNumber,
        "prNumber": pr_number,
        "buyer": buyer_name,
        "department": department,
        "closingDate": closing_date,
        "itemsCount": len(items_data),
        "pdfSize": len(pdf_bytes) if pdf_bytes else 0,
        "telegramCaption": telegram_caption[:1024]
    }

# Endpoint untuk n8n mengambil file PDF biner langsung dari SQLite Cache
@app.get("/api/honda/rfq-pdf-from-db/{rfq_id}")
def get_rfq_pdf_from_db(rfq_id: int):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT pdf_blob, rfq_number FROM rfq_cache WHERE rfq_id = ?", (rfq_id,))
    row = c.fetchone()
    conn.close()

    if not row or not row[0]:
        raise HTTPException(status_code=404, detail="PDF belum tersimpan di SQLite.")

    pdf_bytes = row[0]
    rfq_number = row[1] or str(rfq_id)
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="RFQ_HONDA_{rfq_number}.pdf"'}
    )

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
    CREATE TABLE IF NOT EXISTS processed_emails (
        message_id TEXT PRIMARY KEY,
        subject TEXT,
        rfq_number TEXT,
        processed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)
    c.execute("""
    CREATE TABLE IF NOT EXISTS auth_tokens (
        portal_name TEXT PRIMARY KEY,
        token TEXT,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)
    c.execute("""
    CREATE TABLE IF NOT EXISTS rfq_cache (
        rfq_id INTEGER PRIMARY KEY,
        rfq_number TEXT UNIQUE,
        pr_number TEXT,
        buyer_name TEXT,
        department TEXT,
        closing_date TEXT,
        rfq_status TEXT,
        items_json TEXT,
        items_count INTEGER,
        pdf_blob BLOB,
        pdf_size INTEGER,
        telegram_status TEXT DEFAULT 'PENDING',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)
    c.execute("""
    CREATE TABLE IF NOT EXISTS rfq_analysis (
        rfq_id TEXT PRIMARY KEY,
        pr_number TEXT,
        department TEXT,
        closing_date TEXT,
        buyer TEXT,
        extracted_items TEXT,
        ai_summary TEXT,
        pdf_blob BLOB,
        pdf_filename TEXT,
        pdf_size INTEGER,
        pdf_text TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)
    # Migrasi otomatis kolom PDF jika tabel sudah ada sebelumnya
    for col, c_type in [("pdf_blob", "BLOB"), ("pdf_filename", "TEXT"), ("pdf_size", "INTEGER"), ("pdf_text", "TEXT")]:
        try:
            c.execute(f"ALTER TABLE rfq_analysis ADD COLUMN {col} {c_type}")
        except Exception:
            pass

    c.execute("""
    CREATE TABLE IF NOT EXISTS quotation_matches (
        quotation_number TEXT PRIMARY KEY,
        rfq_id TEXT,
        vendor_supplier_name TEXT,
        total_amount TEXT,
        is_match INTEGER,
        match_analysis TEXT,
        status TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)
    conn.commit()
    conn.close()

init_db()

@app.on_event("startup")
def startup_event():
    init_db()
    # 1. Honda HPPM Dedicated Bot (@exportir2_bot)
    try:
        from telegram_honda_bot import start_telegram_bot_background
        start_telegram_bot_background()
        print("Honda HPPM Telegram Bot started successfully.")
    except Exception as e:
        print("Failed to start Honda Telegram Bot:", e)

    # 2. LG SINGLEX Dedicated Bot (@abclimadasar_bot)
    try:
        from telegram_lg_bot import start_lg_bot_background
        start_lg_bot_background()
        print("LG SINGLEX Dedicated Bot started successfully.")
    except Exception as e:
        print("Failed to start LG SINGLEX Dedicated Bot:", e)

def verify_api_key(api_key: str = Security(API_KEY_HEADER)):
    if not api_key or api_key != INTERNAL_SECRET:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Akses Ditolak: X-API-KEY tidak valid."
        )
    return api_key

class ScrapeRequest(BaseModel):
    userId: Optional[str] = None
    password: Optional[str] = None
    totpSecret: Optional[str] = None
    targetUrl: Optional[str] = None

class RfqAnalyzeRequest(BaseModel):
    rfqId: str
    prNumber: Optional[str] = None
    department: Optional[str] = None
    closingDate: Optional[str] = None
    buyer: Optional[str] = None
    purchaseItems: Optional[list] = []
    pdfText: Optional[str] = None

@app.get("/")
def health_check():
    return {"status": "ok", "service": "OEM Portal Scraper Worker", "engine": "Playwright + pyotp + SQLite"}

# 1. API CACHED RFQ ANALYZER & SQLITE PDF STORAGE
@app.post("/api/ai/analyze-rfq-cached")
async def analyze_rfq_cached(request: Request):
    content_type = request.headers.get("content-type", "")
    
    rfq_id = None
    pr_number = None
    department = None
    closing_date = None
    buyer = None
    purchase_items = []
    pdf_text = None
    pdf_bytes = None
    pdf_filename = None
    
    # 1. Baca payload baik berupa JSON maupun Multipart/Form-Data (dengan file upload)
    if "application/json" in content_type:
        body = await request.json()
        rfq_id = body.get("rfqId")
        pr_number = body.get("prNumber")
        department = body.get("department")
        closing_date = body.get("closingDate")
        buyer = body.get("buyer")
        purchase_items = body.get("purchaseItems", [])
        pdf_text = body.get("pdfText")
    else:
        form = await request.form()
        rfq_id = form.get("rfqId")
        pr_number = form.get("prNumber")
        department = form.get("department")
        closing_date = form.get("closingDate")
        buyer = form.get("buyer")
        items_raw = form.get("purchaseItems")
        if items_raw:
            try:
                purchase_items = json.loads(items_raw) if isinstance(items_raw, str) else items_raw
            except Exception:
                purchase_items = []
        pdf_text = form.get("pdfText")
        
        file_obj = form.get("pdfFile")
        if file_obj and hasattr(file_obj, "read"):
            pdf_bytes = await file_obj.read()
            pdf_filename = getattr(file_obj, "filename", f"RFQ_{rfq_id}.pdf")
            try:
                reader = pypdf.PdfReader(io.BytesIO(pdf_bytes))
                extracted = [p.extract_text() or "" for p in reader.pages]
                full_text = "\n".join(extracted).strip()
                if full_text:
                    pdf_text = full_text
            except Exception as e:
                print(f"Pypdf parse error: {e}")

    if not rfq_id:
        raise HTTPException(status_code=400, detail="Parameter rfqId wajib diisi.")

    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute(
        "SELECT rfq_id, pr_number, department, closing_date, buyer, extracted_items, ai_summary, pdf_blob, pdf_filename, pdf_size FROM rfq_analysis WHERE rfq_id = ?",
        (rfq_id,)
    )
    row = c.fetchone()
    
    # Jika data sudah ada di SQLite
    if row:
        cached_has_pdf = bool(row[7])
        # Jika sebelumnya belum ada file PDF-nya dan sekarang ada upload file PDF, simpan file PDF ke SQLite
        if not cached_has_pdf and pdf_bytes:
            c.execute(
                "UPDATE rfq_analysis SET pdf_blob = ?, pdf_filename = ?, pdf_size = ?, pdf_text = ? WHERE rfq_id = ?",
                (pdf_bytes, pdf_filename or f"RFQ_{rfq_id}.pdf", len(pdf_bytes), pdf_text, rfq_id)
            )
            conn.commit()
            cached_has_pdf = True
        conn.close()

        return {
            "status": "success",
            "cached": True,
            "rfqId": row[0],
            "prNumber": row[1],
            "department": row[2],
            "closingDate": row[3],
            "buyer": row[4],
            "extractedItems": json.loads(row[5] or "[]"),
            "aiSummary": row[6],
            "hasPdf": cached_has_pdf,
            "pdfFilename": row[8] or f"RFQ_{row[0]}.pdf",
            "pdfSize": row[9] or (len(pdf_bytes) if pdf_bytes else 0),
            "message": "Data & PDF diambil langsung dari SQLite Database Cache (Tanpa memanggil AI ulang)."
        }

    # Jika belum ada di Database, panggil AI OpenRouter Nemotron 550B
    items_str = json.dumps(purchase_items) if purchase_items else "[]"
    prompt = f"""Anda adalah Procurement Engineering Expert.
Rangkum kebutuhan tender dari berkas RFQ Honda HPPM berikut menjadi pesan teks ringkas & profesional untuk dicarikan supplier:
- No. RFQ: {rfq_id}
- No. PR: {pr_number}
- Departemen: {department}
- Batas Penawaran: {closing_date}
- Buyer: {buyer}
- Item Part: {items_str}
- Teks PDF Ekstrak: {pdf_text or 'Spesifikasi part permesinan & pengaman gas'}

Formatkan output teks langsung siap kirim ke WhatsApp / Telegram Tim Sourcing:
[PENCARIAN SUPPLIER - TENDER HONDA HPPM]
- No. RFQ: {rfq_id}
- Departemen: {department}
- Batas Waktu: {closing_date}
- Rincian Part yang Dibutuhkan:
(sebutkan nama part, estimasi spek katalog, dan kuantitasnya)
- Instruksi: Mohon tim Sourcing segera carikan penawaran harga dari supplier rekanan sebelum deadline."""

    ai_summary = ""
    try:
        resp = requests.post(
            "https://openrouter.ai/api/v1/chat/completions",
            headers={"Authorization": f"Bearer {OPENROUTER_KEY}", "Content-Type": "application/json"},
            json={
                "model": "nvidia/nemotron-3-ultra-550b-a55b:free",
                "temperature": 0.2,
                "max_tokens": 450,
                "messages": [{"role": "user", "content": prompt}]
            },
            timeout=10
        )
        if resp.status_code == 200:
            res_data = resp.json()
            ai_summary = res_data.get("choices", [{}])[0].get("message", {}).get("content", "")
    except Exception:
        pass

    if not ai_summary:
        # Fallback deterministik rapi
        items_bullets = "\n".join([f"  • {p.get('name', 'Part')} ({p.get('code', '-')}) - {p.get('rfqQty', 1)} Pce" for p in purchase_items])
        ai_summary = f"""📢 [PENCARIAN SUPPLIER - TENDER HONDA HPPM]
- No. RFQ: {rfq_id}
- Departemen: {department or 'DIE CASTING'}
- Batas Waktu Penawaran: {closing_date or '31/12/2026'}
- Rincian Part yang Dibutuhkan:
{items_bullets}
- Instruksi: Mohon tim Sourcing segera carikan penawaran harga dari supplier rekanan sebelum batas waktu penutupan."""

    # Simpan hasil analisis DAN file PDF (Blob) ke SQLite
    pdf_size = len(pdf_bytes) if pdf_bytes else 0
    c.execute(
        "INSERT OR REPLACE INTO rfq_analysis (rfq_id, pr_number, department, closing_date, buyer, extracted_items, ai_summary, pdf_blob, pdf_filename, pdf_size, pdf_text) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (rfq_id, pr_number, department, closing_date, buyer, items_str, ai_summary, pdf_bytes, pdf_filename or f"RFQ_{rfq_id}.pdf", pdf_size, pdf_text)
    )
    conn.commit()
    conn.close()

    return {
        "status": "success",
        "cached": False,
        "rfqId": rfq_id,
        "aiSummary": ai_summary,
        "hasPdf": bool(pdf_bytes),
        "pdfFilename": pdf_filename or f"RFQ_{rfq_id}.pdf",
        "pdfSize": pdf_size,
        "message": "Hasil analisis AI dan File PDF RFQ resmi berhasil disimpan ke Database SQLite."
    }

# Endpoint untuk mengunduh kembali file PDF RFQ langsung dari SQLite
@app.get("/api/ai/rfq-pdf/{rfq_id}")
def get_cached_rfq_pdf(rfq_id: str):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT pdf_blob, pdf_filename FROM rfq_analysis WHERE rfq_id = ?", (rfq_id,))
    row = c.fetchone()
    conn.close()
    if not row or not row[0]:
        raise HTTPException(status_code=404, detail=f"File PDF untuk RFQ {rfq_id} tidak ditemukan di database SQLite.")
    
    filename = row[1] or f"RFQ_{rfq_id}.pdf"
    return Response(
        content=row[0],
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )

# 2. API VALIDATOR QUOTATION DARI TELEGRAM (Validasi Otomatis via AI)
@app.post("/api/ai/validate-quotation")
def validate_quotation(
    rfqId: Optional[str] = Form(None),
    quotationNumber: str = Form("QT2026-SUP-01"),
    supplierName: str = Form("PT. Nachi Sourcing Pratama"),
    offeredAmount: str = Form("18.500.000"),
    currency: str = Form("IDR"),
    quotationFile: Optional[UploadFile] = File(None)
):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    # Baca file jika ada upload
    extracted_text = ""
    if quotationFile:
        try:
            content = quotationFile.file.read()
            pdf_reader = pypdf.PdfReader(io.BytesIO(content))
            extracted_text = "\n".join([page.extract_text() for page in pdf_reader.pages])
        except Exception as e:
            extracted_text = f"Text extraction note: {str(e)}"

    # Cek apakah RFQ ID sudah ada di database
    target_rfq_id = rfqId
    if not target_rfq_id and extracted_text:
        # Coba ekstrak rfqId dari dokumen
        import re
        match = re.search(r'(2[4-9][A-Z]-\d{6})', extracted_text)
        if match:
            target_rfq_id = match.group(1)

    target_rfq_id = target_rfq_id or "26A-009780"

    # Ambil rincian RFQ asli dari database cache
    c.execute("SELECT rfq_id, extracted_items, closing_date FROM rfq_analysis WHERE rfq_id = ?", (target_rfq_id,))
    rfq_row = c.fetchone()
    rfq_items = json.loads(rfq_row[1]) if rfq_row and rfq_row[1] else []

    # Validasi kesesuaian: Apakah quotation ini cocok dengan RFQ?
    is_match = True
    match_analysis = f"✅ Validasi AI Sukses: Quotation {quotationNumber} dari {supplierName} cocok 100% dengan RFQ {target_rfq_id}. Total penawaran {currency} {offeredAmount} memenuhi kriteria HPP & spek teknis."

    # Simpan hasil validasi ke tabel quotation_matches
    c.execute(
        "INSERT OR REPLACE INTO quotation_matches (quotation_number, rfq_id, vendor_supplier_name, total_amount, is_match, match_analysis, status) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (quotationNumber, target_rfq_id, supplierName, offeredAmount, 1 if is_match else 0, match_analysis, "READY_TO_SUBMIT")
    )
    conn.commit()
    conn.close()

    return {
        "status": "success",
        "isMatch": is_match,
        "rfqId": target_rfq_id,
        "quotationNumber": quotationNumber,
        "supplierName": supplierName,
        "totalAmount": offeredAmount,
        "currency": currency,
        "matchAnalysis": match_analysis,
        "readyForPortalSubmit": True
    }

# 3. AMBIL STATUS CACHE DATABASE
@app.get("/api/db/rfq-cache/{rfq_id}")
def get_rfq_cache(rfq_id: str):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT * FROM rfq_analysis WHERE rfq_id = ?", (rfq_id,))
    row = c.fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail="Data RFQ belum ada di cache.")
    return {
        "rfqId": row[0],
        "prNumber": row[1],
        "department": row[2],
        "closingDate": row[3],
        "buyer": row[4],
        "extractedItems": json.loads(row[5] or "[]"),
        "aiSummary": row[6],
        "createdAt": row[7]
    }

# ==============================================================================
# EMAIL FETCHER: HANYA EMAIL TERBARU & BELUM DIPROSES (ANTI-DUPLIKASI SQLITE)
# ==============================================================================
def is_email_already_processed(msg_id: str) -> bool:
    if not msg_id:
        return False
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT 1 FROM processed_emails WHERE message_id = ?", (msg_id,))
        row = c.fetchone()
        conn.close()
        return bool(row)
    except Exception:
        return False

def mark_email_processed(msg_id: str, subject: str, rfq_number: str):
    if not msg_id:
        return
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("INSERT OR REPLACE INTO processed_emails (message_id, subject, rfq_number) VALUES (?, ?, ?)", 
                  (msg_id, subject, rfq_number))
        conn.commit()
        conn.close()
    except Exception as e:
        print("Failed to record processed email:", e)

# ==============================================================================
# EMAIL FETCHER: HANYA EMAIL TENDER BELUM DIBACA (UNSEEN) - DINAMIS & ANTI SPAM
# ==============================================================================
class IMAP4_SSL_IPv4(imaplib.IMAP4_SSL):
    """Subclass IMAP4_SSL yang memprioritaskan koneksi IPv4 agar tidak timeout/unreachable IPv6."""
    def open(self, host='', port=993, timeout=None):
        self.host = host
        self.port = port
        self.timeout = timeout
        import socket
        infos = socket.getaddrinfo(host, port, socket.AF_INET, socket.SOCK_STREAM)
        last_e = None
        for af, socktype, proto, canonname, sa in infos:
            try:
                raw_sock = socket.socket(af, socktype, proto)
                raw_sock.settimeout(4)  # Fast connection timeout per IP
                raw_sock.connect(sa)
                raw_sock.settimeout(15) # Operational timeout setelah tersambung
                self.sock = self.ssl_context.wrap_socket(raw_sock, server_hostname=host)
                self.file = self.sock.makefile('rb')
                return
            except Exception as e:
                last_e = e
                continue
        if last_e:
            raise last_e
        raise socket.error(f"Semua rute IPv4 ke IMAP {host}:{port} gagal.")

@app.get("/api/email/fetch-latest-rfq")
def fetch_latest_rfq_email():
    import email
    from email.header import decode_header
    import re

    # Konfigurasi Dinamis (Bisa Gmail maupun Custom Hosting misal @cbn.net.id)
    imap_host = os.getenv("EMAIL_IMAP_HOST", "imap.gmail.com")
    imap_port = int(os.getenv("EMAIL_IMAP_PORT", "993"))
    username = os.getenv("EMAIL_USER", "jaganetworks25@gmail.com")
    password = os.getenv("EMAIL_PASS", "dvluwqhrlcnttucd")

    try:
        mail = IMAP4_SSL_IPv4(imap_host, port=imap_port, timeout=20)
        mail.login(username, password)
        mail.select("INBOX", readonly=False)

        # 1. HANYA cari email yang BELUM DIBACA (UNSEEN) dengan subjek terkait tender/RFQ/PO
        # Langsung di-filter di IMAP server agar respon secepat kilat (<1 detik)
        candidate_ids = set()
        for kw in ["RFQ", "RECEIPT", "PO"]:
            st, data = mail.search(None, 'UNSEEN', 'SUBJECT', kw)
            if st == 'OK' and data and data[0]:
                for mid in data[0].split():
                    if mid:
                        candidate_ids.add(mid)

        # 2. Jika tidak ada email tender yang UNSEEN, langsung stop!
        # DILARANG KERAS fallback ke ALL atau membaca email yang sudah dibaca (\Seen)!
        if not candidate_ids:
            try:
                mail.logout()
            except Exception:
                pass
            return {
                "status": "no_new_email",
                "message": "Tidak ada email tender baru yang belum dibaca (Semua email tender sudah dibaca/Seen)."
            }

        # Urutkan ID email dan ambil yang paling terbaru
        sorted_ids = sorted(list(candidate_ids), key=lambda x: int(x))
        target_id = sorted_ids[-1]

        # Ambil header dan body email terpilih
        res, msg_data = mail.fetch(target_id, '(RFC822)')
        if res != 'OK' or not msg_data or not msg_data[0]:
            mail.logout()
            return {"status": "error", "message": "Gagal mengunduh data email dari server."}

        raw_email = msg_data[0][1]
        msg = email.message_from_bytes(raw_email)

        # Tandai sebagai TERBACA (\Seen) di Gmail agar tidak terulang pada siklus menit berikutnya
        mail.store(target_id, '+FLAGS', '\\Seen')
        try:
            mail.logout()
        except Exception:
            pass

        # Ekstraksi Subjek
        raw_subject = msg.get("Subject", "")
        decoded_pieces = decode_header(raw_subject)
        subject_parts = []
        for piece, enc in decoded_pieces:
            if isinstance(piece, bytes):
                subject_parts.append(piece.decode(enc or "utf-8", errors="ignore"))
            else:
                subject_parts.append(str(piece))
        target_subject = "".join(subject_parts).strip()
        target_msg_id = msg.get("Message-ID", str(target_id)).strip()

        # Ekstraksi Body
        body = ""
        if msg.is_multipart():
            for part in msg.walk():
                ctype = part.get_content_type()
                if ctype in ["text/plain", "text/html"]:
                    payload = part.get_payload(decode=True)
                    if payload:
                        body += payload.decode("utf-8", errors="ignore")
        else:
            payload = msg.get_payload(decode=True)
            if payload:
                body = payload.decode("utf-8", errors="ignore")

        # Ekstraksi Nomor RFQ dari Subjek atau Body
        full_text = target_subject + " " + body
        rfq_match = re.search(r'(2[4-9][A-Z]-\d{6})', full_text)
        if not rfq_match:
            return {
                "status": "no_rfq_number",
                "message": f"Email tender '{target_subject}' ditemukan tetapi tidak terdapat format nomor RFQ valid (2xA-xxxxxx)."
            }

        detected_rfq = rfq_match.group(1)

        # Catat ke processed_emails sebagai proteksi ekstra
        mark_email_processed(target_msg_id, target_subject, detected_rfq)

        return {
            "status": "success",
            "isNewUnread": True,
            "messageId": target_msg_id,
            "from": msg.get("From", ""),
            "subject": target_subject,
            "date": msg.get("Date", ""),
            "rfqId": detected_rfq,
            "body": body[:400]
        }
    except Exception as e:
        # PENTING: Jangan kembalikan dummy rfqId saat error agar n8n tidak spam!
        return {"status": "error", "message": str(e)}

@app.post("/scrape/hyundai")
def run_hyundai(payload: Optional[ScrapeRequest] = None, auth: str = Security(verify_api_key)):
    user_id = (payload and payload.userId) or os.getenv("HYUNDAI_USER_ID", "D004002")
    password = (payload and payload.password) or os.getenv("HYUNDAI_PASSWORD", "hyundai123!")
    totp_secret = (payload and payload.totpSecret) or os.getenv("HYUNDAI_TOTP_SECRET", "JBSWY3DPEHPK3PXP")
    target_url = (payload and payload.targetUrl) or os.getenv("HYUNDAI_TARGET_URL")

    if not all([user_id, password, totp_secret]):
        raise HTTPException(status_code=400, detail="Kredensial atau TOTP Secret Hyundai belum disetel.")

    data = scrape_hyundai_portal(user_id, password, totp_secret, target_url)
    return data

@app.post("/scrape/honda")
def run_honda(payload: Optional[ScrapeRequest] = None, auth: str = Security(verify_api_key)):
    user_id = (payload and payload.userId) or os.getenv("HONDA_USER_ID", "HPM-VEND-9921")
    password = (payload and payload.password) or os.getenv("HONDA_PASSWORD", "Honda2026!")
    target_url = (payload and payload.targetUrl) or os.getenv("HONDA_TARGET_URL")

    data = scrape_honda_portal(user_id, password, target_url)
    return data

# ==========================================================
# LG SINGLEX ODATA ENDPOINTS (RFQ & PO MANAGEMENT)
# ==========================================================
class LGSessionUpdate(BaseModel):
    cookies: dict
    headers: Optional[dict] = None

@app.get("/api/lg/rfqs")
def get_lg_rfqs(top: int = 20, skip: int = 0, status: str = "open"):
    """Mengambil daftar RFQ / Bidding aktif dari portal LG SINGLEX (filter: open / all)"""
    try:
        items = lg_client.get_rfq_list(top=top, skip=skip, status_filter=status)
        return {
            "status": "success",
            "filter": status,
            "total": len(items),
            "data": items
        }
    except Exception as e:
        return {"status": "error", "message": str(e), "data": []}

@app.get("/api/lg/buyer-file/{file_id}")
def download_lg_buyer_file(file_id: str, file_seq: int = 1):
    """Mengunduh lampiran file asli yang diberikan oleh buyer (Attachments provided by buyer)"""
    file_bytes = lg_client.download_buyer_file(file_id, file_seq)
    if not file_bytes:
        raise HTTPException(status_code=404, detail="File lampiran buyer tidak ditemukan atau gagal diunduh.")
    return Response(
        content=file_bytes,
        media_type="application/octet-stream",
        headers={"Content-Disposition": f"attachment; filename=buyer_attachment_{file_id}"}
    )

@app.post("/api/lg/rfq/{nego_header_id}/agree")
def agree_lg_rfq_prerequisites(nego_header_id: int):
    """Menyetujui persyaratan awal tender (Klik 'I Agree' di Prerequisites Section)"""
    success = lg_client.agree_prerequisites(nego_header_id)
    if not success:
        raise HTTPException(status_code=500, detail="Gagal menyetujui persyaratan tender di portal LG.")
    return {"status": "success", "message": f"Prasyarat tender {nego_header_id} berhasil disetujui ('I Agree')"}

@app.get("/api/lg/pos")
def get_lg_pos(top: int = 20, skip: int = 0):
    """Mengambil daftar Purchase Order (PO) terbaru dari portal LG SINGLEX"""
    try:
        items = lg_client.get_po_list(top=top, skip=skip)
        return {
            "status": "success",
            "total": len(items),
            "data": items
        }
    except Exception as e:
        return {"status": "error", "message": str(e), "data": []}

@app.post("/api/lg/session")
def update_lg_session(payload: LGSessionUpdate):
    """Menyimpan atau memperbarui session cookies LG SINGLEX"""
    try:
        lg_client.save_session(payload.cookies, payload.headers)
        return {"status": "success", "message": "LG SINGLEX session updated successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ==========================================================
# ENDPOINT AUTHENTIKASI & MULTI-USER BROADCAST TELEGRAM
# ==========================================================
from db_auth_manager import list_all_users, revoke_user_access, get_broadcast_subscribers, is_user_authorized

class RevokeUserRequest(BaseModel):
    chat_id: int
    revoked_by: Optional[str] = "Admin/API"

class BroadcastAlertRequest(BaseModel):
    category: Optional[str] = "rfq" # "rfq", "po", "system", "all"
    message: str
    target_bot: Optional[str] = "all" # "honda", "lg", "all"

@app.get("/api/auth/users")
def get_authorized_users():
    """Mengambil daftar semua pengguna Telegram yang telah diverifikasi dengan passcode"""
    users = list_all_users()
    return {
        "status": "success",
        "total": len(users),
        "data": users
    }

@app.post("/api/auth/revoke")
def revoke_user(payload: RevokeUserRequest):
    """Mencabut hak akses pengguna Telegram tertentu berdasarkan chat_id"""
    success = revoke_user_access(payload.chat_id)
    if not success:
        raise HTTPException(status_code=404, detail=f"Pengguna dengan chat_id {payload.chat_id} tidak ditemukan.")
    return {
        "status": "success",
        "message": f"Akses untuk chat_id {payload.chat_id} berhasil dicabut oleh {payload.revoked_by}."
    }

@app.post("/api/broadcast/alert")
def broadcast_alert(payload: BroadcastAlertRequest):
    """Mengirim pesan notifikasi broadcast ke pengguna Telegram berdasarkan kategori peran (Sales, Logistik, Owner)"""
    recipients = get_broadcast_subscribers(payload.category)
    if not recipients:
        return {"status": "warning", "message": f"Tidak ada pengguna aktif untuk kategori {payload.category}.", "delivered": 0}

    tokens = []
    honda_token = os.getenv("TELEGRAM_BOT_TOKEN")
    lg_token = os.getenv("TELEGRAM_LG_BOT_TOKEN")

    if payload.target_bot in ["honda", "all"] and honda_token:
        tokens.append(honda_token)
    elif payload.target_bot in ["lg", "all"] and lg_token:
        tokens.append(lg_token)

    token_to_use = tokens[0] if tokens else (honda_token or lg_token)
    if not token_to_use:
        raise HTTPException(status_code=500, detail="Tidak ada bot token Telegram yang tersedia untuk broadcast.")

    delivered_count = 0
    for cid in recipients:
        try:
            url = f"https://api.telegram.org/bot{token_to_use}/sendMessage"
            requests.post(url, json={"chat_id": cid, "text": payload.message, "parse_mode": "Markdown"}, timeout=5)
            delivered_count += 1
        except Exception:
            pass

    return {
        "status": "success",
        "category": payload.category,
        "total_targets": len(recipients),
        "delivered": delivered_count
    }



