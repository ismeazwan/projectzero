@echo off
title OEM Automation Suite - Launcher
echo ========================================================
echo   OEM MULTI-PORTAL AUTOMATION (HONDA & LG SINGLEX)
echo ========================================================
echo.
echo [1/2] Menjalankan Docker Containers (Worker & n8n)...
docker compose up -d

echo.
echo [2/2] Memastikan Host Bridge Service aktif di background...
wscript.exe "%~dp0start_bridge_silent.vbs"

echo.
echo ========================================================
echo   SEMUA KOMPONEN TELAH BERJALAN DENGAN SUKSES!
echo   - Scraper Worker (FastAPI + Playwright) : Port 8000
echo   - n8n Automation Engine                 : Port 5678
echo   - Host Bridge (Windows Cookie DPAPI)    : Port 5005
echo ========================================================
echo.
pause
